//require express library
var express = require('express');
//require the express router
var router = express.Router();
var config = require('../configuration.json');

var bodyParser = require('body-parser');
var app = express();
app.use(bodyParser.json({ limit: '100mb' }));
app.use(bodyParser.urlencoded({ limit: '100mb', extended: false }));

//require multer for the file uploads
var multer = require('multer');


var storage = multer.diskStorage({
    destination: function(req, file, cb) {
        cb(null, 'C:/SynMon/ftp/temp')
    },
    filename: function(req, file, cb) {
        var fname = file.originalname;
        var regexAll = /^([^\\]*)\.(\w+)$/;;

        // var total = path.match(regexAll);
        // var total=fname.slice((fname.lastIndexOf(".") - 1 >>> 0) + 2);
        var temp1, temp2;
        temp1 = fname.split(".");
        //console.log(temp1[0] + "  " + temp1[1]);
        //console.log();
        var total = fname.split(fname.lastIndexOf("."));
        var filename = total[0];
        var extension = total[1];
        //cb(null, temp1[0] + "_" + Date.now() + "." + temp1[1]);
        cb(null, fname);
        /* cb(null, filename+"_"+Date.now()+"."+extension);*/
    }
});


var fs = require('fs');


router.post('/uploadScreenshots', function(req, res) {
    var upload = multer({
        storage: storage
    }).single('photo');
    var path = '';
    upload(req, res, function(err) {
        if (err) {
            // An error occurred when uploading
            console.log(err);
            return res.status(422).send("" + err);
        } else {
            console.log('-----------------uploadScreenshots--------------------');
            var customerID = req.body.customerID;
            var applicationID = req.body.applicationID;

            var esResponseID = req.body.esResponseID;
            if (typeof customerID == "undefined" || customerID === "" || customerID === null) {
                customerID = "default";
            }

            if (typeof applicationID == "undefined" || applicationID === "" || applicationID === null || typeof req.file == "undefined") {
                return res.status(500).json("the values sent may be undefined null or empty");
            }
            
            var folderName = config.screenshootPath + customerID;
            if (!fs.existsSync(folderName)) {
                fs.mkdirSync(folderName);
                //console.log('Folder ' + folderName + ' was created!');
            }

            folderName = folderName + "/" + applicationID;
            if (!fs.existsSync(folderName)) {
                fs.mkdirSync(folderName);
                //console.log('Folder ' + folderName + ' was created!');
            }
            let resfilepath;
            if (typeof esResponseID == "undefined" || esResponseID === "" || esResponseID === null) {
                console.log("foldername in if : " + folderName);
                resfilepath = folderName + '/' + req.file.filename;
                console.log("resfilepath in if : " + resfilepath);
            } else {
                var fname = req.file.filename;
                var extension = fname.split(".")[1];
                resfilepath = folderName + '/' + esResponseID + "." + extension;
                console.log("resfilepath in else : " + resfilepath)
            }
            fs.copyFile('C:/SynMon/ftp/temp/' + req.file.filename, resfilepath, function(err) {
                if (err) {
                    console.log("error in file upload --");
                    console.error(err);
                    return res.status(500).json(err);
                }
                console.log('File moved');
                fs.unlink('C:/SynMon/ftp/temp/' + req.file.filename, function(error) {
                    if (error) {
                        console.log("error in file delete --");
                    } else {
                        console.log("File deleted from temp");
                        return res.status(200).json("Screenshots Added Successfully ");
                    }
                });

            });

            /* fs.copyFileSync('C:/SynMon/ftp/temp/' + req.file.filename, folderName + '/' + req.file.filename, function (err) {
                if (err) {
                    console.error(err);
                    return res.status(500).json(err);
                }
                console.log('File moved');
            });
            return res.status(200).json("Screenshots Added Successfully "); */
        }
    });
});





module.exports = router;