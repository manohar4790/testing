var mapCoordinates = {};
mapCoordinates["california"]={latitude:36.778261, longitude:-119.417932};
mapCoordinates["ohio"]={latitude:40.417287, longitude:-82.907123};
mapCoordinates["singapore"]={latitude:1.352083, longitude:103.819836};
mapCoordinates["london"]={latitude:51.507351, longitude:-0.127758};
mapCoordinates["mumbai"]={latitude:19.075984, longitude:72.877656};

var getCoordinates = function(placeName) {
    var placeNameLower = placeName.toLowerCase();
    var coordinates =  mapCoordinates[placeNameLower];
    return coordinates;
}

module.exports = getCoordinates;