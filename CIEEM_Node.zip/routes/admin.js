var config = require('../configuration.json');
var express = require('express');
var multer = require('multer');
var router = express.Router();
var app = express();
let mongo = require('mongodb');
var bodyParser = require('body-parser');
var jwt = require('jsonwebtoken');
const bcrypt = require('bcrypt');
var generateLicense = require("./license.js");
var elasticsearch = require('elasticsearch');
var elasticClient = new elasticsearch.Client({
    //host: 'http://18.219.74.14:9200',
    host: 'http://' + config.elasticsearchDBHost + ':9200',
    log: 'trace'
});


const saltRounds = config.saltRounds;
//app.set('secretKey', 'nodeRestApi')
app.use(bodyParser.json({ limit: '50mb' }));
app.use(bodyParser.urlencoded({ limit: '50mb', extended: false }));
//app.use(redirectToHTTPS([/localhost:(\d{4})/], [/\/addNewCustomerAdmin/], 301));

let ObjectID = mongo.ObjectID;
let db;
mongo.connect(config.mongoDBURL, function(err, mongoDB) {
    db = mongoDB.db();
    console.log("Connected to MongoDB - admin.js");
});

//this is onload of admin page
router.get('/getAllCustomerDetailsAdmin', function(req, res) {
    db.collection("Customers").find({}).toArray((err, result) => {
        if (err) {
            console.log("Error in Customers detail module : " + err);
            return res.status(500).json("Internal Error: Error in displaying customer data");
        } else {
            console.log("Result  " + result);
            return res.status(200).json(result);
        }
    });
});



//this is to get customer details after selecting a customer in admin page
router.get('/getCustomerDetailsAdmin', function(req, res) {

    console.log("inside getCustomerDetailsAdmin");
    var id = req.query.customerId;
    if (typeof id == "undefined" || id === "" || id === null) {
        return res.status(404).json("Customer Id is null or undefined");
    }
    db.collection("Customers").find({ "_id": mongo.ObjectID(id) }).toArray((err, result) => {
        if (err) {
            console.log("Error in Customers detail module : " + err);
            return res.status(500).json("Internal Server Error: Error in displaying selected customer data");
        } else {
            console.log("Result  " + result);
            return res.status(200).json(result);
        }
    });
});



router.post('/addNewCustomerAdmin', function(req, res) {
    console.log("inside addNewCustomerAdmin");
    var customerName = req.body.customerName;
    var contactDetails = req.body.contactDetails;
    if (typeof customerName == "undefined" || customerName === "" || typeof contactDetails == "undefined" || contactDetails === "" || customerName === null || contactDetails === null) {
        return res.status(404).json("the values sent may be undefined or null or empty");
    }
    var license = generateLicense(customerName);
    // if (license) {
    db.collection("Customers").insert({ "customerName": customerName, "contactDetails": contactDetails, "application": [] }, function(err, result) {
        if (err) {
            console.log("Error in newCustomer : " + err);
            return res.status(500).json("Internal Server Error: Error in adding customer");
        } else {
            console.log("No Error in  applicationNames : ");

            return res.status(200).json("added application Successfully");
        }
    });
    // } else {
    //     return res.status(500).json("Internal Server Error: Error in creating license file ");
    // }

});


router.post('/updateCustomerAdmin', function(req, res) {
    var id = req.query.customerId;
    var customerName = req.body.customerName;
    var contactDetails = req.body.contactDetails;
    if (typeof id == "undefined" || id === "" || typeof customerName == "undefined" || customerName === "" || typeof contactDetails == "undefined" || contactDetails === "" || id === null || customerName === null || contactDetails === null) {
        return res.status(500).json("the values sent may be undefined null or empty");
    }
    db.collection("Customers").update({ "_id": mongo.ObjectID(id) }, { "$set": { "customerName": customerName, "contactDetails": contactDetails } }, function(err, result) {
        if (err) {
            console.log("Error in updateCustomerAdmin : " + err);
            return res.status(500).json("Internal Server Error: Error in updating customer");
        } else {
            console.log("No Error in  updateCustomerAdmin : ");
            return res.status(200).json("updated customer Successfully");
        }
    });
});

router.delete('/deleteCustomer', function(req, res) {
    var id = req.query.customerId;
    if (typeof id == "undefined" || id === "" || id === null) {
        return res.status(500).json("the values sent may be undefined null or empty");
    }
    db.collection("Customers").removeOne({ "_id": mongo.ObjectID(id) }, function(err, result) {
        if (err) {
            console.log("Error in deleteCustomer : " + err);
            return res.status(500).json("Internal Server Error: Error in deleting customer");
        } else {
            console.log("No Error in  deleteCustomer : ");
            return res.status(200).json("customer deleted Successfully ");
        }
    });


});

router.post('/addNewApplicationAdmin', function(req, res) {
    var applicationName = "";
    applicationName = req.body.applicationName;
    var lob = req.body.lob;
    var id = req.query.customerId;
    if (typeof applicationName == "undefined" || applicationName === null || applicationName === "" || typeof lob == "undefined" || lob === null || lob === "" || typeof id == "undefined" || id === "" || id === null) {
        return res.status(500).json("the values sent may be undefined null or empty");
    }
    if (applicationName !== applicationName.toLowerCase()) {
        return res.status(500).json("application Name should be in lower case");
    }
    if (applicationName !== applicationName.replace(/\s/g, "")) {
        return res.status(500).json("application Name should not have spaces");
    }
    db.collection("Customers").update({ "_id": mongo.ObjectID(id) }, { $push: { application: { $each: [{ "appid": new ObjectID(), "applicationName": applicationName, "lob": lob, "scripts": [] }] } } }, function(err, result) {
        if (err) {
            console.log("Error in applicationNames : " + err);
            return res.status(500).json("Internal Error: Error in adding application");
        } else {
            console.log("No Error in  applicationNames : ");

            //Now create an index in ElasticSearch
            elasticClient.index({
                index: applicationName,
                type: "_doc",
                body: {}
            }).then(function(x) {
                    console.log(x);
                    return res.status(200).json("added application Successfully");
                },
                function(err) {
                    console.log(err);
                    // return res.status(500).json(err);
                    return res.status(500).json("Internal Server Error: Error in adding application");
                });


        }
    });
});


router.post('/updateApplicationAdmin', function(req, res) {
    var id = req.query.customerId;
    var applicationId = req.query.applicationId;
    var applicationName = req.body.applicationName;
    var lob = req.body.lob;
    if (typeof id == "undefined" || id === "" || id === null || typeof applicationName == "undefined" || applicationName === null || typeof applicationId == "undefined" || applicationId === null || applicationId === "" || typeof lob == "undefined" || lob === null || lob === "") {
        return res.status(500).json("the values sent may be undefined null or empty");
    }
    db.collection("Customers").update({ "_id": mongo.ObjectID(id), "application.appid": mongo.ObjectID(applicationId) }, { "$set": { "application.$[a].applicationName": applicationName, "application.$[a].lob": lob } }, { arrayFilters: [{ "a.appid": mongo.ObjectId(applicationId) }] }, function(err, result) {
        if (err) {
            console.log("Error in updateApplicationAdmin : " + err);
            return res.status(500).json("Internal Server Error: Error in updating application");
        } else {
            console.log("No Error in  updateApplicationAdmin : ");
            return res.status(200).json("updated application Successfully");
        }
    });
});



router.delete('/deleteApplicationAdmin', function(req, res) {
    var id = req.query.customerId;
    var applicationId = req.query.applicationId;
    if (typeof id == "undefined" || id === "" || id === null || typeof applicationId == "undefined" || applicationId === null || applicationId === "") {
        return res.status(500).json("the values sent may be undefined null or empty");
    }
    db.collection("Customers").update({ "_id": mongo.ObjectID(id), "application.appid": mongo.ObjectID(applicationId) }, { "$pull": { "application": { "appid": mongo.ObjectID(applicationId) } } }, function(err, result) {
        if (err) {
            console.log("Error in deleteApplication : " + err);
            return res.status(500).json("Internal Server Error: Error in deleting application");
        } else {
            console.log("No Error in  deleteApplication : ");
            return res.status(200).json("application deleted Successfully ");
        }
    });
});


router.post('/addNewUser', function(req, res) {
    var pass = config.defaultUserPassword; //  we  have  to update  deafault password in config file
    var userName = req.body.userName;
    var emailId = req.body.emailId;
    var customerName = req.body.customerName;
    var id = req.query.customerId;
    if (typeof pass == "undefined" || pass === "" || pass === null || typeof userName == "undefined" || userName === "" || userName === null || typeof emailId == "undefined" || emailId === "" || emailId === null || typeof customerName == "undefined" || customerName === "" || customerName === null || typeof id == "undefined" || id === "" || id === null) {
        return res.status(500).json("the values sent may be undefined null or empty");
    }
    const password = bcrypt.hashSync(pass, saltRounds);
    db.collection("users").insertOne({
        "userName": userName,
        "emailId": emailId,
        "password": password,
        "customerName": customerName,
        "customerId": mongo.ObjectID(id)
    }, function(err, result) {
        if (err) {
            console.log("Error in addNewUsers : " + err);
            return res.status(500).json("Internal Server Error: Error in adding user");
        } else {
            console.log("No Error in  addNewUsers : ");
            return res.status(200).json("added users Successfully");
        }
    });
});



router.post('/updateUser', function(req, res) {
    console.log("inside new updateUser");
    var userId = req.query.userId;
    var userName = req.body.userName;
    var emailId = req.body.emailId;
    if (typeof userName == "undefined" || userName === "" || userName === null || typeof emailId == "undefined" || emailId === "" || emailId === null || typeof userId == "undefined" || userId === "" || userId === null) {
        return res.status(500).json("the values sent may be undefined null or empty");
    }
    db.collection("users").updateOne({ "_id": mongo.ObjectID(userId) }, {
        "$set": {
            "userName": userName,
            "emailId": emailId
        }
    }, function(err, result) {
        if (err) {
            console.log("Error in updateUser : " + err);
            return res.status(500).json("Internal Server Error: Error in updating user");
        } else {
            console.log("No Error in  updateUser : ");
            return res.status(200).json("updated users Successfully");
        }
    })
});

router.post('/updateUserPassword', function(req, res) {
    var pass = req.body.password;
    var userId = req.query.userId;
    console.log("inside new updateUserPassword");
    if (typeof pass == "undefined" || pass === "" || pass === null || typeof userId == "undefined" || userId === "" || userId === null) {
        return res.status(500).json("the values sent may be undefined null or empty");
    }

    const password = bcrypt.hashSync(pass, saltRounds);
    db.collection("users").updateOne({ "_id": mongo.ObjectID(userId) }, {
        "$set": {
            "password": password
        }
    }, function(err, result) {
        if (err) {
            console.log("Error in updateUserPassword : " + err);
            return res.status(500).json("Internal Server Error: Error in updating user password");
        } else {
            console.log("No Error in  updateUser : ");
            return res.status(200).json("updated password Successfully");
        }
    })
});

router.delete('/deleteUser', function(req, res) {
    console.log("inside deleteUser");
    var userId = req.query.userId;
    if (typeof userId == "undefined" || userId === "" || userId === null) {
        return res.status(500).json("the values sent may be undefined null or empty");
    }
    db.collection("users").removeOne({ "_id": mongo.ObjectID(userId) }, function(err, result) {
        if (err) {
            console.log("Error in deleteApplication : " + err);
            return res.status(500).json("Internal Server Error: Error in deleting user");
        } else {
            console.log("No Error in  deleteUser : ");
            return res.status(200).json("User deleted Successfully ");
        }
    })
});


router.get('/getUserDetails', function(req, res) {
    console.log("inside getUserDetails");
    var customerId = req.query.customerId;
    if (typeof customerId == "undefined" || customerId === "" || customerId === null) {
        return res.status(500).json("the values sent may be undefined null or empty");
    }
    db.collection("users").find({ "customerId": mongo.ObjectID(customerId) }).toArray((err, result) => {
        if (err) {
            console.log("Error in User detail module : " + err);
            return res.status(500).json("Internal Server Error: Error in displaying user details");
        } else {
            console.log("Result  " + result);
            return res.status(200).json(result);
        }
    });
});

module.exports = router;