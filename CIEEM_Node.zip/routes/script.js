var config = require('../configuration.json');
//require express library
var express = require('express');
//require the express router
var router = express.Router();
var app = express();
//require multer for the file uploads
var multer = require('multer');
// set the directory for the uploads to the uploaded to
var DIR = 'uploads/';
var mongo = require('mongodb');
var bodyParser = require('body-parser');
var fs = require('fs');
var path = require('path');
var replaceall = require("replaceall");
var parse = require("./parse.js");
app.use(bodyParser.json({ limit: '100mb' }));
app.use(bodyParser.urlencoded({ limit: '100mb', extended: false }));

let ObjectID = mongo.ObjectID;
let db;
mongo.connect(config.mongoDBURL, function (err, mongoDB) {
    db = mongoDB.db();
    console.log("Connected to MongoDB - script.js");
});


var storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, config.tempftpPath)
    },
    filename: function (req, file, cb) {
        var fname = file.originalname;
        var regexAll = /^([^\\]*)\.(\w+)$/;
        var temp1, temp2;
        temp1 = fname.split(".");
        var total = fname.split(fname.lastIndexOf("."));
        var filename = total[0];
        var extension = total[1];
        cb(null, temp1[0] + "_" + Date.now() + "." + temp1[1]);
    }
});

//Get the list of indices. Each index is an application name for  home  page
router.get('/getApplicationList', function (req, res, next) {
    console.log('Decoded value : ' + JSON.stringify(req.decoded));
    var customerID = req.decoded.customerID;
    var customerName = req.decoded.customerName;
    console.log('customer ID : ' + customerID);
    if (customerID === null || typeof customerID == 'undefined' || customerID === "") {
        return res.status(500).json("the values sent may be undefined null or empty");
    }

    // var license = parse.parseFunc(customerName);
    // if (license === false) {
    //     console.log("License Invalid");
    //     return res.status(500).json("Your License is expired");
    // } else
    //     console.log("License valid");

    db.collection("Customers").find({ "_id": mongo.ObjectID(customerID) }).toArray((err, result) => {
        if (err) {
            console.log("Error in Customers detail module : " + err);
            return res.status(500).json("Internal Server Error: Error in getting application list");
        } else {
            console.log('after querying customer document : ' + JSON.stringify(result));
            var applicationsNames = [];
            var applicationJSONArray = result[0].application;
            for (var i = 0; i < applicationJSONArray.length; i++) {
                var tempEntry = {
                    "applicationName": applicationJSONArray[i].applicationName,
                    "appid": applicationJSONArray[i].appid
                };
                applicationsNames.push(tempEntry);
            }
            var customerDoc = {
                "customerID": customerID,
                "applications": applicationsNames,
                "type": "valid"
            };
            console.log("Result  " + JSON.stringify(customerDoc));

            return res.status(200).json(customerDoc);
        }
    });
});


router.post('/addScripts', function (req, res) {
    var upload = multer({
        storage: storage,
        fileFilter: function (req, file, callback) {
            // path.endsWith(".jar")
            console.log("path" + path + "\n" + "file.originalname" + file.originalname);
            // var ext = path.extname(file.originalname);

            // if (ext !== '.jar') {
            if (!(file.originalname.endsWith(".jar")) && !(file.originalname.endsWith(".zip"))) {
                return callback(new Error("Only JAR/ZIP files allowed"))
            }
            callback(null, true)
        }
    }).single('photo');
    var path = '';
    upload(req, res, function (err) {
        if (err) {
            // An error occurred when uploading
            console.log(err);
            return res.status(422).send("" + err);
        } else {
            var id = req.decoded.customerID;
            var applicationId = req.query.applicationId;
            var customerName = req.body.customerName;
            var applicationName = req.body.applicationName;
            //Check if customer folder exists - if not create it
            var folderName = config.ftpPath + customerName;
            if (!fs.existsSync(folderName)) {
                fs.mkdirSync(folderName);
                //console.log('Folder ' + folderName + ' was created!');
            } else {
                //console.log('fs check  1 : ' + folderName + 'folder already exists');
            }

            folderName = folderName + "/" + applicationName;
            if (!fs.existsSync(folderName)) {
                fs.mkdirSync(folderName);
                //console.log('Folder ' + folderName + ' was created!');
            } else {
                //console.log('fs check  2 : ' + folderName + 'folder already exists');
            }

            //Check if application folder exists - if not create it

            //Move the file from C:\synmon\ftp\Temp to the appropriate customer \application name folder
            fs.copyFileSync(config.tempftpPath + req.file.filename, folderName + '/' + req.file.filename, function (err) {
                if (err) {
                    console.error(err);
                } else {
                    //console.log('File moved');
                }

                //res.json({});

            });
            console.log("uploaded file");
            if (typeof id == "undefined" || id === "" || id === null || typeof applicationId == "undefined" || applicationId === "" || applicationId === null || typeof req.file == "undefined") {
                return res.status(500).json("the values sent may be undefined null or empty");
            }
            var ftpPath = "/" + customerName + "/" + applicationName + "/" + req.file.filename;
            let transaction = {};

            if (req.body.transaction != undefined) {
                transaction = JSON.parse(req.body.transaction);
            }

            var saveObj = {
                "scriptid": new ObjectID(),
                "scriptname": req.file.originalname,
                "scriptversion": req.file.filename,
                "file_location": ftpPath,
                "regions": req.body.regions,
                "scripttype": req.body.scripttype,
                //"fulllocationname": req.body.fulllocationname,
                "monitoring_interval": Number(req.body.interval),
                "status": "Stopped",
                "transaction": transaction //req.body.transaction
            }
            db.collection("Customers").update({ "_id": mongo.ObjectID(id), "application.appid": mongo.ObjectID(applicationId) }, { "$push": { "application.$.scripts": saveObj } }, function (err, result) {
                if (err) {
                    console.log("Error in newScripts : " + err);
                    return res.status(500).json("Internal Server Error: Error in adding scripts");
                } else {
                    console.log("No Error in  applicationNames : ");
                    return res.status(200).json("script added Successfully ");
                }
            })
        }
    });
});


router.post('/addScriptDesignData', function (req, res) {
    console.log(" INSIDE      /addNewScriptingData");
    console.log(JSON.stringify(req.body));
    console.log(JSON.stringify(req.body.scriptname));
    var applicationId = req.query.applicationId;
    var id = req.decoded.customerID;
    if (typeof id == "undefined" || id === "" || id === null || typeof applicationId == "undefined" || applicationId === "" || applicationId === null) {
        console.log("applicationId customer Id is null")
        return res.status(500).json("the values sent may be undefined null or empty");
    }
    var transaction = req.body.transaction;
    if (typeof transaction == undefined) {
        console.log("atransaction is undefined")
        return res.status(500).json("the values sent may be undefined null or empty");
    }
    for (let i = 0; i < transaction.length; i++) {
        console.log(JSON.stringify(transaction[i]));
    }
    var saveObj = {
        "scriptid": new ObjectID(),
        "scriptname": req.body.scriptname,
        "regions": req.body.regions,
        "monitoring_interval": parseInt(req.body.interval),
        "status": "Stopped",
        "scripttype": req.body.scripttype,
        "transaction": transaction
    }
    var isvalidObj = saveObjValidation(saveObj);
    console.log("IsvalidObject : " + isvalidObj);
    if (isvalidObj === true) {
        console.log(JSON.stringify(saveObj));
        db.collection("Customers").updateOne({ "_id": mongo.ObjectID(id), "application.appid": mongo.ObjectID(applicationId) }, { "$push": { "application.$.scripts": saveObj } }, function (err, result) {
            if (err) {
                return res.status(500).json("Internal Server Error: Error in adding script design data");
            } else {
                return res.status(200).json("Scripting data added Successfully ");
            }
        });

    } else {
        return res.status(500).json("the values sent may be undefined null or empty");
    }

});


router.post('/updateScriptDesignData', function (req, res) {
    console.log("/updateScriptDesignData");
    var transaction = req.body.transaction;
    transaction.forEach(function (value) {
        if (value.transid == undefined)
            value.transid = new ObjectID();
    });
    console.log(JSON.stringify(transaction));
    var saveObj = {
        "scriptid": new ObjectID(req.query.scriptId),
        "scriptname": req.body.scriptname,
        "regions": req.body.regions,
        "monitoring_interval": parseInt(req.body.interval),
        "status": "Stopped",
        "scripttype": req.body.scripttype,
        "transaction": transaction
    }
    let isvalidObj = saveObjValidation(saveObj);
    console.log("IsvalidObject : " + isvalidObj);
    if (isvalidObj) {
        console.log(JSON.stringify(saveObj));
        db.collection("Customers").updateOne({ "_id": mongo.ObjectID(req.decoded.customerID), "application.appid": mongo.ObjectID(req.query.applicationId) },
            {
                $set: {
                    "application.$[a].scripts.$[s].scriptid": saveObj.scriptid,
                    "application.$[a].scripts.$[s].scriptname": saveObj.scriptname,
                    "application.$[a].scripts.$[s].regions": saveObj.regions,
                    "application.$[a].scripts.$[s].monitoring_interval": saveObj.monitoring_interval,
                    "application.$[a].scripts.$[s].status": saveObj.status,
                    "application.$[a].scripts.$[s].scripttype": saveObj.scripttype,
                    "application.$[a].scripts.$[s].transaction": saveObj.transaction,
                }
            }, { arrayFilters: [{ "a.appid": mongo.ObjectId(req.query.applicationId) }, { "s.scriptid": mongo.ObjectId(req.query.scriptId) }] },
            function (err, result) {
                if (err) {
                    return res.status(500).json("Internal Server Error: Error in updating script design");
                } else {
                    return res.status(200).json("Design script data updated successfully ");
                }
            });
    } else {
        return res.status(500).json("the values sent may be undefined null or empty");
    }
});




router.post('/updateExistingScript', function (req, res) {
    console.log("Inside updateExistingScript");
    var upload = multer({
        storage: storage,
        // fileFilter: function(req, file, callback) {
        //     var ext = path.extname(file.originalname);
        //     if (ext !== '.jar' || ext !== '.zip') {
        //         return callback(new Error("Only JAR/ZIP files allowed"))
        //     }
        //     callback(null, true)
        // }
    }).single('photo');
    upload(req, res, function (err) {
        if (err) {
            // An error occurred when uploading
            console.log(err);
            /* return res.status(422).send("Error : "+err); */
            return res.status(422).send("" + err);
        } else {
            var regions = req.body.regions;
            var monitoring_interval = parseInt(req.body.interval);
            var id = req.decoded.customerID;
            var applicationId = req.query.applicationId;
            var scriptId = req.query.scriptId;
            let transaction = {};
            if (req.body.transaction != undefined) {
                transaction = JSON.parse(req.body.transaction);
            }
            let scripttype = req.body.scripttype;
            if (typeof id == "undefined" || id === "" || id === null || typeof applicationId == "undefined" || applicationId === "" || applicationId === null || typeof req.file == "undefined") {
                return res.status(500).json("the values sent may be undefined null or empty")

            }
            // if (req.file !== undefined) {
            console.log("Inside if block");
            var scriptname = req.file.originalname;
            var file_location = req.file.path;
            var customerName = req.body.customerName;
            var applicationName = req.body.applicationName;
            //Check if customer folder exists - if not create it
            var folderName = config.ftpPath + customerName + "/" + applicationName;

            fs.copyFileSync('C:/SynMon/ftp/temp/' + req.file.filename, folderName + '/' + req.file.filename, function (err) {
                if (err) {
                    console.error(err);
                } else {
                    console.log("updated file in location : " + folderName + '/' + req.file.filename)
                    //console.log('File moved');
                }

                //res.json({});

            });

            //console.log("DEBUGGIN : " + customerName + ", " + applicationName + ", filename : " + req.file.filename);
            file_location = "/" + customerName + "/" + applicationName + "/" + req.file.filename;
            db.collection("Customers").update({ "_id": mongo.ObjectID(id), "application.appid": mongo.ObjectID(applicationId) }, {
                $set: {
                    "application.$[a].scripts.$[s].scriptname": scriptname,
                    "application.$[a].scripts.$[s].file_location": file_location,
                    "application.$[a].scripts.$[s].regions": regions,
                    "application.$[a].scripts.$[s].scripttype": scripttype,
                    "application.$[a].scripts.$[s].monitoring_interval": monitoring_interval,
                    "application.$[a].scripts.$[s].transaction": transaction
                }
            }, { arrayFilters: [{ "a.appid": mongo.ObjectId(applicationId) }, { "s.scriptid": mongo.ObjectId(scriptId) }] }, function (err, result) {
                if (err) {
                    console.log("Error in updateExistingScript : " + err);
                    return res.status(500).json("Internal Server Error: Error in updating the script");
                } else {
                    console.log("No Error in  updateExistingScript : ");
                    return res.status(200).json("updated script Successfully");
                }
            })
        }

    });
});

router.post('/updateExistingScriptWithoutFile', function (req, res) {
    var regions = req.body.regions;
    var interval = req.body.interval;
    var id = req.decoded.customerID;
    var applicationId = req.query.applicationId;
    var scriptId = req.query.scriptId;
    let transaction = {};
    if (req.body.transaction != undefined) {
        transaction = req.body.transaction;
    }
    let scripttype = req.body.scripttype;
    if (typeof regions == "undefined" || regions === "" || regions === null || typeof interval == "undefined" || interval === "" || interval === null || typeof id == "undefined" || id === "" || id === null || typeof applicationId == "undefined" || applicationId === "" || applicationId === null || typeof scriptId == "undefined" || scriptId === "" || scriptId === null) {
        return res.status(500).json("the values sent may be undefined null or empty");
    }
    db.collection("Customers").update({ "_id": mongo.ObjectID(id), "application.appid": mongo.ObjectID(applicationId) }, {
        $set: {
            "application.$[a].scripts.$[s].regions": regions,
            "application.$[a].scripts.$[s].scripttype": scripttype,
            "application.$[a].scripts.$[s].monitoring_interval": interval,
            "application.$[a].scripts.$[s].transaction": transaction
        }
    }, { arrayFilters: [{ "a.appid": mongo.ObjectId(applicationId) }, { "s.scriptid": mongo.ObjectId(scriptId) }] }, function (err, result) {
        if (err) {
            console.log("Error in updateExistingScriptWithoutFile : " + err);
            return res.status(500).json("Internal Server Error: Error in updating the script");
        } else {
            console.log("No Error in  updateExistingScriptWithoutFile : ");
            return res.status(200).json("updated script Successfully without file ");
        }
    });
});

router.post('/addAlertsForScripts', function (req, res) {
    var id = req.decoded.customerID;
    var applicationId = req.query.applicationId;
    var scriptId = req.query.scriptId;
    let transactionValue = {};
    console.log(req.body.recipients);
    // if (req.body.transactionValue.recipients != undefined) {
    transactionValue.recipients = req.body.recipients;
    transactionValue.alertsForTransaction = req.body.alertsForTransaction;
    //}

    if (typeof id == "undefined" || id === "" || id === null || typeof applicationId == "undefined" || applicationId === "" || applicationId === null || typeof scriptId == "undefined" || scriptId === "" || scriptId === null) {
        return res.status(500).json("the values sent may be undefined null or empty");
    }
    db.collection("Customers").update({ "_id": mongo.ObjectID(id), "application.appid": mongo.ObjectID(applicationId) }, {
        $set: {
            "application.$[a].scripts.$[s].transactionValue": transactionValue
        }
    }, { arrayFilters: [{ "a.appid": mongo.ObjectId(applicationId) }, { "s.scriptid": mongo.ObjectId(scriptId) }] }, function (err, result) {
        if (err) {
            console.log("Error in updating alerts : " + err);
            return res.status(500).json("Internal Server Error: Error in updating the alerts");
        } else {
            console.log("No Error in  updating alerts : ");
            return res.status(200).json("updated alerts Successfully   ");
        }
    });
});


router.delete('/deleteScript', function (req, res) {
    var id = req.decoded.customerID;
    var applicationId = req.query.applicationId;
    var scriptId = req.query.scriptId;
    if (typeof id == "undefined" || id === "" || id === null || typeof applicationId == "undefined" || applicationId === "" || applicationId === null || typeof scriptId == "undefined" || scriptId === "" || scriptId === null) {
        return res.status(500).json("the values sent may be undefined null or empty");
    }
    db.collection("Customers").update({ "_id": mongo.ObjectID(id), "application.appid": mongo.ObjectID(applicationId) }, { "$pull": { "application.$.scripts": { "scriptid": mongo.ObjectID(scriptId) } } }, function (err, result) {
        if (err) {
            console.log("Error in deleteScript : " + err);
            return res.status(500).json("Internal Server Error: Error in deleting the script");
        } else {
            console.log(result);
            console.log("No Error in  deleteScript : ");
            return res.status(200).json("deleted script Successfully ");
        }
    });
});





router.get('/regions', function (req, res) {
    db.collection("regions").find({}).toArray((err, result) => {
        if (err) {
            return res.status(500).json("Internal Server Error: Error in getting regions");
        } else {
            return res.status(200).json(result);
        }
    });

});

//will get both application and script details
router.get('/getCustomerDetails', function (req, res) {
    var id = req.decoded.customerID;
    console.log("id value is :   " + id);
    if (typeof id == "undefined" || id === "" || id === null) {
        return res.status(500).json("the values sent may be undefined null or empty");
    }
    db.collection("Customers").find({ "_id": mongo.ObjectID(id) }).toArray((err, result) => {
        if (err) {
            console.log("Error in Customers detail module : " + err);
            return res.status(500).json("Internal Server Error: Error in getting application and script details");
        } else {
            var data = [];
            var applications = [];
            if (result[0].application == undefined) {
                return res.status(500).json("Internal Server Error: Error in getting application and script details");
            }
            var applicationJSONArray = result[0].application;
            for (var i = 0; i < applicationJSONArray.length; i++) {
                for (var val of applicationJSONArray[i].scripts) {
                    if (val.status === "Stopped" || val.status === "Runnable") {
                        data.push(val);
                    }
                }
                var app = {
                    "appid": applicationJSONArray[i].appid,
                    "applicationName": applicationJSONArray[i].applicationName,
                    "scripts": data
                }
                data = [];
                applications.push(app)
            }

            var responseData = {};
            responseData.customerName = result[0].customerName;

            responseData.applications = applications;
            return res.status(200).json(responseData);
        }
    });
});

function saveObjValidation(saveObj) {
    if (saveObj.scriptname == null || typeof saveObj.scriptname == "undefined" || saveObj.scriptname === "") {
        return false;
    }
    if (saveObj.regions == null || typeof saveObj.regions == "undefined" || saveObj.regions === "") {
        return false;
    }
    if (saveObj.monitoring_interval == null || typeof saveObj.monitoring_interval == "undefined" || saveObj.monitoring_interval === "") {
        return false;
    }
    if (saveObj.status == null || typeof saveObj.status == "undefined" || saveObj.status === "") {
        return false;
    }
    if (saveObj.scripttype == null || typeof saveObj.scripttype == "undefined" || saveObj.scripttype === "") {
        return false;
    }
    saveObj.transaction.forEach(function (value) {
        if (typeof value.transactionName == "undefined" || value.transactionName == null || value.transactionName === "" || typeof value.sla == undefined || value.sla == null || value.sla === "" || value.methods == "undefined" || value.methods == null || value.methods === "" || typeof value.navigate == undefined || value.navigate == null || value.navigate === "") {
            return false;
        }
    });

    return true;
}


//Get Application Name
router.get('/getApplicationNameByID', function (req, res, next) {
    res.header("Strict-Transport-Security", "max-age=604800"); // 1 week in seconds   
    res.header('Cache-Control', 'private, no-cache, no-store, must-revalidate');
    console.log("-----getApplicationNameByID------");
    var customerID = req.decoded.customerID;
    if (customerID === null || customerID === undefined || customerID === "") {
        return res.status(404).json("Token is not valid");
    }
    var appID = req.query.applicationId;
    var bsonCustomerID = mongo.ObjectID(customerID);
    var bsonappID = mongo.ObjectID(appID);
    console.log("appID: " + appID);
    //"customerId": bsonCustomerID 
    db.collection("Customers").find({ "_id": bsonCustomerID }).project({ "application.appid": 1, "application.applicationName": 1, }).toArray((err, result) => {
        if (err) {
            console.log("Error in getApplicationListByCID : " + err);
            return res.status(500).json(err);
        } else {
            console.log("Result  " + JSON.stringify(result[0].application));
            let apps = [];
            apps = apps.concat(JSON.parse(JSON.stringify(result[0].application)));
            let app = apps.filter(app => app.appid === appID);

            return res.status(200).json(app[0].applicationName);
        }
    });
});//end of //getApplicationName

module.exports = router;