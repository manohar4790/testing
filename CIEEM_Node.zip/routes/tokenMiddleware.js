var jwt = require('jsonwebtoken');
var config = require('../configuration.json');

module.exports = function(req, res, next) {
    var authorization = req.headers['authorization'];

    var token = '';
    if (typeof authorization !== 'undefined') {
        const bearer = authorization.split(' ');
        token = bearer[1];
    } else {
        //If header is undefined return Forbidden (403)
        return res.status(403).send({
            "error": true,
            "message": "Forbidden - No token found"
        });
    }
    if (token) {
        // verifies secret and checks exp
        jwt.verify(token, config.bcryptSecretKey, function(err, decoded) {
            if (err) { //failed verification.
                return res.status(403).send({
                    "error": true,
                    "message": err.message
                });
            }
            req.decoded = decoded;
            next(); //no error, proceed
        });
    } else {
        // forbidden without token
        return res.status(403).send({
            "error": true,
            "message": "Forbidden - No token found"
        });
    }
}