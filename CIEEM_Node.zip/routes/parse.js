const licenseFile = require('nodejs-license-file');
var template = require('./template.js');
var exportObj=require('./license.js');
var should = require('should');
var datetime = require('node-datetime');
// const request = require('request');

function parseFunc(customerName) {
    try {
        // customerName="Be Cognizant";
        const data = licenseFile.parse({
            publicKeyPath: './routes/public.pem',
            licenseFilePath: './CustomerLicenses/'+customerName+'.lic',
         template
        });
        Object.keys(data).should.deepEqual(['valid', 'serial', 'data']);
        Object.keys(data.data).should.deepEqual(['customername', 'expirationDate']);
        try {
            console.log("Inside try block");
            // if(!data.data.expirationDate.should.be.greater(present)){
            //     data.valid=false;
            // request('http://www.epochconverter.com/', (err, res, body) => {
            //     if (err) { return console.log(err); }
            //     var date = res.headers['date'];
            //     present = new Date(date).getTime();
            var presentDate = new Date().getTime();
            
            console.log("Present date====" + presentDate + " type of " + typeof (presentDate))
            var expirationDate = new Date(data.data.expirationDate).getTime()
            if (presentDate > expirationDate || !data.data.customername.should.be.eql(customerName)) {
                //!data.serial.should.be.eql("iEYccTSC4tUE9x74GdhB3h3WufU11QRWGaRK0+3KsLgtUbxa20vSQ2YItTu97Rvq2aRBxPBTVCOJ/h2sMvNso1/cGaC3OU7RI7ktHAecO9QVfcEsGYkwcD9cEg347RpE1PVv2cENqAD8tRnm2emeuuVrDKLU6P2QwF3hEF7/WHNxsUAZVYmGfF9Jbn6qSqJ4TGq9f81Ui0NKcdRjArSFoTdCuy3CBa11MDV+1gfuxeQ3OF1ibksR7OzNGR+F2xm4kx3XcG7dhTXdhke7jx4izkfMob+zZpkRNR4TpvQOB7MklyHu1Z0lWPh57UIcGeXWpppNtEjzyKAH4OjaXYxd4Q==")
                data.valid = false;
                console.log("data\n" + JSON.stringify(data));
            }
            return(data.valid);
            // });
        }
        catch (e) {

            console.log("Error: " + e);
        }

        //    data.valid.should.not.be.ok();


        // done(); 

    } catch (err) {

        console.log(err);
    }

}
// parseFunc("Be Cognizant");
module.exports.parseFunc=parseFunc;