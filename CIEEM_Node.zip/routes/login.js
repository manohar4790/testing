var config = require('../configuration.json');
var express = require('express');
//require the express router
var multer = require('multer');
let validationRoute = require('./validation.js');
var router = express.Router();
var app = express();
var mongo = require('mongodb');
var bodyParser = require('body-parser');
var jwt = require('jsonwebtoken');
const bcrypt = require('bcrypt');
const saltRounds = 10;

let db;
mongo.connect(config.mongoDBURL, function(err, mongoDB) {
    db = mongoDB.db();
    console.log("Connected to MongoDB - login.js");
});

router.post('/login', function(req, res) {
    const emailId = req.body.email;
    const password = req.body.password;
    if (typeof emailId == "undefined" || emailId == "" || typeof password == "undefined" || password == "" || emailId === null || password === null || validationRoute(emailId)) {
        res.status(401).json("Invalid credentials, please check");
    } else {
        //console.log("email   ", emailId);
        //console.log("password   ", password);
        db.collection("users").findOne({ "emailId": emailId }, function(err, result) {
            if (err) {
                return res.status(500).json("Invalid credentials, please check");
                //next(err);
            }

            if (result) {
                if (bcrypt.compareSync(password, result.password)) {
                    let role = result.role;
                    if (role === null || role === undefined || role === "") {
                        role = "user";
                    }
                    const token = jwt.sign({ id: result._id, customerID: result.customerId, customerName: result.customerName, role: role }, config.bcryptSecretKey, { expiresIn: config.tokenExpiryTime });
                    console.log("result._id  ", result._id);
                    /** assign our jwt to the cookie */
                    res.cookie('jwt', jwt, { httpOnly: true, secure: true });
                    res.json({
                        "data": {
                            "token": token,
                            "userName": result.userName,
                            "emailID": result.emailId,
                        }
                    });

                    //res.status(200).json(token);
                } else {
                    res.status(401).json("Invalid credentials, please check");
                }
            } else {
                res.status(401).json("Invalid credentials, please check");
            }

        });
    }
});

module.exports = router;