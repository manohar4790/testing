var Influx = require('influx');
var config = require('../configuration.json');
var express = require('express');
var router = express.Router();
var Request = require("request");
var worker=require("./worker.js");

var mongo = require('mongodb');
let mongodb;
mongo.connect(config.mongoDBURL, function (err, mDB) {
    mongodb = mDB.db();
    console.log("Connected to MongoDB - worker.js");
});

var elasticsearch = require('elasticsearch');
var elasticClient = new elasticsearch.Client({
    //host: 'http://18.219.74.14:9200',
    host: 'http://' + config.elasticsearchDBHost + ':9200'//,
   // log: 'trace'
});

elasticClient.ping({
    requestTimeout: 30000,
}, function(error) {
    if (error) {
        console.error('elasticsearch cluster is down! - seleniumAPI.js');
    } else {
        console.log('Success : Connection to ElasticSearch DB is fine! - seleniumAPI.js');
    }
});
var influx = new Influx.InfluxDB({
    host: config.influxDBURL,
    //host: 'localhost:8086', config
    //port:8086,
    database: 'synmonsample',
    schema: [{
        measurement: 'sample',
        fields: {
            region: Influx.FieldType.STRING,
            status: Influx.FieldType.STRING,
            responsetime: Influx.FieldType.INTEGER,
            post_date: Influx.FieldType.STRING,
            sla: Influx.FieldType.INTEGER,
            applicationName: Influx.FieldType.STRING,
        },
        tags: [
            'host',
            'transaction',
        ]
    }]
})

//Insert json into the ElasticSearch
router.post('/insertNewSample', function(req, res, next) {

    var json = req.body;
    var transaction = json.transaction;
    var applicationName = json.application;
    var region = json.region;
    var transactionStatus = json.status;
    var responsetime = json.responsetime;
    var sla = json.sla;
    var post_date = json.post_date;
    var customerId=json.customerID;
    let scriptID=json.scriptID;
    var component = "activemonitor";
    var op = "decrement";
    var users = 0;
    var parJson = {
        "email": config.email,
        "password": config.password
    }
    Request.post({url: config.PerfAssureUrl + "/login/login",json: true,body: parJson},
    (errors, response, body) => { if (errors) {
         console.error(errors);
         return res.status(500).json(errors);
     } else {
         //console.log(body.data.token);
         var token =body.data.token;
         Request.get({
             url: config.PerfAssureUrl + "/license/LicenseValidatorApi?component=" + component + "&users=" + users + "&op=" + op+"&customerId="+customerId,
             headers: { 'Authorization': 'Bearer ' + body.data.token }
         }, async function  (error, response, body){ if (error) {
                 console.error(error);
                 return res.status(500).json(error);
             } else {
                 console.log("decrement response in Active Monitor  Validation");
                 var jsonObj=JSON.parse(body);
                 console.log(jsonObj);
                 if(!jsonObj.license){  
                    try {
                        console.log(" scriptID  : " +scriptID);
                      //  if (scriptID) { 
                          var checkStopStatus= await  StoppingScripts(scriptID);
                          console.log(checkStopStatus);
                          if(checkStopStatus.status)
                          {
                            return res.status(200).json({status: checkStopStatus.message});
                         }
                       // }
                    } catch (error) {
                        console.log("Error in stopscript " + error);
                        return res.status(500).json(error);
                
                    }
                 } else{
                     console.log(" insert  data to ES");
                    elasticClient.index({
                        index: applicationName,
                        type: '_doc',
                        body: json
                    }, function(err, response, status) {
                        if (err) {
                            console.log("search error in insertnewsample : " + err)
                            return res.status(500).json(err);
                
                        } else {
                            console.log("response in node insertnewsample\n" + JSON.stringify(response));
                           return res.status(200).json(response);
                        }
                    });
                 }
          
            }
         });
     }
 });
});

function StoppingScripts(scriptId) {
    return new Promise(function (resolve, reject) {
        try{
        mongodb.collection("scheduling_table").findOne({ "scriptid": mongo.ObjectID(scriptId)}, function (err, result) {
            if (err) {
                console.log("Error in getting doc scheduling_table : " + err);
                reject("Internal Server Error: Error in getting document from  scheduling_table");
            } else {
                console.log("No Error in getting doc scheduling_table : ");
                console.log(result);  //  edited  one
                let orginalScript = result;
                Request.get("http://" + config.actionControllerHost + ":8080/ActionController/rest/stopscript/" + result._id, (error, response, body) => {
                    if (error) {
                        console.error(error);
                        reject(error);
                    }
                    console.log(body); // "Script scheduling stopped"

                    if (body === "Script scheduling stopped" || body === "Script reference not found - It is already stopped or deleted") {
                        mongodb.collection("scheduling_table").removeOne({ "scriptid": mongo.ObjectID(scriptId) }, function (err, result) {
                            if (err) {
                                reject("Error in deleting script");
                            } else {
                                console.log("Deleted scheduling script");
                                mongodb.collection("Customers").update({ "_id": mongo.ObjectID(orginalScript.customerid), "application.appid": mongo.ObjectID(orginalScript.appid) }, { $set: { "application.$[a].scripts.$[s].status": "Stopped" } }, { arrayFilters: [{ "a.appid": mongo.ObjectId(orginalScript.appid) }, { "s.scriptid": mongo.ObjectId(orginalScript.scriptid) }] }, function (err, result) {
                                    if (err) {
                                        console.log("Error in updating status : " + err);
                                        reject("Error in updating status in Customer Collection");
                                    } else {
                                        console.log("Updated script status as Stopped");
                                        resolve({ "status": true, "message": "Script scheduling stopped" });
                                        //return res.status(200).json("updated script status as Runnable");
                                        // return res.status(200).json({
                                        //     status: "Script scheduling stopped"
                                        // });
                                    }
                                })
                                //return res.status(200).json("no error in deleteScriptingData");
                            }
                        });
                    } else {
                        reject(body);
                    }
                });
            }
        });
    }catch( error){
        console.log(error);
    }
    });
}
  // influx.writePoints([{
            //     measurement: 'sample',
            //     //tags: { host: "localhost" },
            //     tags: { transaction: transaction },
            //     fields: { region: region, status: transactionStatus, responsetime: responsetime, post_date: post_date, sla: sla, applicationName: applicationName },
            // }]).then(() => {
            //     return influx.query(`
            //       select * from sample limit 5
            //     `)
            // }).then(rows => {
            //     rows.forEach(row =>
            //         console.log(" Transaction Name : " + row.transaction + " Application Name : " + row.applicationName + " Region : " +
            //             row.region + " Status : " + row.status + " Response Time : " + row.responsetime + " Date : " + row.post_date)
            //     )
            // }).catch(error => {
            //     console.log(error);
            //     console.error("Error saving data to InfluxDB! ")
            // });


//Insert Log in ElasticSearch
router.post('/addSeleniumLog', function(req, res, next) {
    var transcation_id = req.body.transcation_id;
    var log = req.body.log;
    var post_date = req.body.post_date;

    console.log(JSON.stringify(req.body));

    elasticClient.index({
        index: 'seleniumlog',
        type: 'doc',
        body: {
            "transcation_id": String(transcation_id),
            "message": String(log),
            "post_date": String(post_date),
            "timestamp": new Date(),
        },
        refresh: true
    }, function(err, resp, status) {
        console.log(resp);
        if (err) {
            //console.log("search error: " + error)
            return res.status(500).json(err);
        } else {
            return res.status(200).json(resp);
        }
    });
});


module.exports = influx;

module.exports = router;