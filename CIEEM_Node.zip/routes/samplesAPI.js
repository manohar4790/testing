var config = require('../configuration.json');
var express = require('express');
var router = express.Router();
const Influx = require('influx');
var mongo = require('mongodb');
//var HashMap = require('hashmap');
//var fs = require('fs');
//var csv = require('csv-parse');
//var dataformat = require("date-format-lite");
//var async = require('async');
//var S = require('string');
//var SecondsTohhmmss = require('../rules/utilMethods.js');
var getCoordinates = require('./mapCoordinates.js');

var elasticsearch = require('elasticsearch');
var elasticClient = new elasticsearch.Client({
    host: 'http://' + config.elasticsearchDBHost + ':9200',
    log: 'trace'
});

elasticClient.ping({
    requestTimeout: 30000,
}, function(error) {
    if (error) {
        console.error('elasticsearch cluster is down! - sampleAPI.js');
    } else {
        console.log('Success : Connection to ElasticSearch DB is fine! - sampleAPI.js');
    }
});

let ObjectID = mongo.ObjectID;
let db;
mongo.connect(config.mongoDBURL, function(err, mongoDB) {
    db = mongoDB.db();
    console.log("Connected to MongoDB - samplesAPI.js");
});

//with sla
router.get('/getTransactionSummary', async function(req, res, next) {
    var appName = req.query.appName;
    var gteString = req.query.gteString; //"now-1h"
    var lteString = req.query.lteString; //"now"
    let customerID = req.decoded.customerID;
    await elasticClient.search({
        index: appName,
        body: {
            "query": {
                "range": {
                    "post_date": {
                        "gte": gteString,
                        "lt": lteString
                    }
                }
            },
            "size": 0,
            "aggs": {
                "transaction_summary": {
                    "terms": { "field": "transaction.keyword",
                    "size": 50 },
                    "aggregations": {
                        "transactionaverage": {
                            "avg": { "field": "responsetime" },
                            
                        }
                    }
                }
            }
        }
    }).then(async function(resp) {
        var hits = resp.aggregations.transaction_summary.buckets;
        var transactionSummary = [];
        var storeSla = 0;
        let CustomerDocResult = await getCustomerDoc(customerID);

        //console.log(" hit  length " + hits.length);
        for (var i = 0; i < hits.length; i++) {
            //console.log(" iteration inside hits " + i);
            var hit = hits[i];
            var avgVal = hit.transactionaverage.value.toFixed(1);
            var transaction = hit.key;
            //console.log("respponse from elastic : " + JSON.stringify(resp));

            //console.log("appName**** - " + appName + " transaction*** - " + transaction);
            var applicationJSONArray = CustomerDocResult[0].application; //all apps
            applicationLoop: for (var j = 0; j < applicationJSONArray.length; j++) {
                    if (applicationJSONArray[j].applicationName === appName) {
                        scriptLoop: for (let scriptArray of applicationJSONArray[j].scripts) {
                            if (scriptArray.transaction != undefined) {
                                if (scriptArray.transaction instanceof Array) {
                                    for (let transactionArray of scriptArray.transaction) {
                                        if (transactionArray.transactionName === transaction) {
                                            storeSla = transactionArray.sla;
                                            console.log("storesla" + storeSla);
                                            break applicationLoop;
                                        }
                                    }
                                }
                                if (typeof scriptArray.transaction === 'object') {
                                    if (scriptArray.transaction.hasOwnProperty('slaForResponseTime')) {
                                        for (let transactionArray of scriptArray.transaction.slaForResponseTime) {
                                            if (transactionArray.transactionName === transaction) {
                                                storeSla = transactionArray.sla;
                                                console.log("storesla" + storeSla);
                                                break applicationLoop;
                                            }
                                        }
                                    }
                                }
                            }
                        }

                    }
                }
                //var sla;
            var slastatus = true;
            var status;
            /*  if (storeSla == 0)
                 sla = 3000;
             else
                 sla = storeSla; */

            if (avgVal < storeSla) {
                status = "green";
            } else if (storeSla == 0) {
                status = "grey";
            } else {
                status = "red";
                slastatus = false;
            }
            var availability;
            try {
                availability = await getTransactionAvailability(appName, transaction, gteString, lteString);
                //console.log(availability);
            } catch (error) {
                console.log(error);
                availability = error;
            }
            var entry = {
                "transaction": hit.key,
                "count": hit.doc_count,
                "average": avgVal,
                "sla": storeSla,
                "slastatus": slastatus,
                "status": status,
                "availability":Math.round(availability)
            };

            transactionSummary.push(entry);
        }
        return res.status(200).json(transactionSummary);
    }, function(err) {

        console.log(err.message);
        return res.status(200).json([]);
    });
});

function getTransactionAvailability(appName, transactionName, gteString, lteString) {
    return new Promise(function (resolve, reject) {
        elasticClient.search({
            index: appName,
            body: {
                "query": {
                    "bool": {
                        "must": [
                            { "match": { "transaction.keyword": transactionName } }
                        ],
                        "filter": [{
                            "range": {
                                "post_date": {
                                    "gte": gteString,
                                    "lt": lteString
                                }
                            }
                        }]
                    }
                },
                "size": 0,
                "aggs": {
                    "status_summary": {
                        "composite": {
                            "sources": [
                                { "txStatus": { "terms": { "field": "status.keyword" } } }
                            ]
                        },
                        "aggregations": {
                            "statusCount": {
                                "value_count": { "field": "status.keyword" }
                            }
                        }
                    }
                }
            }
        }).then(function (resp) {
            var hits = resp.aggregations.status_summary.buckets;
            var passvalue = 0;
            var failvalue = 0;
            var totalavailable = 0;
            for (var i = 0; i < hits.length; i++) {
                var hit = hits[i];
                var countVal = hit.statusCount.value;
                var statusString = hit.key.txStatus.toLowerCase();

                switch (statusString.toLowerCase()) {
                    case "pass": { passvalue = countVal + passvalue; break; }
                    case "fail": { failvalue = countVal + failvalue; break; }
                    case "fail-transactiontimeout": { failvalue = countVal + failvalue; break }
                    case "fail-incorrectresult": { failvalue = countVal + failvalue; break }
                }

            }
            if (passvalue != 0) {
                var total = passvalue + failvalue;
                totalavailable = ((passvalue / total) * 100).toFixed(2);
            }
            else
                totalavailable = 0;
            resolve(totalavailable);
        }, function (err) {
            reject("NA");
        });
    });
}


function getCustomerDoc(customerID) {
    return new Promise(function(resolve, reject) {
        console.log("inside getCustomerDoc function");
        db.collection("Customers").find({ "_id": mongo.ObjectID(customerID) }).toArray((err, result) => {
            resolve(result);
        });
    });
}

//------------------------//
router.get('/getTransactionResponsetimeByInterval', function(req, res, next) {
    console.log("------------------getTransactionResponsetimeByInterval--------------------");
    var appName = req.query.appName;
    var gteString = req.query.gteString; //"now-1h"
    var lteString = req.query.lteString; //"now"
    var interval = req.query.interval;
    var status = req.query.status;

    console.log("appName:" + appName);
    console.log("gteString:" + appName);
    console.log("lteString:" + appName);
    console.log("interval:" + interval);
    console.log("status:" + status);

    elasticClient.search({
        index: appName,
        body: {
            "query": {
                "bool": {
                    "must": [
                        { "match": { "status.keyword": status } }
                    ],
                    "filter": [{
                        "range": {
                            "post_date": {
                                "gte": gteString,
                                "lt": lteString
                            }
                        }
                    }]
                }
            },
            "size": 0,
            "aggs": {
                "by_transactionName": {
                    "terms": {
                        "field": "transaction.keyword"
                    },
                    "aggs": {
                        "responsetimeafteraggregation": {
                            "date_histogram": {
                                "field": "post_date",
                                "interval": interval
                            },
                            "aggs": {
                                "computedavgresponsetime": {
                                    "avg": {
                                        "field": "responsetime"
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }).then(function(resp) {
        var transactionHits = resp.aggregations.by_transactionName.buckets;
        if (transactionHits.length == 0) {
            //return  No transactions
        }
        let transactionsAvgRT = [];
        for (var i = 0; i < transactionHits.length; i++) {
            let AvgRTByInterval = [];

            let transactionHit = transactionHits[i];

            let aggregationRTs = transactionHit.responsetimeafteraggregation.buckets;

            for (var j = 0; j < aggregationRTs.length; j++) {
                AvgRTByInterval.push({
                    "time": aggregationRTs[j].key_as_string,
                    "value": aggregationRTs[j].computedavgresponsetime.value
                });
            }

            transactionsAvgRT.push({
                transactionName: transactionHit.key,
                avgRTByInterval: AvgRTByInterval
            });
        }
        return res.status(200).json(transactionsAvgRT);
    }, function(err) {
        console.trace(err.message);
        return res.status(500).json(err.message);
    });

});

//Get the average response time by region for a given transaction
router.get('/getTransactionAverageByRegion', function(req, res, next) {
    var appName = req.query.appName;
    var transactionName = req.query.transactionName;
    var gteString = req.query.gteString; //"now-1h"
    var lteString = req.query.lteString; //"now"
    elasticClient.search({
        body: {
            "query": {
                "bool": {
                    "must": [
                        { "match": { "transaction.keyword": transactionName } },
                        { "match": { "status.keyword": "PASS" } }
                    ],
                    "filter": [{
                        "range": {
                            "post_date": {
                                "gte": gteString,
                                "lt": lteString
                            }
                        }
                    }]
                }
            },
            "size": 0,
            "aggs": {
                "transaction_summary": {
                    "composite": {
                        "sources": [
                            { "region": { "terms": { "field": "region.keyword" } } }
                        ]
                    },
                    "aggregations": {
                        "transactionaverage": {
                            "avg": { "field": "responsetime" }
                        },
                        "load_times": {
                            "percentiles": {
                                "field": "responsetime",
                                "percents": [90],
                                "keyed": false
                            }
                        }
                    }
                }
            }
        }
    }).then(function(resp) {
        var hits = resp.aggregations.transaction_summary.buckets;
        var transactionSummary = [];
        for (var i = 0; i < hits.length; i++) {
            var hit = hits[i];
            var avgVal = hit.transactionaverage.value.toFixed(0);
            var percentvalue = hit.load_times.values[0].value.toFixed(0)

            var regionString = hit.key.region.toLowerCase();
            var entry = {
                "region": hit.key.region,
                "count": hit.doc_count,
                "average": avgVal,
                "percentile": percentvalue,
                "coordinates": getCoordinates(regionString)
            };
            transactionSummary.push(entry);
        }
        return res.status(200).json(transactionSummary);
    }, function(err) {
        return res.status(500).json(err.message);
        console.trace(err.message);
    });
    //console.log('inside getTransactionAverageByRegion');
});



//Get the average response time by region hourly for a given transaction  
router.get('/getHourlyTransactionAverageByRegion', function(req, res, next) {
    var appName = req.query.appName;
    var transactionName = req.query.transactionName;
    var gteString = req.query.gteString; //"now-1h"
    var lteString = req.query.lteString; //"now"
    elasticClient.search({
        index: appName,
        body: {
            "query": {
                "bool": {
                    "must": [
                        { "match": { "transaction.keyword": transactionName } },
                        { "match": { "status.keyword": "PASS" } }

                    ],
                    "filter": [{
                        "range": {
                            "post_date": {
                                "gte": gteString,
                                "lt": lteString
                            }
                        }
                    }]
                }
            },
            "size": 0,
            "aggs": {
                "hourly_summary": {
                    "composite": {
                        "sources": [{
                            "region": {
                                "terms": {
                                    "field": "region.keyword"
                                }
                            }
                        }]
                    },
                    "aggregations": {
                        "transactionaverage": {
                            "avg": {
                                "field": "responsetime"
                            }
                        },
                        "avgHourlyResponseTime": {
                            "date_histogram": {
                                "field": "post_date",
                                "interval": "hour"
                            },
                            "aggregations": {
                                "hourlyAverage": {
                                    "avg": {
                                        "field": "responsetime"
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }).then(function(resp) {
        var regionsHit = resp.aggregations.hourly_summary.buckets;
        var regions_summary = [];
        for (var i = 0; i < regionsHit.length; i++) {
            var hourlyhit = regionsHit[i].avgHourlyResponseTime.buckets;
            var regionString = regionsHit[i].key.region.toLowerCase();
            var avgVal = regionsHit[i].transactionaverage.value.toFixed(0);
            //console.log(' region'+regionString+' hit size : ' + hourlyhit.length);
            var hourly_summary = [];

            for (var j = 0; j < hourlyhit.length; j++) {
                var hourly_entry = {
                    "datetimestamp": hourlyhit[j].key_as_string,
                    "count": hourlyhit[j].doc_count,
                    "average": hourlyhit[j].hourlyAverage.value.toFixed(0)
                };
                hourly_summary.push(hourly_entry);
            }

            var entry = {
                "region": regionString,
                "count": regionsHit[i].doc_count,
                "average": avgVal,
                "coordinates": getCoordinates(regionString),
                "hourlyEntries": hourly_summary,
            };
            regions_summary.push(entry);
        }
        return res.status(200).json(regions_summary);
    }, function(err) {
        return res.status(500).json(err.message);
        console.trace(err.message);
    });
});




//Get the sum of pass/fail count aggregated by minute 
router.get('/getTransactionStatusByMinute', function(req, res, next) {
    var appName = req.query.appName;
    var transactionName = req.query.transactionName;
    var gteString = req.query.gteString; //"now-1h"
    var lteString = req.query.lteString; //"now"
    var status = req.query.status; //"now"
    elasticClient.search({

        body: {
            "query": {
                "bool": {
                    "must": [
                        { "match": { "transaction.keyword": transactionName } },
                        { "match": { "status.keyword": status } },
                    ],
                    "filter": [{
                        "range": {
                            "post_date": {
                                "gte": gteString,
                                "lt": lteString
                            }
                        }
                    }]
                }
            },
            "size": 0,
            "aggs": {
                "values_over_time": {
                    "date_histogram": {
                        "field": "post_date",
                        "interval": "5m"
                    }
                }
            }
        }
    }).then(function(resp) {
        var response = resp.aggregations.values_over_time.buckets;
        return res.status(200).json(response);
    }, function(err) {
        return res.status(500).json(err.message);
        console.trace(err.message);
    });
});

//Get the number of pass fail count for a given transaction
router.get('/getTransactionStatusCount', function(req, res, next) {
    var appName = req.query.appName;
    var transactionName = req.query.transactionName;
    var gteString = req.query.gteString; //"now-1h"
    var lteString = req.query.lteString; //"now"
    elasticClient.search({
        body: {
            "query": {
                "bool": {
                    "must": [
                        { "match": { "transaction.keyword": transactionName } }
                    ],
                    "filter": [{
                        "range": {
                            "post_date": {
                                "gte": gteString,
                                "lt": lteString
                            }
                        }
                    }]
                }
            },
            "size": 0,
            "aggs": {
                "status_summary": {
                    "composite": {
                        "sources": [
                            { "txStatus": { "terms": { "field": "status.keyword" } } }
                        ]
                    },
                    "aggregations": {
                        "statusCount": {
                            "value_count": { "field": "status.keyword" }
                        }
                    }
                }
            }
        }
    }).then(function(resp) {
        var hits = resp.aggregations.status_summary.buckets;
        var statusSummary = [];
        for (var i = 0; i < hits.length; i++) {
            var hit = hits[i];
            var countVal = hit.statusCount.value;

            var statusString = hit.key.txStatus.toLowerCase();
            var entry = {
                "status": statusString,
                "count": countVal
            };
            statusSummary.push(entry);
        }
        return res.status(200).json(statusSummary);
    }, function(err) {
        return res.status(500).json(err.message);
        console.trace(err.message);
    });
});

//with 95 percentile
router.get("/getPageStatsForTransaction", function(req, res, next) {
    var appname = req.query.appName;
    var transactionName = req.query.transactionName;
    var gteString = req.query.gteString;
    var lteString = req.query.lteString;
    elasticClient.search({
        body: {
            "query": {
                "bool": {
                    "must": [
                        { "match": { "transaction.keyword": transactionName } },
                        { "match": { "status.keyword": "PASS" } }
                    ],
                    "filter": [{
                        "range": {
                            "post_date": {
                                "gte": gteString,
                                "lt": lteString
                            }
                        }
                    }]
                }
            },
            "sort": [{
                "TotalRequestsCount": {
                    "order": "desc"
                }
            }],
            "size": 1,
            "aggs": {
                "load_times": {
                    "percentiles": {
                        "field": "responsetime",
                        "percents": [90],
                        "keyed": false
                    }
                },
                "transactionaverage": {
                    "avg": {
                        "field": "responsetime"
                    }
                }
            }
        }
    }).then(function(resp) {
            var hit = resp.hits.hits[0];

            var respTime = 0;
            var percentileValue = 0;
            var totalReqCount = 0;
            var totalTransactionSize = 0;
console.log("-----------getPageStatsForTransaction-----------");
console.log(resp.hits.hits.length);
//console.log( hit._source.TotalRequestsCount);
            //if (resp.hits.total > 0) {
                respTime = resp.aggregations.transactionaverage.value;
                percentileValue = resp.aggregations.load_times.values[0].value;
                totalReqCount = hit._source.TotalRequestsCount;
                totalTransactionSize = hit._source.TotalTransactionSize;
           // }
            var entry = {
                "ResponseTime": respTime,
                "PercentileValue": percentileValue,
                "TotalRequestsCount": totalReqCount,
                "TotalTransactionSize": totalTransactionSize
            };
            return res.status(200).json(entry);
        },
        function(err) {
            console.log(err.message);
            return res.status(500).json(err.message);
        });
});

//Get the transaction response time data for given transaction, start/enddate
router.get('/getTransactionSamples', function(req, res, next) {
    var appName = req.query.appName;
    console.log("getTransactionSamples applicationname : " + req.query.appName);
    var transactionName = req.query.transactionName;
    var gteString = req.query.gteString; //"now-1h"
    var lteString = req.query.lteString; //"now"
    console.log("-----------Transaction Name--------------");
    console.log(transactionName);
    elasticClient.search({
        index: appName,
        body: {
            "size": 10000,
            "query": {
                "bool": {
                    "must": [
                        { "match": { "transaction.keyword": transactionName } } //,
                        // { "match": { "status": "PASS" } }
                    ],
                    "filter": [{
                        "range": {
                            "post_date": {
                                "gte": gteString,
                                "lt": lteString
                            }
                        }
                    }]
                }
            },
            "_source": {
                "includes": ["id", "transaction", "responsetime", "region", "post_date", "NetworkStatsCalls", "status"]
            },
            "sort": [
                { "post_date": "asc" }
            ]
        }
    }).then(function(resp) {
        var hits = resp.hits.hits;
        var txSamplesByRegion = {};
        console.log('************** hits size : ' + hits.length);
        console.log("--------------------------hit._source-------------------------------------");

        for (var i = 0; i < hits.length; i++) {

            var hit = hits[i];
            //    console.log(JSON.stringify(hit._source)); 
            var region = hit._source.region;
            var entry = {
                "id": hit._id,
                //"region":region,
                "transaction": hit._source.transaction,
                "post_date": hit._source.post_date,
                "responsetime": hit._source.responsetime,
                "networkcallsflag": hit._source.NetworkStatsCalls,
                "status": hit._source.status
            };
            //if was commented----  bug
            // if (JSON.stringify(hit._source.transaction) === JSON.stringify(transactionName)) {
            if (hit._source.transaction === transactionName) {
                if (txSamplesByRegion[region] == null) {
                    txSamplesByRegion[region] = [entry];
                } else {
                    txSamplesByRegion[region].push(entry);
                }
            }
        }
        return res.status(200).json(txSamplesByRegion);
    }, function(err) {
        return res.status(500).json(err.message);
        console.trace(err.message);
    });
    console.log('inside getTransactionSamples');
});


//Get the errors transaction response time data for given transaction, start/enddate
router.get('/getErrorTransactionSamples', function(req, res, next) {
    var appName = req.query.appName;
    var transactionName = req.query.transactionName;
    var gteString = req.query.gteString; //"now-1h"
    var lteString = req.query.lteString; //"now"
    elasticClient.search({
        body: {
            "size": 10000,
            "query": {
                "bool": {
                    "must": [
                        { "match": { "transaction.keyword": transactionName } }
                    ],
                    "filter": [{
                        "range": {
                            "post_date": {
                                "gte": gteString,
                                "lt": lteString
                            }
                        }
                    }]
                }
            },
            "_source": {
                "includes": ["id", "transaction", "responsetime", "region", "post_date", "NetworkStatsCalls", "status"]
            },
            "sort": [
                { "post_date": "asc" }
            ]
        }
    }).then(function(resp) {
        var hits = resp.hits.hits;
        var txSamplesByRegion = {};
        for (var i = 0; i < hits.length; i++) {
            var hit = hits[i];
            var region = hit._source.region;
            var status = hit._source.status;
            if (status.includes("FAIL")) {
                var entry = {
                    "id": hit._id,
                    //"region":region,
                    "post_date": hit._source.post_date,
                    "responsetime": hit._source.responsetime,
                    "status": hit._source.status
                };

                if (txSamplesByRegion[region] == null) {
                    txSamplesByRegion[region] = [entry];
                } else {
                    txSamplesByRegion[region].push(entry);
                }
            }
        }
        console.log(" ErrorTransaction For  bubble chart");
        console.log(JSON.stringify(txSamplesByRegion));
        return res.status(200).json(txSamplesByRegion);
    }, function(err) {
        return res.status(500).json(err.message);
        console.trace(err.message);
    });
});


//used for summary table in transaction page
router.get('/getTransactionForSummaryDetails', function(req, res, next) {
    var appName = req.query.appName;
    var status = [];
    var check;
    console.log(" summary table ");
    var tempstatus = (req.query.status).split(',');

    for (let temp of tempstatus)
        status.push(temp);
    console.log(JSON.stringify(status));
    var transactionName = req.query.transactionName;
    var gteString = req.query.gteString; //"now-1h"
    var lteString = req.query.lteString; //"now"
    elasticClient.search({
        body: {
            "size": 10000,
            "query": {
                "bool": {
                    "must": [
                        { "match": { "transaction.keyword": transactionName } } /* ,{"match":{"status":status}} */
                    ],
                    "filter": [{
                        "range": {
                            "post_date": {
                                "gte": gteString,
                                "lt": lteString
                            }
                        }
                    }]
                }
            },
            "_source": {
                "includes": ["id", "transaction", "responsetime", "region", "post_date", "status"]
            },
            "sort": [
                { "post_date": "asc" }
            ]
        }
    }).then(function(resp) {
        var hits = resp.hits.hits;
        var transactionSummary = [];
        for (let transactionstatus of status) {
            for (var i = 0; i < hits.length; i++) {
                var hit = hits[i];
                var region = hit._source.region;
                console.log(hit._source.status);
                console.log(transactionstatus);
                if (transactionstatus == hit._source.status) {

                    var entry = {
                        "id": hit._id,
                        "transactionName": transactionName,
                        "timestamp": hit._source.post_date,
                        "responseTime": hit._source.responsetime,
                        "status": hit._source.status,
                        "region": hit._source.region
                    };
                    console.log(JSON.stringify(entry));
                    transactionSummary.push(entry);
                }
            }
        }

        return res.status(200).json(transactionSummary);
    }, function(err) {
        return res.status(500).json(err.message);
        console.trace(err.message);
    });

});



//Get the transaction data by ID
router.get('/getTransactionByID', function(req, res, next) {
    var appName = req.query.appName;
    var id = req.query.id;
    console.log("id value in gettransactionByID : " + id);
    console.log("applicationName is " + appName);
    elasticClient.search({
        body: {
            "query": {
                "bool": {
                    "must": [
                        { "match": { "_id": id } }
                    ]
                }
            }
        }
    }).then(function(resp) {
        var hits = resp.hits.hits;
        if (hits.length === 0)
            return res.status(500).json({ "error": "No transaction data found for given ID" });
        else
            return res.status(200).json(hits);
    }, function(err) {
        return res.status(500).json(err.message);
        console.trace(err.message);
    });

});


module.exports = router;