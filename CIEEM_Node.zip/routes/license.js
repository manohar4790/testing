const licenseFile = require('nodejs-license-file');
const fs = require("fs");
var template = require('./template.js')
var datetime = require('node-datetime');
//var dt = datetime.create("12/31/2019");//march 02 2019  //expiry//cognizant
var dt = datetime.create(); //present date
dt.offsetInDays(365); //1 year 
// var expiry=dt.format('m/d/Y');//expiry date
var expiry = datetime.create("12/31/2020").format('m/d/Y');

function generateLicense(customerName) {
    try {
        const licenseFileContent = licenseFile.generate({
            privateKeyPath: './routes/private.pem',
            // privateKeyPath: 'private.pem',
            template,
            data: {
                customername: customerName,
                expirationDate: expiry
            }
        });
        console.log("licenseFileContent\n" + licenseFileContent);
        fs.writeFileSync('./CustomerLicenses/' + customerName + '.lic', licenseFileContent, 'utf8');
        // fs.writeFileSync('../CustomerLicenses/'+'license'+'.lic', licenseFileContent, 'utf8');
        return (true);

    } catch (err) {
        console.log(err);
    }
}

module.exports = template;
module.exports = generateLicense;