var config = require('../configuration.json');
//require express library
var express = require('express');
//require the express router
var router = express.Router();
var app = express();
var bodyParser = require('body-parser');
var fs = require('fs');
var Request = require("request");

var mongo = require('mongodb');
let mongodb;
mongo.connect(config.mongoDBURL, function (err, mDB) {
    mongodb = mDB.db();
    console.log("Connected to MongoDB - worker.js");
});
//This API will start script
router.get('/startscript', function (req, res) {
    try {
        let scriptid = req.query.id;
        if (scriptid) {
            let orginalScript;
            mongodb.collection("Customers").aggregate([{ "$match": { 'application': { $elemMatch: { 'scripts': { $elemMatch: { 'scriptid': mongo.ObjectID(scriptid) } } } } } }, { $project: { '_id': 1, 'customerName': 1, 'application.appid': 1, 'application.applicationName': 1, 'application.scripts': 1 } }]).toArray((err, result) => {
                if (err) {
                    //console.log("Error in getdata : " + err);
                    return res.status(500).json(err);
                } else {
                    let apps = result[0].application; //.scripts

                    let customerName = result[0].customerName;
                    let customerid = result[0]._id;
                    apps.forEach((app) => {
                        let scripts = app.scripts;
                        let appName = app.applicationName;
                        let appid = app.appid;
                        scripts.forEach((script) => {
                            if (script.scriptid == scriptid) {
                                orginalScript = script;
                                orginalScript.appid = appid;
                                orginalScript.applicationName = appName;
                                orginalScript.customerid = customerid;
                                orginalScript.customerName = customerName;
                                orginalScript.scriptversion = script.scriptname;
                            }
                        });
                    });
                    mongodb.collection("scheduling_table").insert(orginalScript, function (err, result) {
                        if (err) {
                            console.log("Error in inserting scheduling_table : " + err);
                            return res.status(500).json(err);
                        } else {
                            console.log("No Error in inserting scheduling_table : ");
                            //res.status(200).json(result.ops[0]._id);
                            console.log(result); //  edited one
                            Request.get("http://" + config.actionControllerHost + ":8080/ActionController/rest/startscript/" + result.ops[0]._id, (error, response, body) => {
                                if (error) {
                                    console.error(error);
                                    return res.status(500).json(error);
                                }
                                console.log(body);
                                //"Runnable"
                                //"Script schedule started"

                                if (body === "Script schedule started") {
                                    mongodb.collection("Customers").update({ "_id": mongo.ObjectID(orginalScript.customerid), "application.appid": mongo.ObjectID(orginalScript.appid) }, { $set: { "application.$[a].scripts.$[s].status": "Runnable" } }, { arrayFilters: [{ "a.appid": mongo.ObjectId(orginalScript.appid) }, { "s.scriptid": mongo.ObjectId(orginalScript.scriptid) }] }, function (err, result) {
                                        if (err) {
                                            console.log("Error in updating status : " + err);
                                            return res.status(500).json("Internal Server Error : Error in updating status");
                                        } else {
                                            console.log("Updated script status as Runnable");
                                            console.log(JSON.stringify(result));
                                            //return res.status(200).json("updated script status as Runnable");
                                            return res.status(200).json({
                                                status: body,
                                                //statusmessage:result.
                                            });
                                        }
                                    })
                                } else {

                                    return res.status(500).json(body);
                                }
                            });
                        }
                    });
                }
            });
        }
    } catch (error) {
        //console.log("Error in startscript " + e);
        return res.status(500).json(error);

    }
});
function StoppingScripts(scriptid) {
    return new Promise(function (resolve, reject) {
        mongodb.collection("scheduling_table").findOne({ "scriptid": mongo.ObjectID(scriptid) }, function (err, result) {
            if (err) {
                console.log("Error in getting doc scheduling_table : " + err);
                reject("Internal Server Error: Error in getting document from  scheduling_table");
            } else {
                console.log("No Error in getting doc scheduling_table : ");
                console.log(result);  //  edited  one
                let orginalScript = result;
                Request.get("http://" + config.actionControllerHost + ":8080/ActionController/rest/stopscript/" + result._id, (error, response, body) => {
                    if (error) {
                        console.error(error);
                        reject(error);
                    }
                    console.log(body); // "Script scheduling stopped"

                    if (body === "Script scheduling stopped" || body === "Script reference not found - It is already stopped or deleted") {
                        mongodb.collection("scheduling_table").removeOne({ "scriptid": mongo.ObjectID(scriptid) }, function (err, result) {
                            if (err) {
                                reject("Error in deleting script");
                            } else {
                                console.log("Deleted scheduling script");
                                mongodb.collection("Customers").update({ "_id": mongo.ObjectID(orginalScript.customerid), "application.appid": mongo.ObjectID(orginalScript.appid) }, { $set: { "application.$[a].scripts.$[s].status": "Stopped" } }, { arrayFilters: [{ "a.appid": mongo.ObjectId(orginalScript.appid) }, { "s.scriptid": mongo.ObjectId(orginalScript.scriptid) }] }, function (err, result) {
                                    if (err) {
                                        console.log("Error in updating status : " + err);
                                        reject("Error in updating status in Customer Collection");
                                    } else {
                                        console.log("Updated script status as Stopped");
                                        resolve({ "status": true, "message": "Script scheduling stopped" });
                                        //return res.status(200).json("updated script status as Runnable");
                                        // return res.status(200).json({
                                        //     status: "Script scheduling stopped"
                                        // });
                                    }
                                })
                                //return res.status(200).json("no error in deleteScriptingData");
                            }
                        });
                    } else {
                        reject(body);
                    }
                });
            }
        });
    });
}

//This API will stop script
router.get('/stopscript', async function (req, res) {
    try {
        let scriptid = req.query.id;
        if (scriptid) {
            var checkStopStatus = await StoppingScripts(scriptid);
            console.log(" response from Fn ");
            console.log(checkStopStatus);
            if (checkStopStatus.status) { return res.status(200).json({ status: checkStopStatus.message }); }
        }
    } catch (error) {
        //console.log("Error in stopscript " + e);
        return res.status(500).json(error);

    }
});


//This API will get one message from queue, for a given region
//Will be called multiple SeleniumControllers
router.get('/getMessageFromRegionQueue', function (req, res) {
    var regionQueueName = req.query.regionQueueName;
    if (typeof regionQueueName == "undefined" || regionQueueName == null) {
        return res.status(500).json({
            status: "ERROR",
            message: "Region Queue name not passed as parameter"
        });
    }

    /*res.setTimeout(5000, function(){
        //console.log('Request has timed out, guess no messages in the queue');
        return  res.status(200).json({
            status: "No messages found, after waiting & timedout",
          });
    });*/

    try {
        Request.get("http://" + config.actionControllerHost + ":8080/ActionController/rest/getMessageFromQueue/" + regionQueueName, (error, response, body) => {
            if (error) {
                console.error(error);
                return res.status(500).json({
                    status: error
                });
            }
            //console.log(body);
            return res.status(200).json(body);
        });
    } catch (e) {
        console.log("Error in getMessageFromRegionQueue " + e);
        return res.status(500).json({
            status: "ERROR",
            message: e
        });
    }


});
module.exports = router;
//exports.StoppingScripts =StoppingScripts;