template = [
    '====BEGIN LICENSE====',
    '{{&customername}}',
    '{{&expirationDate}}',
    '{{&serial}}',
    '=====END LICENSE====='
].join('\n');
module.exports=template;