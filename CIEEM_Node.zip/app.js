var createError = require('http-errors');
var express = require('express');
var path = require('path');
var cookieParser = require('cookie-parser');
var logger = require('morgan');
var validator = require('express-validator');
var bodyParser = require('body-parser');
var helmet = require('helmet');

var adminRouter = require('./routes/admin');
var loginRouter = require('./routes/login');
var samplesRoutes = require('./routes/samplesAPI.js');
var scriptRouter = require('./routes/script');
var workerRouter = require('./routes/worker');
let verifyToken = require('./routes/tokenMiddleware');
let seleniumAPIRoutes = require('./routes/seleniumAPI');
var fileUploadRoutes = require('./routes/fileUpload.js');
const https = require('https');
const http = require('http');
const fs = require('fs');

var cors = require('cors');



var app = express();

// view engine setup
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');

app.use(logger('dev'));

/*bodyParser = {
  json: {limit: '50mb', extended: true},
  urlencoded: {limit: '50mb', extended: true}
};*/

//Required for resolving 'PayloadTooLarge' error
app.use(bodyParser.json({ limit: '50mb', extended: true }))
app.use(bodyParser.urlencoded({ limit: '50mb', extended: true }))
    //app.use(bodyParser.urlencoded());

app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(cors());
app.use(express.static(path.join(__dirname, 'public')));

app.use('/activemonitorFiles',express.static(path.join(__dirname, 'public/assets')));

//monitor access using morgan
var morgan = require('morgan');
var rfs = require("rotating-file-stream");

var accessLogStream = rfs('access.log', {
    size: "10M",
    interval: "1d",
    path: path.join(__dirname, '/logs/'),
});

var stdoutLogStream = rfs('stdout.log', {
    size: "10M",
    interval: "1d",
    path: path.join(__dirname, '/logs/'),
});

// setup the logger
app.use(morgan('[:date[iso]] - :remote-addr - :method :url HTTP/:http-version :status :res[content-length] - :response-time ms', { stream: accessLogStream }));
app.use(morgan('dev', { stream: stdoutLogStream }));

//Print in console as well
app.use(morgan("dev")); //log to console on development


//Code to handle XSS using express-validator
/* app.use(validator());
app.use(function(req, res, next) {
  console.log("sanitize: "+req.headers['host'] + req.url);
  for (var item in req.body) {
    console.log(item);
   
    if(req.checkBody().isArray()){
      req.sanitize(item.regions).unescape();
    }
    else
    req.sanitize(item).escape(); 
    */
/* req.sanitize(item).; */
/* const sanitizeValue = value => {
      
  //sanitize...
} */

/* app.post('/form', [
  check('value').customSanitizer(value => {
    return sanitizeValue(value)
  }),
], (req, res) => {
  const value  = req.body.value
}) */
/* }
  
  next();
}); */

//Required to handle XSS - Content security policy (CSP)
/* app.use(helmet.contentSecurityPolicy({
  directives: {
    defaultSrc: ["'self'"]
  }
})); */
/*app.use(helmet.csp({
  defaultSrc: ["'self'"],
  scriptSrc: ['*.google-analytics.com'],
  styleSrc: ["'unsafe-inline'"],
  imgSrc: ['*.google-analytics.com'],
  connectSrc: ["'none'"],
  fontSrc: [],
  objectSrc: [],
  mediaSrc: [],
  frameSrc: []
}));*/


//create a cors middleware
app.use(function(req, res, next) {
    //set headers to allow cross origin request.
    res.header("Access-Control-Allow-Origin", "*");
    res.header('Access-Control-Allow-Methods', 'PUT, GET, POST, DELETE, OPTIONS');
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    next();
});

app.use(function(err, req, res, next) {
    console.log("req.headersSent in app.js - " + JSON.stringify(req.headersSent));
    console.log('ERROR : ' + err);
    if (res.headersSent) return next(err);
    res.status(500).json("Internal Server Error");;
});



//app.use('/', indexRouter);
//app.use('/worker', verifyToken, workerRouter);
app.use('/worker', workerRouter);
//app.use('/samplesAPI/', verifyToken, samplesRoutes);
app.use('/samplesAPI/', verifyToken, samplesRoutes);
app.use('/seleniumAPI/', seleniumAPIRoutes);
app.use('/login', loginRouter);
app.use('/script/', verifyToken, scriptRouter);
app.use('/admin/', verifyToken, adminRouter);
app.use('/fileupload/', fileUploadRoutes);

//app.use('/users', usersRouter);



// catch 404 and forward to error handler
app.use(function(req, res, next) {
    next(createError(404));
});

// error handler
app.use(function(err, req, res, next) {
    // set locals, only providing error in development
    console.log('ERROR : ' + err);
    res.locals.message = err.message;
    res.locals.error = req.app.get('env') === 'development' ? err : {};

    // render the error page
    res.status(err.status || 500);
    res.render('error');
});



module.exports = app;