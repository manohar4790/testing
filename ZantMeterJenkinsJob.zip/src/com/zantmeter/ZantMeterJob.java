
package com.zantmeter;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.UnknownHostException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import javax.net.ssl.SSLContext;

import org.apache.http.client.CookieStore;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.protocol.HttpClientContext;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.conn.ssl.TrustSelfSignedStrategy;
import org.apache.http.entity.StringEntity;

import org.apache.http.impl.client.BasicCookieStore;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.protocol.BasicHttpContext;
import org.apache.http.protocol.HttpContext;
import org.apache.http.ssl.SSLContexts;
import org.json.JSONArray;
import org.json.JSONObject;

public class ZantMeterJob {

	private static String serverURLPrefix;
	private static String keystorePath;
	private static String keystorePassword;
	private static String email;
	private static String password;
	private static String elasticsearchDBHost;
	private String jwtToken;
	private static String testScenarioID;
	private String bTestRunID;
	private String cTestRunID;
	private HttpContext httpContext;

	ZantMeterJob() {

	}

	public static void main(String[] args) {
		ZantMeterJob job = new ZantMeterJob();
		job.initialize();
		job.generateJwtToken();

		if (args.length > 0) {
			testScenarioID = args[0];
		}
		System.out.println(testScenarioID);
		job.startTestRun(testScenarioID);
		String testRunStatus = "Running";
		while (!testRunStatus.equals("Analysed")) {
			testRunStatus = job.getTestRunStatus();
			try {
				Thread.sleep(5000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}

		// job.getTransactionSummaryByID(job.bTestRunID);
		// job.getTransactionSummaryByID(job.cTestRunID);
		
		// job.iterateTS(job.getTransactionSummaryByID(job.bTestRunID), job.bTestRunID);
		job.iterateTS(job.getTransactionSummaryByID(job.cTestRunID), job.cTestRunID);
	}

	public void initialize() {

		// Read the property file entries
		Properties prop = new Properties();
		InputStream input = null;
		try {
			input = getClass().getResourceAsStream("/zantmeter.properties");

			// load a properties file
			prop.load(input);
			serverURLPrefix = prop.getProperty("ServerURLPrefix");
			keystorePath = prop.getProperty("keystorePath");
			keystorePassword = prop.getProperty("keystorePassword");
			email = prop.getProperty("nodeEmail");
			password = prop.getProperty("nodePassword");
			testScenarioID = prop.getProperty("testScenarioID");
			bTestRunID = prop.getProperty("bTestRunID");
			elasticsearchDBHost = prop.getProperty("elasticsearchDBHost");
		} catch (IOException ex) {
			ex.printStackTrace();
			System.exit(0);
		} finally {
			if (input != null) {
				try {
					input.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}

	public void generateJwtToken() {
		JSONObject jsonTokenObj = null;
		try {

			String urlString = serverURLPrefix + "/login/login";

			HttpPost httpPost = new HttpPost(urlString);
			JSONObject jsonObj = new JSONObject();
			jsonObj.put("email", email);
			jsonObj.put("password", password);
			StringEntity entity = new StringEntity(jsonObj.toString());
			httpPost.setEntity(entity);
			httpPost.setHeader("Accept", "application/json");
			httpPost.setHeader("Content-type", "application/json");

			CookieStore cookieStore = new BasicCookieStore();
			this.httpContext = new BasicHttpContext();
			this.httpContext.setAttribute(HttpClientContext.COOKIE_STORE, cookieStore);

			CloseableHttpClient httpclient = null;

			if (serverURLPrefix.contains("https:")) { // i.e, HTTPS URL
				SSLContext sslcontext = SSLContexts.custom().loadTrustMaterial(new File(keystorePath),
						keystorePassword.toCharArray(), new TrustSelfSignedStrategy()).build();
				// Allow TLSv1 protocol only
				SSLConnectionSocketFactory sslsf = new SSLConnectionSocketFactory(sslcontext, new String[] { "TLSv1" },
						null, SSLConnectionSocketFactory.getDefaultHostnameVerifier());
				httpclient = HttpClients.custom().setSSLSocketFactory(sslsf).build();
			} else { // i.e., HTTP url
				httpclient = HttpClients.custom().build();
			}

			CloseableHttpResponse httpResponse = httpclient.execute(httpPost, this.httpContext);

			BufferedReader reader = new BufferedReader(new InputStreamReader(httpResponse.getEntity().getContent()));

			String inputLine;
			StringBuffer response = new StringBuffer();

			while ((inputLine = reader.readLine()) != null) {
				response.append(inputLine);
			}
			reader.close();
			// print result
			// System.out.println(response.toString());
			httpclient.close();
			jsonTokenObj = new JSONObject(response.toString());
			JSONObject data = (JSONObject) jsonTokenObj.get("data");
			this.jwtToken = data.getString("token");
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	public String getTestRunStatus() {
		String urlString = serverURLPrefix + "/testAPI/getTestRunStatusByID?_id=" + this.cTestRunID;
		String jsonData = null;
		try {
			jsonData = getHTTPRequest(urlString);
			JSONObject myJsonObject = null;
			myJsonObject = new JSONObject(jsonData);
			System.out.println("Response :: " + myJsonObject);
			return myJsonObject.getString("status");
		} catch (Exception ex) {
			ex.printStackTrace();
			return null;
		}
	}

	public void startTestRun(String testrunid) {
		String urlString = serverURLPrefix + "/testAPI/startTestRunByScenario?_id=" + testrunid;
		String jsonData = null;
		try {
			jsonData = getHTTPRequest(urlString);
			JSONObject myJsonObject = null;
			myJsonObject = new JSONObject(jsonData);
			System.out.println("Response :: " + myJsonObject);// testRunID
			this.cTestRunID = myJsonObject.getString("testRunID");
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	public void stopTestRun(String testrunid) {
		String urlString = serverURLPrefix + "/testAPI/stopTestRun?testrunid=" + testrunid;
		String jsonData = null;
		try {
			jsonData = getHTTPRequest(urlString);
			JSONObject myJsonObject = null;
			myJsonObject = new JSONObject(jsonData);
			System.out.println("Response :: " + myJsonObject);
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	public JSONArray getTransactionSummaryByID(String testrunid) {
		String urlString = serverURLPrefix + "/testAPI/getTransactionSummaryByID?_id=" + testrunid;
		String jsonData = null;
		try {
			jsonData = getHTTPRequest(urlString);
			JSONArray myJsonArray = null;
			myJsonArray = new JSONArray(jsonData);
			// System.out.println("Response :: " + myJsonArray);
			return myJsonArray;
		} catch (Exception ex) {
			ex.printStackTrace();
			return null;
		}
	}

	public void iterateTS(JSONArray summary, String TestRunID) {
		try {
			// System.out.println(summary.toString());
			for (int i = 0; i < summary.length(); i++) {
				JSONObject Transaction = (JSONObject) summary.get(i);
				// System.out.println(Transaction.toString());
				String TransactionName = Transaction.getString("TransactionName");
				Float ResponseTime = Transaction.getFloat("avg"), percentile = Transaction.getFloat("percentile");
				int pass = Transaction.getInt("passcount"), fail = Transaction.getInt("errorcount");
				// System.out.println(TransactionName + " " + ResponseTime + " " + percentile +
				// " " + pass + " " + fail);

				JSONObject tObj = new JSONObject();
				tObj.put("TestRunID", TestRunID);
				tObj.put("TransactionName", TransactionName);
				tObj.put("ResponseTime", ResponseTime);
				tObj.put("percentile", percentile);
				tObj.put("pass", pass);
				tObj.put("fail", fail);

				SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZ");
				String dateString = sdf.format(new Date());
				tObj.put("post_date", dateString);

				/*
				 * var indexName = json.indexName; var indexType = json.indexType; var doc =
				 * json.doc;
				 */
				JSONObject reqObj = new JSONObject();
				reqObj.put("indexName", testScenarioID.toLowerCase());
				reqObj.put("indexType", "_doc");
				reqObj.put("doc", tObj);
				postHTTPRequest(reqObj);
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	public String getHTTPRequest(String urlString) {
		try {

			CloseableHttpClient httpclient = null;

			if (serverURLPrefix.contains("https:")) { // i.e, HTTPS URL
				SSLContext sslcontext;

				sslcontext = SSLContexts.custom().loadTrustMaterial(new File(keystorePath),
						keystorePassword.toCharArray(), new TrustSelfSignedStrategy()).build();

				// Allow TLSv1 protocol only
				SSLConnectionSocketFactory sslsf = new SSLConnectionSocketFactory(sslcontext, new String[] { "TLSv1" },
						null, SSLConnectionSocketFactory.getDefaultHostnameVerifier());
				httpclient = HttpClients.custom().setSSLSocketFactory(sslsf).build();
			} else { // i.e., HTTP url
				httpclient = HttpClients.custom().build();
			}

			HttpGet httpGet = new HttpGet(urlString);
			httpGet.setHeader("Authorization", "Bearer " + this.jwtToken);
			httpGet.setHeader("Accept", "application/json");

			CloseableHttpResponse httpResponse = httpclient.execute(httpGet, this.httpContext);

			System.out.println("Post Response Status:: " + httpResponse.getStatusLine().getStatusCode());

			BufferedReader reader = new BufferedReader(new InputStreamReader(httpResponse.getEntity().getContent()));

			String inputLine;
			StringBuffer response = new StringBuffer();

			while ((inputLine = reader.readLine()) != null) {
				response.append(inputLine);
			}
			reader.close();

			// print result
			// System.out.println(response.toString());
			httpclient.close();

			return response.toString();
		} catch (Exception ex) {
			ex.printStackTrace();
			return null;
		}
	}

	public void postHTTPRequest(JSONObject jsonObj) {
		try {
			String urlString = serverURLPrefix + "/jenkinsESAPI/insertNewSample";
//			System.out.println(jsonObj.toString());
			HttpPost httpPost = new HttpPost(urlString);
			StringEntity entity = new StringEntity(jsonObj.toString());
			httpPost.setEntity(entity);
			httpPost.setHeader("Accept", "application/json");
			httpPost.setHeader("Content-type", "application/json");
			httpPost.setHeader("Authorization", "Bearer " + this.jwtToken);

			CloseableHttpClient httpclient = null;

			if (serverURLPrefix.contains("https:")) { // i.e, HTTPS URL
				SSLContext sslcontext = SSLContexts.custom().loadTrustMaterial(new File(keystorePath),
						keystorePassword.toCharArray(), new TrustSelfSignedStrategy()).build();
				// Allow TLSv1 protocol only
				SSLConnectionSocketFactory sslsf = new SSLConnectionSocketFactory(sslcontext, new String[] { "TLSv1" },
						null, SSLConnectionSocketFactory.getDefaultHostnameVerifier());
				httpclient = HttpClients.custom().setSSLSocketFactory(sslsf).build();
			} else { // i.e., HTTP url
				httpclient = HttpClients.custom().build();
			}

			CloseableHttpResponse httpResponse = httpclient.execute(httpPost, this.httpContext);

			BufferedReader reader = new BufferedReader(new InputStreamReader(httpResponse.getEntity().getContent()));

			String inputLine;
			StringBuffer response = new StringBuffer();

			while ((inputLine = reader.readLine()) != null) {
				response.append(inputLine);
			}
			reader.close();
			// print result
			// System.out.println(response.toString());
			httpclient.close();
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

}
