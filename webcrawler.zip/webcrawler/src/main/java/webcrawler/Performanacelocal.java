package webcrawler;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.math.BigDecimal;
import java.nio.file.Files;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;

import com.applitools.eyes.BatchInfo;
import com.applitools.eyes.EyesRunner;
import com.applitools.eyes.MatchLevel;
import com.applitools.eyes.RectangleSize;
import com.applitools.eyes.selenium.ClassicRunner;
import com.applitools.eyes.selenium.Eyes;
import com.applitools.eyes.selenium.StitchMode;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

public class Performanacelocal {
	static ThreadLocal<ExtentTest> extentest = new ThreadLocal<ExtentTest>();
	protected static ExtentReports extent;
	static ChromeDriver driver = null;
	static ArrayList<String> crawledList = new ArrayList<String>();
	static EyesRunner runner = new ClassicRunner();
	static Eyes eyes = new Eyes(runner);
	static Boolean enableAppliTools = false;
	static String destDir = "";
	// Below are input data fetched from CSV
	static String baseURL = "";
	static Boolean webCrawl = true;
	static String domainRestrcitionForCrawl = "";
	static String domainApprovedForCrawl = "";
	static Boolean appliTools = true;
	static Boolean outputComparison = false;
	static String baselineOutput = "";
	static String filePathForURLlist = "";
	static Boolean LightHouseThreshold = false;
	static int Performance = 0;
	static int Accessiblity = 0;
	static int BestPractice = 0;
	static int SEO = 0;
	static int ProgressiveWebApp = 0;
	static Boolean DeadLinkAndRedirectValidation = false;
	static String baseDomainForComp = "";
	static String currentDomain = "";
	static ExtentTest occ;
	public static void main(String args[]) {
		//compareWithPreviousOutput("C:\\svnlunaspace\\webcrawler\\TestResult\\2021_07_12_03_11_30\\WebCrawlReport.csv","C:\\svnlunaspace\\webcrawler\\TestResult\\2021_07_12_04_15_12\\WebCrawlReport.csv");
		String inputDataSheetPath = args[0];
		generateReportDirectory();
		extent = getReport();
		occ = extent.createTest("StartTest");
		extentest.set(occ);
		extentest.get().log(Status.INFO, "Tet execution stated");
		getInputDataFromFile(inputDataSheetPath);
		enableAppliTools = appliTools;
		if (webCrawl) {
			initiateChromeDriver();
			crawlWebPage();
			quitDiver();
		}
		writeCrawledURLListinFile();
		measureSingleUserPerformance(destDir + File.separator + "ListOfUniqueURL.txt"); // to pass file path
		lightHouseCSVconsolidation(destDir + File.separator+"LightHouseRepor"); // to replace path dynamically 
		if (outputComparison)
			compareWithPreviousOutput(baselineOutput, destDir + File.separator + "WebCrawlReport.csv");
		String consolidatedCSVreportPath = destDir + "/LighthouseConsolidatedCSVreport.csv";
		if (LightHouseThreshold) 
			lightHouseThresholdValidation(consolidatedCSVreportPath);
		extent.flush();
		validateDeadLink(destDir + File.separator + "WebCrawlReport.csv"); 
	}

	private static void lightHouseThresholdValidation(String consolidatedCSVreportPath) {
		// TODO Auto-generated method stub
		FileInputStream fstream;
		try {
			fstream = new FileInputStream(consolidatedCSVreportPath);
		
		BufferedReader br = new BufferedReader(new InputStreamReader(fstream));
		String headerLine =br.readLine();
		String[] urlOfReport = headerLine.split(",");
		String strLine;
		int calculateValue;
		//Read File Line By Line
		while ((strLine = br.readLine()) != null)   {
		  // Print the content on the console
		  if(strLine.contains("Overall")){
			  if(strLine.contains("Overall Performance Category Score")) {
				  occ = extent.createTest("LightHousePerformanceValidation");
				  extentest.set(occ);
				  String[] PerfScore = strLine.split(",");
				  for(int i=4;i<PerfScore.length;i++) {
					  calculateValue = (int)(Double.parseDouble(PerfScore[i].replaceAll("\"", ""))*100);
					  if(calculateValue<Accessiblity) {
						  extentest.get().log(Status.FAIL,urlOfReport[i]+ " has Performance score "+calculateValue+ "%. Less than expected value "+Performance);
					  }else {
						  extentest.get().log(Status.PASS,urlOfReport[i]+ " has Performance score "+calculateValue+ "%. Min expected value was"+Performance);
					  }
				  }
				  
			  }else if (strLine.contains("Overall Accessibility Category Score")) {
				  occ = extent.createTest("LightHouseAccessibilityValidation");
				  extentest.set(occ);
				  String[] PerfScore = strLine.split(",");
				  for(int i=4;i<PerfScore.length;i++) {
					  calculateValue = (int)(Double.parseDouble(PerfScore[i].replaceAll("\"", ""))*100);
					  if(calculateValue<Accessiblity) {
						  extentest.get().log(Status.FAIL,urlOfReport[i]+ " has Performance score "+(int)calculateValue+ "%. Less than expected value "+Accessiblity);
					  }else {
						  extentest.get().log(Status.PASS,urlOfReport[i]+ " has Performance score "+(int)calculateValue+ "%. Min expected value was"+Accessiblity);
					  }
				  }
			  }else if (strLine.contains("Overall Best Practices Category Score")) {
				  occ = extent.createTest("LightHouseBestPracticeValidation");
				  extentest.set(occ);
				  String[] PerfScore = strLine.split(",");
				  for(int i=4;i<PerfScore.length;i++) {
					  calculateValue = (int)(Double.parseDouble(PerfScore[i].replaceAll("\"", ""))*100);
					  if(calculateValue<BestPractice) {
						  extentest.get().log(Status.FAIL,urlOfReport[i]+ " has Performance score "+calculateValue+ "%. Less than expected value "+BestPractice);
					  }else {
						  extentest.get().log(Status.PASS,urlOfReport[i]+ " has Performance score "+calculateValue+ "%. Min expected value was"+BestPractice);
					  }
				  }
			  }else if (strLine.contains("Overall SEO Category Score")) {
				  occ = extent.createTest("LightHouseSEOValidation");
				  extentest.set(occ);
				  String[] PerfScore = strLine.split(",");
				  for(int i=4;i<PerfScore.length;i++) {
					  calculateValue = (int)(Double.parseDouble(PerfScore[i].replaceAll("\"", ""))*100);
					  if(calculateValue<Performance) {
						  extentest.get().log(Status.FAIL,urlOfReport[i]+ " has Performance score "+calculateValue+ "%. Less than expected value "+SEO);
					  }else {
						  extentest.get().log(Status.PASS,urlOfReport[i]+ " has Performance score "+calculateValue+ "%. Min expected value was"+SEO);
					  }
				  }
			  }else if (strLine.contains("Overall Progressive Web App Category Score")) {
				  occ = extent.createTest("LightHouseProgressiveWebAppValidation");
				  extentest.set(occ);
				  String[] PerfScore = strLine.split(",");
				  for(int i=4;i<PerfScore.length;i++) {
					  calculateValue = (int)(Double.parseDouble(PerfScore[i].replaceAll("\"", ""))*100);
					  if(calculateValue<Performance) {
						  extentest.get().log(Status.FAIL,urlOfReport[i]+ " has Performance score "+calculateValue+ "%. Less than expected value "+ProgressiveWebApp);
					  }else {
						  extentest.get().log(Status.PASS,urlOfReport[i]+ " has Performance score "+calculateValue+ "%. Min expected value was"+ProgressiveWebApp);
					  }
				  }
			  }
		  }
		}

		br.close();
		fstream.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	
	private static void generateReportDirectory() {
		// TODO Auto-generated method stub
		DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		Date date = new Date();
		File dir;
		destDir = "." + File.separator + "TestResult" + File.separator
				+ dateFormat.format(date).toString().replaceAll("/", "_").replaceAll(" ", "_").replaceAll(":", "_");
		dir = new File(destDir);
		dir.mkdir();
	}

	private static void writeCrawledURLListinFile() {
		// TODO Auto-generated method stub
		FileWriter myWriter;
		try {
			filePathForURLlist = destDir + File.separator + "ListOfUniqueURL.txt";
			myWriter = new FileWriter(filePathForURLlist);
			StringBuilder sb = new StringBuilder();

			int i = 0;
			while (i < crawledList.size()) {
				sb.append(crawledList.get(i)).append("\n");
				i++;
			}
			myWriter.write(sb.toString());
			myWriter.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	private static void compareWithPreviousOutput(String baseFilePath, String currentFilePath) {
		String v8Path = baseFilePath;// "C:\\Scrap\\v9\\Lamech\\WebCrawlingResults\\Crawl ReportSummary_SV8.csv";
		String v9Path = currentFilePath;// "C:\\Scrap\\v9\\Lamech\\WebCrawlingResults\\Crawl ReportSummary_SV9.csv";
		ArrayList<String> v8list = new ArrayList<>();
		ArrayList<String> v9list = new ArrayList<>();
		String line;
		BufferedReader reader;
		try {
			reader = new BufferedReader(new FileReader(v8Path));
			line = reader.readLine();
			while (line != null) {
				line = (line.replaceAll("https://", "").replaceAll("http://", ""));
				String[] parts = line.split(",");
				// str.replaceAll("/+$", "")
				if (parts.length > 1) {
					v8list.add(parts[0].replaceAll("/+$", "") + "," + parts[1].replaceAll("/+$", ""));
				}
				line = reader.readLine();
			}
			reader.close();
			reader = new BufferedReader(new FileReader(v9Path));
			line = reader.readLine();
			while (line != null) {
				String[] parts = line.replaceAll("http://", "").replaceAll("https://", "").split(",");
				if (parts.length > 1) {
					parts[0] = parts[0].replace("azne-rg-dignon-d-sitecore9-126890-cd.azurewebsites.net/",
							"www.theaa.com/");
					v9list.add(parts[0].replaceAll("/+$", "") + "," + parts[1].replaceAll("/+$", ""));
				}
				line = reader.readLine();
			}
			reader.close();
			ArrayList<String> v8listMissing = new ArrayList<>();
			ArrayList<String> v9listNew = new ArrayList<>();
			ArrayList<String> v9listLiveEndPoint = new ArrayList<>();
			v8listMissing = v8list;
			for (String temp : v9list) {
				String[] parts = temp.split(",");
				if (parts.length > 1) {
					boolean isPresentNew = true;
					v8list = v8listMissing;
					String baseDetailPrevSrc = "";
					for (String baseDetails : v8list) {
						String[] splitBase = baseDetails.split(",");
						if (splitBase.length > 1 && parts[0].equals(splitBase[0])) {
							if (parts[1].equals(splitBase[1])) {
								v9listLiveEndPoint.add(temp);
								v8listMissing.remove(baseDetails);
								isPresentNew = false;
								break;
							} else if (parts[1].replace(currentDomain,baseDomainForComp).equals(splitBase[1])) {
								v8listMissing.remove(baseDetails);
								isPresentNew = false;
								break;
							} else if (parts[1].equals(baseDetailPrevSrc) & !parts[1].equals(splitBase[0])) {
								break;
							}
							baseDetailPrevSrc = splitBase[0];
						}
					}
					if (isPresentNew) {
						v9listNew.add(temp);
						// System.out.println("PASS "+temp);
					} /*
						 * else { System.out.println("FAIL "+temp); }
						 */

				}
			}

			/*
			 * DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss"); Date
			 * date = new Date();
			 * System.out.println(dateFormat.format(date).toString().replaceAll("/",
			 * "_").replaceAll(" ", "_").replaceAll(":", "_"));
			 */
			File dir;
			dir = new File(destDir + File.separator + "CrawlHrefComparison");
			dir.mkdir();
			BufferedWriter writer;
			writer = new BufferedWriter(new FileWriter(destDir + File.separator + "CrawlHrefComparison" + File.separator
					+ "ListOfOldLinkThatAreMissing.csv", true));
			occ = extent.createTest("WebCrawlBaselineComparison");
			extentest.set(occ);
			extentest.get().log(Status.INFO,"Pass test step are not printed in report to reduce report size");
			for (String fut : v8listMissing) {
				writer.append(fut + '\n');
				extentest.get().log(Status.FAIL,fut + " ::source,destimation link is missing in latest code");
			}
			writer.close();
			writer = new BufferedWriter(new FileWriter(
					destDir + File.separator + "CrawlHrefComparison" + File.separator + "ListOfNewlyPresentLink.csv",
					true));
			for (String fut : v9listNew) {
				writer.append(fut + '\n');
				extentest.get().log(Status.FAIL,fut + " ::source,destimation link is new in latest code but was not present in baseline");
			}
			writer.close();
			writer = new BufferedWriter(new FileWriter(destDir + File.separator + "CrawlHrefComparison" + File.separator
					+ "ListofNewURLwithWrongDomain.csv", true));
			for (String fut : v9listLiveEndPoint) {
				writer.append(fut + '\n');
			}
			writer.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	private static void validateDeadLink(String crawlDetailFile) {
		// TODO Auto-generated method stub
		File file = new File(crawlDetailFile); // creates a new file instance
		FileReader fr;
		try {
			fr = new FileReader(file);
	// reads the file
		BufferedReader br = new BufferedReader(fr); // creates a buffering character input stream
		// StringBuffer sb=new StringBuffer(); //constructs a string buffer with no
		// characters
		String line;
		ArrayList<String> hrefUniqueList = new ArrayList<String>();
		while ((line = br.readLine()) != null) {
			String[] arr = line.split(",");
			System.out.println(line);
			if (arr.length > 1) {
				if(!hrefUniqueList.contains(arr[1]))
					hrefUniqueList.add(arr[1]);
			}
		}
		fr.close(); // closes the stream and release the resources
		// WriteAllUniqueHrefInAFile
		FileWriter myWriter;
		try {
			filePathForURLlist = destDir + File.separator + "ListOfUniqueHrefLink.txt";
			myWriter = new FileWriter(filePathForURLlist);
			StringBuilder sb = new StringBuilder();

			int i = 0;
			while (i < hrefUniqueList.size()) {
				sb.append(hrefUniqueList.get(i)).append("\n");
				i++;
			}
			myWriter.write(sb.toString());
			myWriter.close();
			scRedirectDetails b; // A reference to B

		    b = new scRedirectDetails(destDir + File.separator + "ListOfUniqueHrefLink.txt"); // Creating object of class B

		    scRedirectDetails.callFromOtherClass(destDir + File.separator + "ListOfUniqueHrefLink.txt",destDir);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
	}

	private static void measureSingleUserPerformance(String Path) {
		BufferedWriter writer = null;
		try {
			writer = new BufferedWriter(new FileWriter("test.bat"));
			StringBuilder updatedReport = new StringBuilder();
			updatedReport.append("CALL lighthouse-batch -f "+Path + " --html --csv -o "+destDir + File.separator+"LightHouseRepor");
			updatedReport.append("\n");
			updatedReport.append("exit");
			writer.write(updatedReport.toString());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			if (writer != null)
				try {
					writer.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		StringBuilder command = new StringBuilder("cmd /c start /wait test.bat");
	    try {
	        final Process p = Runtime.getRuntime().exec(command.toString());
	        p.waitFor();
	    } catch (InterruptedException e) {
	        System.out.println(e);
	    } catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private static void getInputDataFromFile(String filePath) {
		// TODO Auto-generated method stub
		try {
			File file = new File(filePath); // creates a new file instance
			FileReader fr = new FileReader(file); // reads the file
			BufferedReader br = new BufferedReader(fr); // creates a buffering character input stream
			// StringBuffer sb=new StringBuffer(); //constructs a string buffer with no
			// characters
			String line;
			HashMap<String, String> nameMap = new HashMap<String, String>();
			while ((line = br.readLine()) != null) {
				String[] arr = line.split(",");
				System.out.println(line);
				if (arr.length > 2)
					nameMap.put(arr[0].toString(), arr[2].toString());
			}
			fr.close(); // closes the stream and release the resources

			baseURL = nameMap.get("baseURL").toString();
			webCrawl = nameMap.get("webCrawl").equalsIgnoreCase("TRUE");
			domainRestrcitionForCrawl = nameMap.get("domainRestrcitionForCrawl").toString();
			domainApprovedForCrawl = nameMap.get("allowedDomainToCrawl").toString();
			appliTools = nameMap.get("appliTools").equalsIgnoreCase("TRUE");
			outputComparison = nameMap.get("outputComparison").equalsIgnoreCase("TRUE");
			baselineOutput = nameMap.get("baselineOutput").toString();
			filePathForURLlist = nameMap.get("filePathForURLlist").toString();
			LightHouseThreshold = nameMap.get("LightHouseThreshold").equalsIgnoreCase("TRUE");
			;
			Performance = Integer.parseInt(nameMap.get("Performance").toString());
			Accessiblity = Integer.parseInt(nameMap.get("Accessiblity").toString());
			BestPractice = Integer.parseInt(nameMap.get("BestPractice").toString());
			SEO = Integer.parseInt(nameMap.get("SEO").toString());
			ProgressiveWebApp = Integer.parseInt(nameMap.get("ProgressiveWebApp").toString());
			DeadLinkAndRedirectValidation = nameMap.get("DeadLinkAndRedirectValidation").equalsIgnoreCase("TRUE");
			baseDomainForComp = nameMap.get("baseDomainForComp").toString();
			currentDomain = nameMap.get("currentDomain").toString();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	private static void crawlWebPage(/* String baseURL, String listOfSubD */) {
		occ = extent.createTest("WebCrawling");
		extentest.set(occ);
		StringBuilder webCrawlReport = new StringBuilder();
		webCrawlReport.append("BaseURL,href").append("\n");
		com.applitools.eyes.selenium.Configuration testConfig = eyes.getConfiguration();
		crawledList.add(baseURL);
		int lCount = 0;
		List<WebElement> links = null;
		String[] apprdDomainList = domainApprovedForCrawl .split(";");
		String[] restrdDomainList = domainRestrcitionForCrawl.split(";");
 
		while (crawledList.size() > lCount) {
			String CurrentURL = null;
			System.out.println("lCount: " + lCount + "and crawledList size: " + crawledList.size());

			if (lCount >= 0) {

				try {
					String name = crawledList.get(lCount).replace("https://", "").replace("http://", "")
							.replace(currentDomain, "").replaceAll("-", "_").replace("/", "_");
					System.out.println(crawledList.get(lCount));
					String applitoolsName = "";
					if (enableAppliTools) {
						applitoolsName = crawledList.get(lCount);
						applitoolsName = applitoolsName.replace("https://", "").replace("http://", "")
								.replace(currentDomain, "Webcrawler_");
						applitoolsName = applitoolsName.replace("/", "_");
						applitoolsName = applitoolsName.replace(".", "_");
						applitoolsName = applitoolsName.replace("#", "_");
						/*
						 * eyes.setStitchMode(StitchMode.CSS); eyes.setSendDom(false);
						 */
						RectangleSize viewportSizeLandscape = new RectangleSize(1270, 460);
						testConfig.setTestName(applitoolsName);
						eyes.setConfiguration(testConfig);
						// Lamech to replace below string for CoE demo
						eyes.open(driver, "TheAA SiteCore Application", applitoolsName, viewportSizeLandscape);
					}
					driver.get(crawledList.get(lCount));
					extentest.get().log(Status.INFO, "Web crawling executed for "+crawledList.get(lCount));
					CurrentURL = crawledList.get(lCount);
					if (enableAppliTools) {
						eyes.checkWindow(applitoolsName);
						try {
							eyes.closeAsync();
						} catch (Exception e) {
							System.out.println("Eye close failed " + e);
						}
					}
					// System.out.println("CurrentURL: "+ CurrentURL);
				} catch (Exception e) {
				}

			} else if (lCount != 0 && crawledList.size() == lCount) {
				System.out.println("Execution Completed");
				System.out.println("crawledList size: " + crawledList.size());
				System.out.println("lCount: " + lCount);
				break;
			}

			try {
				links = driver.findElements(By.tagName("a"));
			} catch (Exception e) {
				e.printStackTrace();
				System.out.println("Exception to get tag name a");
			}
			ArrayList<String> refLinks = new ArrayList<>();
			String linkURL = null;
			for (int i = 0; i <= links.size() - 1; i++) {
				try {
					linkURL = links.get(i).getAttribute("href");// String linktext1=links.get(i).getText();
				} catch (Exception e) {
					e.printStackTrace();
					System.out.println("issue in taking href");
				}

				if (linkURL != null) {
					refLinks.add(linkURL);
					if (!(linkURL.startsWith("javascript:") || linkURL.startsWith("market:")
							|| linkURL.startsWith("mailto:")))
						webCrawlReport.append(CurrentURL + "," + linkURL).append("\n");
					try {
						/*if (linkURL.startsWith("https://www.theaa.com/driving-school")
								|| linkURL.startsWith("http://www.theaa.com/driving-school"))*/
						if(stringContainsItemFromList(linkURL.replace("https://", "").replace("http://", ""),apprdDomainList )){
							// check if internalValues contais linkURL, if not add it
							if(!stringContainsItemFromList(linkURL,restrdDomainList))
							if (!(linkURL.contains("http://digg.com/") || linkURL.contains("http://del.icio.us/")
									|| linkURL.contains("http://reddit.com/")
									|| linkURL.contains("http://www.facebook.com/")
									|| linkURL.contains("http://www.stumbleupon.com/")
									|| linkURL.contains("http://twitter.com/") || linkURL.contains("not-found")
									|| linkURL.contains("session=")
									|| linkURL.contains("auth/Account")
									|| linkURL.contains("media"))) {
								if (linkURL.contains("#")) {
									String[] parts = linkURL.split("#");
									linkURL = parts[0];
								}
								if (!crawledList.contains(linkURL))
									crawledList.add(linkURL);
							}
						}
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			}
			lCount++;
		}
		System.out.println("ExecutionOver");
		System.out.println("crawledList size: " + crawledList.size());
		System.out.println("lCount: " + lCount);
		FileWriter myWriter;
		try {
			filePathForURLlist = destDir + File.separator + "WebCrawlReport.csv";
			myWriter = new FileWriter(filePathForURLlist);
			myWriter.write(webCrawlReport.toString());
			myWriter.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	/**
	 * Generate Extent Report
	 * 
	 * @param @return
	 * 			@throws
	 */
	public static boolean stringContainsItemFromList(String inputStr, String[] items)
	{
	    for(int i =0; i < items.length; i++)
	    {
	        if(inputStr.contains(items[i]))
	        {
	            return true;
	        }
	    }
	    return false;
	}

	public static ExtentReports getReport() {
		String Timestamp = (new Timestamp(System.currentTimeMillis()).toString()).replace(":", "_");
		// will only contain failures
		ExtentSparkReporter sparkFail = new ExtentSparkReporter(
				destDir + File.separator + "summary_fail" + Timestamp + ".html").filter().statusFilter()
						.as(new Status[] { Status.FAIL }).apply();

		extent = new ExtentReports();
		ExtentSparkReporter reporter = new ExtentSparkReporter(
				destDir + File.separator + "summary" + Timestamp + ".html");
		reporter.config().setReportName("Automation Results");
		reporter.config().setDocumentTitle("Basic Regression Results");
		extent.attachReporter(sparkFail, reporter);
		return extent;
	}

	private static void quitDiver() {
		extentest.get().log(Status.PASS, "Test execution stated");
		extentest.get().log(Status.PASS, "<a href='file:///"+destDir+"'>Response</a>"); 
		if(appliTools) {
			ExtentTest occ=extent.createTest("WebUIValidationUsingApplitools");
			extentest.set(occ);
			extentest.get().log(Status.INFO , "View UI validathttps://eyes.applitools.com/app/test-results/");
		}
		driver.close();
	}

	private static void initiateChromeDriver() {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "C:\\ChDriv\\chromedriver.exe");
		DesiredCapabilities capabilities = DesiredCapabilities.chrome();
		capabilities.setCapability("acceptInsecureCerts", true);

		capabilities.setJavascriptEnabled(true);
		capabilities.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
		capabilities.setCapability(CapabilityType.SUPPORTS_JAVASCRIPT, true);
		ChromeOptions options = new ChromeOptions();
		capabilities.setCapability(ChromeOptions.CAPABILITY, options);
		options.merge(capabilities);
		driver = new ChromeDriver(capabilities);
		if (enableAppliTools) {
			eyes.setForceFullPageScreenshot(true);
			eyes.setApiKey("412KZhU6rrVNrk0F27582vw15VkPAiDBhE9ydkZL1071E110");
			eyes.setMatchLevel(MatchLevel.CONTENT);
			BatchInfo batch = new BatchInfo("Webcrawler");
			batch.setId("Webcrawler_version2");
			eyes.setBatch(batch);
			RectangleSize viewportSizeLandscape = new RectangleSize(1270, 460);
			eyes.setStitchMode(StitchMode.CSS);
			eyes.setSendDom(false);
		}
	}

	public static void search(final String pattern, final File folder, List<String> result) {
		for (final File f : folder.listFiles()) {

			if (f.isDirectory()) {
				search(pattern, f, result);
			}

			if (f.isFile()) {
				if (f.getName().matches(pattern)) {
					result.add(f.getAbsolutePath());
				}
			}

		}
	}

	public static void lightHouseCSVconsolidation(String reportPath) {
		// TODO Auto-generated method stub
		String folderPathCsv = reportPath;
		// String folderPathCsv =args[0];
		// args[0];
		final File folder = new File(folderPathCsv);
		List<String> result = new ArrayList<>();
		search(".*\\.csv", folder, result);

		// create new folder for report
		int i = 0;
		File reportFile = new File(destDir + "/LighthouseConsolidatedCSVreport.csv");
		BufferedReader interReader = null;
		BufferedReader reportReader = null;
		File source = new File("./base_com.report.csv");

		try {
			Files.copy(source.toPath(), reportFile.toPath());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		for (String s : result) {
			String eachRowDetails = "";
			String readReport = "";
			System.out.println(s);
			/*
			 * if (i==0) { File source = new File(s); System.out.println(s); try {
			 * Files.copy(source.toPath(), reportFile.toPath()); } catch (IOException e) {
			 * // TODO Auto-generated catch block e.printStackTrace(); } }else {
			 */
			try {
				// next light house report csv
				interReader = new BufferedReader(new FileReader(s));
				System.out.println(s);
				eachRowDetails = interReader.readLine();
				eachRowDetails = interReader.readLine();
				reportReader = new BufferedReader(new FileReader(destDir + "/LighthouseConsolidatedCSVreport.csv"));
				readReport = reportReader.readLine();
				String[] newDetails = eachRowDetails.split(",");
				readReport = readReport + "," + newDetails[0] + "\n";

				// read second line and split using ,
				// reportFile
				StringBuilder updatedReport = new StringBuilder();
				updatedReport.append(readReport);
				while (eachRowDetails != null) {
					readReport = reportReader.readLine();

					String[] newDetails2 = eachRowDetails.split(",");
					updatedReport.append(readReport + "," + newDetails2[newDetails2.length - 1] + "\n");
					eachRowDetails = interReader.readLine();
				}
				BufferedWriter writer = null;
				try {
					writer = new BufferedWriter(new FileWriter(destDir + "/LighthouseConsolidatedCSVreport.csv"));
					writer.write(updatedReport.toString());
				} finally {
					if (writer != null)
						writer.close();
				}
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			// }
			i++;
		}

	}
}
