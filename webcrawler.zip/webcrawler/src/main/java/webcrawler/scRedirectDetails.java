package webcrawler;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.SocketTimeoutException;
import java.net.URL;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class scRedirectDetails implements Callable<String> {
	 private final String  sURL;
	 static BufferedWriter writer;
	// static File dir;
	 static int timeout = 15000;
	 static HashMap<String, String> redirectDetails = new HashMap<String, String>();
    public scRedirectDetails(String sURL) {
        this.sURL = sURL;
        
    }

    @Override
    public String call() throws Exception {
        String url = sURL;
        String returnValue = null;
        int status = 0;
        String flowTest = "";
        flowTest = url;
        ArrayList<String> RedirectURLList = new ArrayList<>();
        ArrayList<Integer> RedirectCodeList = new ArrayList<>();
        //boolean SingleRedirect = false;
        int i = 0;
        try {
            boolean redirect = true;
            while (redirect) {
                i++;
                RedirectURLList.add(url);
                URL obj = new URL(url);
                HttpURLConnection conn = (HttpURLConnection) obj.openConnection();
                conn.setUseCaches(false);
                conn.setReadTimeout(timeout);
                conn.setConnectTimeout(timeout);
                conn.setInstanceFollowRedirects(false);
                conn.addRequestProperty("Accept-Language", "en-US,en;q=0.8");
                conn.addRequestProperty("User-Agent", "Mozilla");
                status = conn.getResponseCode();
                if (status != 200) {
                    if (status == 302 || status == 301 || status == 303) {
                        redirect = true;
                    } else {
                        redirect = false;
                    }
                } else {
                    redirect = false;
                }
                RedirectCodeList.add(Integer.valueOf(status));
                if (redirect) {
                    String newUrl = conn.getHeaderField("Location");
                    url = newUrl;
                    /*if (SingleRedirect) {
                        redirect = false;
                    }*/
                }
                flowTest = flowTest + "->(" + status + ")" + url;
                /*if (SingleRedirect) {
                    flowTest = flowTest + "-> (200)";
                    status = 200;
                }*/
            }
            RedirectURLList.add(url);
            boolean bFinalRedirectURLNotValid = Integer.toString(status).equals("200");
            String sFinalRedirectURLNotValid = bFinalRedirectURLNotValid ? "PASS" : "FAIL";
            returnValue = sURL + "," + (String) RedirectURLList.get(1) + "," + RedirectCodeList.get(0) + "," + url + "," + status + "," + (i - 1) + "," + sFinalRedirectURLNotValid + "," + flowTest + '\n';
        } catch (SocketTimeoutException e) {
            if (RedirectCodeList.size() > 0) {
            	returnValue = sURL + "," + (String) RedirectURLList.get(1) + "," + RedirectCodeList.get(0) + ",Connection Time out," + status + "," + (i) + "," + "FAIL-DeadLink" + "," + flowTest + '\n';
            } else {
            	returnValue = sURL + "," + "Time Out" + "," + RedirectCodeList.get(0) + ",Connection Time out," + ",Connection Time out," + "," + (i) + "," + "FAIL-DeadLink" + "," + flowTest + '\n';
            }

        } catch (Exception e) {
        	if (RedirectCodeList.size() > 0) {
            	returnValue = sURL + "," + (String) RedirectURLList.get(1) + "," + RedirectCodeList.get(0) + ",Connection Exception," + status + "," + (i) + "," + "FAIL-DeadLink" + "," + flowTest + '\n';
            } else {
            	System.out.println(e);
            	returnValue = sURL + "," + "Exception" + "," + RedirectCodeList.get(0) + ",Connection Exception," + ",Connection Exception," + "," + (i) + "," + "FAIL-DeadLink" + "," + flowTest + '\n';
            }

            //System.out.println("Flow is ::: " + flowTest + "And number of hop is " + i);
            e.printStackTrace();
        }
        System.out.println(returnValue);
        return returnValue;
    }
	public static void callFromOtherClass(String filePathCrawlDetails,String reportPath) {
		// TODO Auto-generated method stub
		//String urlListFilePath = args[0];
		String urlListFilePath = filePathCrawlDetails;//"C:\\Scrap\\hemanthRedirectValidation_2.txt";
		String tempRow;
		ExecutorService executor = Executors.newFixedThreadPool(14);
		List<Future<String>> list = new ArrayList<Future<String>>();
		BufferedReader reader;
		try {
			reader = new BufferedReader(new FileReader(urlListFilePath));
			String line = reader.readLine();
			line = reader.readLine();
	        while (line != null) {
	        	Callable<String> callable = new scRedirectDetails(line.trim());
	        	Future<String> future = executor.submit(callable);
	        	list.add(future);
	        	line = reader.readLine();
	        }
	        /*DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
            Date date = new Date();
	        dir = new File("." + File.separator + dateFormat.format(date).toString().replaceAll("/", "_").replaceAll(" ", "_").replaceAll(":", "_"));
	        dir.mkdir();*/
	        writer = new BufferedWriter(new FileWriter(reportPath + File.separator + "DeadLinkRedirectValidation.csv", true));
            writer.append("SourceURL,FirstRedirectURL,RedirectCodeList,FinalRedirectURL,FinalHttpStatusCode,NoOfHops,Status,URL_Flow\n");
	        for (Future<String> fut : list) {
                try {
                    //print the return value of Future, notice the output delay in console
                    // because Future.get() waits for task to get completed
                    tempRow = fut.get();
                    writer.append(tempRow);
                    //newRedirectDetails.add(tempRow);
                    }
                 catch (InterruptedException | ExecutionException e) {
                    e.printStackTrace();
                }
            }
	        writer.close();
	        reader.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        
		executor.shutdown();
	}

}

