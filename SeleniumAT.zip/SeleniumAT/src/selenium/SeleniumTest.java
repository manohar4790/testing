package selenium;


import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.ParseException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.mime.HttpMultipartMode;
import org.apache.http.entity.mime.MultipartEntityBuilder;
import org.apache.http.entity.mime.content.FileBody;
import org.apache.http.impl.client.HttpClientBuilder;
import org.json.JSONException;
import org.json.JSONObject;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import seleniumcolorcontrast.ColorContrast;

public class SeleniumTest {
	private static final String lineSeparator = System.getProperty("line.separator");
	private static WebDriver driver;
	static JSONObject colorObject=new JSONObject();
	public static void main(String args[]) throws ParseException, IOException, JSONException{
		String jsn = args[0];
		//System.out.println("HIIII:");
		//System.out.println(jsn);
		JSONObject json = new JSONObject(jsn);
		//System.out.println(json);
		JSONObject tempObj = (JSONObject) json.get("scriptid");
		String scriptid = tempObj.getString("$oid");
		String filepath = (String) json.get("filepath");
		String Runid =json.get("Runid").toString();
		String applicationName = (String) json.get("applicationName");
		String scriptname = (String) json.get("scenarioname");
		JSONObject tempObj2 = (JSONObject) json.get("customerid");
		String customerid = tempObj2.getString("$oid");
		JSONObject tempObj3 = (JSONObject) json.get("appid");
		String appid = tempObj3.getString("$oid");
		String pagesourcepath = filepath +File.separator+ scriptid +File.separator+Runid;
		ClassLoader classLoader = new SeleniumTest().getClass().getClassLoader();
		System.setProperty("webdriver.chrome.driver", "C:\\Accessibility\\ChromeDriver\\chromedriver.exe");
		driver =new ChromeDriver();
		driver.getCurrentUrl();
		String foldername=pagesourcepath;
		createfiles(foldername);
		ColorContrast coloranalysis=new ColorContrast();

		/*Each pagesource and coloranalysis data */ 
		//Page 1
		String homepageurl="https://www.guardianlife.com/retirement";
		driver.get(homepageurl);      		
		driver.manage().window().maximize(); 
		String page1html=driver.getPageSource();
		String Page1="Homepage";
		List firstPagesrc=coloranalysis.Launchjs(driver);
		colorObject.put(Page1,firstPagesrc);		
		Writer fpwriter = null;
		try {
			fpwriter = new BufferedWriter(new OutputStreamWriter(
			new FileOutputStream(foldername+"\\"+Page1+".txt"), "utf-8"));
			fpwriter.write(page1html);
			fpwriter.close();
		} catch (IOException ex) 
		{
		} 
			
		//Page 2		
		String Page2url="https://www.guardianlife.com/life-insurance";
		driver.get(Page2url);
		driver.manage().window().maximize();
		String page2html=driver.getPageSource();
		String Page2="Insurance";
		List secondPagesrc=coloranalysis.Launchjs(driver);
		colorObject.put(Page2,secondPagesrc);
		Writer spwriter = null;
		try {
			spwriter = new BufferedWriter(new OutputStreamWriter(
			new FileOutputStream(foldername+"\\"+Page2+".txt"), "utf-8"));
			spwriter.write(page2html);
			spwriter.close();
		} catch (IOException ex) 
		{
		} 
		
		/* Writing colorObject to color json */
		Writer colorjson = null;
		try {
			colorjson = new BufferedWriter(new OutputStreamWriter(
			new FileOutputStream(foldername+"\\color.json"), "utf-8"));
			colorjson.write(colorObject.toString());
			colorjson.close();
		} catch (IOException ex) {
		} 
				
             /* zipping htmlsource files */        
		zipDirectory(foldername,foldername+".zip");            
		File file = new File(foldername+".zip");
		FileBody fileBody = new FileBody(file, ContentType.DEFAULT_BINARY);
		
		/* building input to the IAAT API */
		MultipartEntityBuilder builder = MultipartEntityBuilder.create();
		builder.setMode(HttpMultipartMode.BROWSER_COMPATIBLE);
     	builder.addTextBody("appid", appid);
     	builder.addTextBody("appname", applicationName);
     	builder.addTextBody("customerid",customerid);
     	builder.addTextBody("scriptid", scriptid);
     	builder.addTextBody("scenarioname", scriptname);
     	builder.addTextBody("textfilepath", foldername);
     	builder.addTextBody("runid",Runid.toString());
		HttpEntity entity = builder.build();
		HttpPost request = new HttpPost("http://localhost:8080/ATAP_Selenium/rest/servicedetails/upload");
		request.setEntity(entity);
		HttpClient client = HttpClientBuilder.create().build();
		try {
			HttpResponse response= client.execute(request);
			HttpEntity entity1 = response.getEntity();
			// Read the contents of an entity and return it as a String.
			String myResponse = new String(response.toString());			
			} catch (IOException e) {
			e.printStackTrace();
			}
	}

	public static void zipDirectory(String sourceDirectoryPath, String zipPath) throws IOException 
	{
		if(zipPath!=null)
		{    		    	
			Path zipFilePath = Files.createFile(Paths.get(zipPath));

			try (ZipOutputStream zipOutputStream = new ZipOutputStream(Files.newOutputStream(zipFilePath))) 
			{
				Path sourceDirPath = Paths.get(sourceDirectoryPath);
				Files.walk(sourceDirPath).filter(path -> !Files.isDirectory(path))
				.forEach(path -> {
					ZipEntry zipEntry = new ZipEntry(sourceDirPath.relativize(path).toString());
					try {
						zipOutputStream.putNextEntry(zipEntry);
						zipOutputStream.write(Files.readAllBytes(path));
						zipOutputStream.closeEntry();
					} catch (Exception e) {
						System.err.println(e);
					}
				});
			}
		}
	}

	public static void createfiles(String foldername) throws IOException {

		// Use relative path for Unix systems
		File f = new File(foldername);

		// f.getParentFile().mkdirs(); 

		if(!f.exists()){
			f.mkdirs();

			//writeUsingOutputStream(pagesource,path);
		}

	}
}
