var express = require('express');
var router = express.Router();
var config = require('../configuration.json');

let validationRoute = require('./validation.js');



//Getting ToolURI 
router.get('/getToolURI', function (req, res) {
    res.header("Strict-Transport-Security", "max-age=604800"); // 1 week in seconds   
    res.header('Cache-Control', 'private, no-cache, no-store, must-revalidate');
    console.log("-----getToolURI------");

    var customerID = req.decoded.customerID;
    if (customerID === null || customerID === undefined || customerID === "") {
        return res.status(404).json("Token is not valid");
    }
    var toolName = req.query.toolName;
    if (toolName === null || toolName === undefined || toolName === "" || validationRoute(toolName)) {
        return res.status(404).json("Tool Name is not specified or not valid");
    }

    let toolJson = getToolURI(toolName);
    return res.status(200).json(toolJson);
});//end of //Getting ToolURI 


function getToolURI(toolName) {
    try {
        let serverURI = "", port = "", serverURL = "", secretKey = "";
        switch (toolName) {
            case "CIPTS": {
                serverURI = config.CIPTS_serverURI;
                port = config.CIPTS_port;
                break;
            };
            case "CIEEM": {
                serverURI = config.CIEEM_serverURI;
                port = config.CIEEM_port;
                break;
            };
            case "CxPerf": {
                serverURI = config.CxPerf_serverURI;
                port = config.CxPerf_port;
                break;
            };
            case "MobilePerf": {
                serverURI = config.MobilePerf_serverURI;
                port = config.MobilePerf_port;
                break;
            };
            case "Scrambled": {
                serverURI = config.scrambled_serverURI;
                port = config.scrambled_port;
                secretKey = config.scrambledSecretKey;
                break;
            };
        }
        if (serverURI == "" || port == "") {
            return res.status(500).json({ error: "NOT FOUND" });
        }

        if (port == "80") {
            serverURL = "http://" + serverURI;
        } else if (port == "443") {
            serverURL = "https://" + serverURI;
        } else {
            serverURL = "http://" + serverURI + ":" + port;
        }
        let responseDoc = { URI: serverURL, toolName: toolName };
        if (toolName == "Scrambled") {
            responseDoc.secretKey = secretKey;
        }
        return (responseDoc);
    } catch (e) {
        console.log("Error in  getToolURI" + e);
        return ({ error: e });
    }
}

//Getting ToolURIs
router.get('/getToolURIs', function (req, res) {
    res.header("Strict-Transport-Security", "max-age=604800"); // 1 week in seconds   
    res.header('Cache-Control', 'private, no-cache, no-store, must-revalidate');
    console.log("-----getToolURI------");

    var customerID = req.decoded.customerID;
    if (customerID === null || customerID === undefined || customerID === "") {
        return res.status(404).json("Token is not valid");
    }

    let toolURIs = [];
    toolURIs.push(getToolURI("CIPTS"));
    toolURIs.push(getToolURI("CIEEM"));
    toolURIs.push(getToolURI("CxPerf"));
    toolURIs.push(getToolURI("MobilePerf"));
    toolURIs.push(getToolURI("Scrambled"));
    return res.status(200).json(toolURIs);
});//end of //Getting ToolURIs 



module.exports = router;
