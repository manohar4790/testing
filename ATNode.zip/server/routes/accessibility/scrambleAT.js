var express = require('express');
var router = express.Router();
var config = require('../../configuration.json');
var uploadPath = config.uploadPath;
let validationRoute = require('../validation.js');
var fs = require('fs');
var path = require('path');
var mongodb = require('mongodb');
//Using mongoclient, not using mongoose
let ObjectID = mongodb.ObjectID;
var MongoClient = mongodb.MongoClient;
var dbURL = config.mongoDBURL;
let db;
MongoClient.connect(dbURL, function (err, mydb) {
    if (err) {
        console.log(' ERROR : scrambleAT.js in DB connection failed using mongodb');
        return err;
    } else {
        db = mydb.db();
        console.log('scrambleAT.js : DB connection established using mongodb!');
    }
});

router.get('/getScramble', function (req, res) {
    res.header("Strict-Transport-Security", "max-age=604800"); // 1 week in seconds   
    res.header('Cache-Control', 'private, no-cache, no-store, must-revalidate');
    console.log("-----getScramble in scramble ------");
    let serverURI, port, secretKey;
    serverURI = config.scrambled_serverURI;
    port = config.scrambled_port;
    secretKey = config.scrambledSecretKey;

    if (serverURI == "" || port == "") {
        return res.status(500).json({ error: "NOT FOUND" });
    }
    if (port == "80") {
        serverURL = "http://" + serverURI;
    } else if (port == "443") {
        serverURL = "https://" + serverURI;
    } else {
        serverURL = "http://" + serverURI + ":" + port;
    }
    let responseDoc = { URI: serverURL, secretKey: secretKey };
    return res.status(200).json(responseDoc);
});//end of //Getting Scramble 

router.get('/getTestDetailsByID', function (req, res, next) {
    res.header("Strict-Transport-Security", "max-age=604800"); // 1 week in seconds   
    res.header('Cache-Control', 'private, no-cache, no-store, must-revalidate');
    console.log("-----getTestDetailsByID------");
    var testrunnid = req.query.objectid;
    if (testrunnid === null || testrunnid === undefined || testrunnid === "" || validationRoute(testrunnid)) {
        return res.status(404).json("Test Run ID is not valid");
    }
    var bsonID = mongodb.ObjectID(testrunnid);
    db.collection('TestRuns').findOne({ "_id": bsonID }, function (err, records) {
        if (err) {
            return res.status(500).json(err);
        } else {
            return res.status(200).json(records);
        }
    });
});
router.get('/getmlrecords', function (req, res, next) {
    console.log("-----getmlrecords------");
    var testrunnid = req.query.objectid;
    res.header("Strict-Transport-Security", "max-age=604800"); // 1 week in seconds   
    res.header('Cache-Control', 'private, no-cache, no-store, must-revalidate');
    if (testrunnid === null || testrunnid === undefined || testrunnid === "" || validationRoute(testrunnid)) {
        return res.status(404).json("Test Run ID is not valid");
    }
    var bsonID = mongodb.ObjectID(testrunnid);

    db.collection('TestRuns').findOne({ "_id": bsonID }, function (err, records) {
        if (err) {
            return res.status(500).json(err);
        } else {
            db.collection('MLRuns').findOne({
                "customerid": mongodb.ObjectID(records["customerid"])
                , "appid": mongodb.ObjectID(records["appid"]), "scriptid": mongodb.ObjectID(records["scriptid"]),
                "runid": records["runid"], "scenarioname": records["scenarioname"]
            }, function (err, record) {
                if (err) {
                    return res.status(500).json(err);
                } else {
                    return res.status(200).json(record);
                }
            });
        }
    });
});

module.exports = router;