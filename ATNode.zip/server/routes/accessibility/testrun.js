var express = require('express');
var router = express.Router();
var config = require('../../configuration.json');
var fs = require('fs');
var path = require('path');
var mongodb = require('mongodb');
//Using mongoclient, not using mongoose
let ObjectID = mongodb.ObjectID;
var MongoClient = mongodb.MongoClient;
var dbURL = config.mongoDBURL;
let db;
MongoClient.connect(dbURL, function (err, mydb) {
    if (err) {
        console.log('userAPI.js : ERROR : DB connection failed using mongodb');
        return err;
    } else {
        db = mydb.db();
        console.log('userAPI.js : DB connection established using mongodb!');
    }
});


router.get('/getTestRun', function (req, res) {
    res.header("Strict-Transport-Security", "max-age=604800"); // 1 week in seconds   
    res.header('Cache-Control', 'private, no-cache, no-store, must-revalidate');
    console.log("-----getTestRun------");

    var customerID = req.decoded.customerID;
    var applicationId = req.query.appid;
    if (customerID === null || customerID === undefined || customerID === "") {
        return res.status(404).json("Token is not valid");
    }
    console.log(" customerID : " + customerID);
    var bsonCustomerID = mongodb.ObjectID(customerID);
    var bsonAppId = mongodb.ObjectID(applicationId);
    console.log(bsonAppId);
    var testRun = [];
    db.collection("TestRuns").find({ "customerId": bsonCustomerID, "applicationId": bsonAppId }).toArray((err, result) => {
        if (err) {
            return res.status(500).json("Internal Server error");
        } else {
            testRun = result;
            testRun.reverse();
            return res.status(200).json(testRun);
        }
    })
})

router.get('/getTestSummary', function (req, res) {
    res.header("Strict-Transport-Security", "max-age=604800"); // 1 week in seconds   
    res.header('Cache-Control', 'private, no-cache, no-store, must-revalidate');
    console.log("-----getTestSummary------");

    var customerID = req.decoded.customerID;
    var applicationId = req.query.appid;
    var runId = req.query.runId;
    if (customerID === null || customerID === undefined || customerID === "") {
        return res.status(404).json("Token is not valid");
    }
    console.log(" customerID : " + customerID);
    var bsonCustomerID = mongodb.ObjectID(customerID);
    var bsonAppId = mongodb.ObjectID(applicationId);
    var bsonRunId = mongodb.ObjectID(runId);;
    console.log(bsonAppId);
    let scriptName = "";
    db.collection("TestRuns").find({ "customerId": bsonCustomerID, "applicationId": bsonAppId, "_id": bsonRunId }).toArray((err, result) => {
        if (err) {
            return res.status(500).json("Internal Server error");
        } else {
            var TransactionsList = [];
            for (let tempSum of result) {
                let runid = tempSum._id;
                scriptName = tempSum.scriptname
                for (let tempTrans of tempSum.transaction) {
                    let tempjson = {
                        "Runid": runid,
                        "transactionId": tempTrans.transactionId,
                        "transactionName": tempTrans.transactionName,
                        "firstUser": tempTrans.firstUser,
                        "Avg_RT": tempTrans.Avg_RT,
                        "_95_percentile": tempTrans._95_percentile,
                        "sla": tempTrans.sla,
                    }
                    TransactionsList.push(tempjson);
                }
            }
            var resultJson = {
                "TransactionsList": TransactionsList,
                "scriptName": scriptName
            }
            return res.status(200).json(resultJson);
        }
    })
})

router.get('/getTestResultForTransList', function (req, res) {
    res.header("Strict-Transport-Security", "max-age=604800"); // 1 week in seconds   
    res.header('Cache-Control', 'private, no-cache, no-store, must-revalidate');
    console.log("-----getTestResultForTransList------");
    var customerID = req.decoded.customerID;
    var applicationId = req.query.appid;
    var runId = req.query.runId;
    var transactionId = req.query.transactionId;
    if (customerID === null || customerID === undefined || customerID === "") {
        return res.status(404).json("Token is not valid");
    }
    console.log(" customerID : " + customerID);
    var bsonCustomerID = mongodb.ObjectID(customerID);
    var bsonAppId = mongodb.ObjectID(applicationId);
    var bsonRunId = mongodb.ObjectID(runId);
    let customerName = "";
    let transactionList = [];
    let IterationList = [];
    transaction = "";
    db.collection("TestResults").find({ "customerId": bsonCustomerID, "applicationId": bsonAppId, "Runid": bsonRunId }).toArray((err, result) => {
        if (err) {
            return res.status(500).json("Internal Server error");
        } else {
            let transactions = result[0].Transactions;
            for (let tran of transactions) {
                transactionList.push({ "transactionId": tran.transactionID, "transactionName": tran.transactionName });
                if (tran.transactionID == transactionId) {
                    transaction = { "transactionId": tran.transactionID, "transactionName": tran.transactionName };
                    for (let iteration of tran.Iterations)
                        IterationList.push({ "iterationnum": iteration.iterationnum, "transactionId": tran.transactionID, "transactionName": tran.transactionName })
                }
            }
            resultJson = {
                "transactionList": transactionList,
                "IterationList": IterationList,
                "scriptname": result[0].scriptname,
                "transaction": transaction
            }
            return res.status(200).json(resultJson);
        }
    })
})

router.get('/getPageStatus', function (req, res) {
    res.header("Strict-Transport-Security", "max-age=604800"); // 1 week in seconds   
    res.header('Cache-Control', 'private, no-cache, no-store, must-revalidate');
    console.log("-----getPageStatus------");

    var customerID = req.decoded.customerID;
    console.log(" req.query.appid : " + req.query.appid);
    var applicationId = req.query.appid;
    var runId = req.query.runId;
    var transactionId = req.query.transactionId;
    var iteration_Num = req.query.Iteration_num;
    if (customerID === null || customerID === undefined || customerID === "") {
        return res.status(404).json("Token is not valid");
    }
    console.log(" customerID : " + customerID);
    var bsonCustomerID = mongodb.ObjectID(customerID);
    var bsonAppId = mongodb.ObjectID(applicationId);
    var bsonRunId = mongodb.ObjectID(runId);
    console.log(" transactionId " + transactionId);
    let customerName = "";
    var resultJson;
    db.collection("TestResults").find({ "customerId": bsonCustomerID, "applicationId": bsonAppId, "Runid": bsonRunId }).toArray((err, result) => {
        if (err) {
            return res.status(500).json("Internal Server error");
        } else {
            console.log(result[0].Transactions.length);
            let transactions = result[0].Transactions;
            for (let tran of transactions) {

                if (tran.transactionID == transactionId) {
                    for (let iteration of tran.Iterations) {
                        if (iteration.iterationnum == iteration_Num) {
                            var errorMessage=iteration.errorMessage
                            if(errorMessage==null || errorMessage==undefined){
                                errorMessage="";
                            }                            
                            resultJson = {
                                "responseTime": iteration.responsetime,
                                "onLoadTime": iteration.LoadTime,
                                "TransactionSize": iteration.TotalTransactionSize,
                                "RequestsCount": iteration.TotalRequestsCount,
                                "logjson": iteration.logjson,
                                "itrsStatus":iteration.itrstatus,
                                "errorMessage":errorMessage
                            }
                        }
                    }
                }
            }
            console.log(resultJson);
            return res.status(200).json(resultJson);
        }
    })
})


router.get('/getPageLoadTimings', function (req, res) {
    res.header("Strict-Transport-Security", "max-age=604800"); // 1 week in seconds   
    res.header('Cache-Control', 'private, no-cache, no-store, must-revalidate');
    console.log("-----getPageLoadTimings------");

    var customerID = req.decoded.customerID;
    console.log(" req.query.appid : " + req.query.appid);
    var applicationId = req.query.appid;
    var runId = req.query.runId;
    var transactionId = req.query.transactionId;
    var iteration_Num = req.query.Iteration_num;
    if (customerID === null || customerID === undefined || customerID === "") {
        return res.status(404).json("Token is not valid");
    }
    console.log(" customerID : " + customerID);
    var bsonCustomerID = mongodb.ObjectID(customerID);
    var bsonAppId = mongodb.ObjectID(applicationId);
    var bsonRunId = mongodb.ObjectID(runId);
    console.log(" transactionId " + transactionId);
    db.collection("TestResults").find({ "customerId": bsonCustomerID, "applicationId": bsonAppId, "Runid": bsonRunId }).toArray((err, result) => {
        if (err) {
            return res.status(500).json("Internal Server error");
        } else {
            console.log(result[0].Transactions.length);
            let transactions = result[0].Transactions;
            var PageLoadTime = [
                {
                    "name": "Page Load Timings",
                    "series": [

                        {
                            "name": "InitialConnection",
                            "value": 0
                        },
                        {
                            "name": "TimeToFirstByte",
                            "value": 0
                        }, {
                            "name": "DOMLoadingtoLoaded",
                            "value": 0
                        }, {
                            "name": "DOMLoadingtoComplete",
                            "value": 0
                        }//, {
                        //     "name": "TotalLoadTime",
                        //     "value": 0
                        // },
                    ]
                }];
            for (let tran of transactions) {

                if (tran.transactionID == transactionId) {
                    for (let iteration of tran.Iterations) {
                        if (iteration.iterationnum == iteration_Num) {
                            var keys = Object.keys(iteration.performancejson);
                            //console.log(keys);
                            for (let keylog of keys) {

                                switch (keylog) {
                                    case "InitialConnection": {
                                        PageLoadTime[0].series[0].value = Number(iteration.performancejson[keylog])
                                        break;
                                    }
                                    case "TimeToFirstByte": {
                                        PageLoadTime[0].series[1].value = Number(iteration.performancejson[keylog])
                                        break;
                                    }
                                    case "DOMLoadingtoLoaded": {
                                        PageLoadTime[0].series[2].value = Number(iteration.performancejson[keylog])
                                        break;
                                    }
                                    case "DOMLoadingtoComplete": {
                                        PageLoadTime[0].series[3].value = Number(iteration.performancejson[keylog])
                                        break;
                                    }
                                    // case "TotalLoadTime": {
                                    //     PageLoadTime[0].series[4].value = Number(iteration.performancejson[keylog])
                                    //     break;
                                    // }
                                }

                            }

                        }
                    }
                }
            }

            return res.status(200).json(PageLoadTime);
        }
    })
})



router.get('/getRecommendation', function (req, res) {
    res.header("Strict-Transport-Security", "max-age=604800"); // 1 week in seconds   
    res.header('Cache-Control', 'private, no-cache, no-store, must-revalidate');
    console.log("-----getRecommendation------");

    var customerID = req.decoded.customerID;
    console.log(" req.query.appid : " + req.query.appid);
    var applicationId = req.query.appid;
    var runId = req.query.runId;
    var transactionId = req.query.transactionId;
    var iteration_Num = req.query.Iteration_num;
    if (customerID === null || customerID === undefined || customerID === "") {
        return res.status(404).json("Token is not valid");
    }
    console.log(" customerID : " + customerID);
    var bsonCustomerID = mongodb.ObjectID(customerID);
    var bsonAppId = mongodb.ObjectID(applicationId);
    var bsonRunId = mongodb.ObjectID(runId);
    console.log(" transactionId " + transactionId);
    let customerName = "";
    var resultJson = [];
    db.collection("TestResults").find({ "customerId": bsonCustomerID, "applicationId": bsonAppId, "Runid": bsonRunId }).toArray((err, result) => {
        if (err) {
            return res.status(500).json("Internal Server error");
        } else {
            console.log(result[0].Transactions.length);
            let transactions = result[0].Transactions;
            for (let tran of transactions) {

                if (tran.transactionID == transactionId) {
                    for (let iteration of tran.Iterations) {
                        if (iteration.iterationnum == iteration_Num) {

                            for (let temp of iteration.recommendation) {
                                if (temp.Recommendation != "none") {
                                    resultJson.push(temp);
                                }
                            }
                        }
                    }
                }
            }

            return res.status(200).json(resultJson);
        }
    })
})


router.get('/getHarData', function (req, res) {
    res.header("Strict-Transport-Security", "max-age=604800"); // 1 week in seconds   
    res.header('Cache-Control', 'private, no-cache, no-store, must-revalidate');
    console.log("-----getHarData------");

    var customerID = req.decoded.customerID;
    console.log(" req.query.appid : " + req.query.appid);
    var applicationId = req.query.appid;
    var runId = req.query.runId;
    var transactionId = req.query.transactionId;
    var iteration_Num = req.query.Iteration_num;
    var transactionName = req.query.transactionName;
    if (customerID === null || customerID === undefined || customerID === "") {
        return res.status(404).json("Token is not valid");
    }
    console.log(" customerID : " + customerID);
    var bsonCustomerID = mongodb.ObjectID(customerID);
    var bsonAppId = mongodb.ObjectID(applicationId);
    var bsonRunId = mongodb.ObjectID(runId);
    console.log(" transactionId " + transactionId);
    let customerName = "";
    var resultJson = [];
    var fileName = "";
    var filePath = "";
    var HarData = {};
    filePath = config.assetsPath + customerID + '/' + runId;
    fileName = transactionName + "_" + iteration_Num + ".har";
    console.log(" filePath  :  " + filePath);
    /*   if (!fs.existsSync(filePath)) {
          console.log(" File Path for HAr File does not exist")
          return res.status(500).json("Internal Server error");
      }
      else { */
    var fileRead = filePath + '/' + fileName;
    console.log(" fileRead : " + fileRead);
    fs.readFile(fileRead, (err, data) => {
        if (err) {
            console.log(err);
            console.log(" Error in reading har file ")
        } else {
            HarData = JSON.parse(data);
            return res.status(200).json(HarData);
            //your code using json object
        }
    })
    //  }

    //return res.status(200).json(resultJson);
    /*     db.collection("TestResults").find({ "customerId": bsonCustomerID, "applicationId": bsonAppId, "Runid": bsonRunId }).toArray((err, result) => {
            if (err) {
                return res.status(500).json("Internal Server error");
            } else {
                console.log(result[0].Transactions.length);
                let transactions = result[0].Transactions;
                for (let tran of transactions) {
    
                    if (tran.transactionId == transactionId) {
                       // filePath=filePath+'/'+tran.transactionId+'/';
                        for (let iteration of tran.Iterations) {
                            if (iteration.iterationnum == iteration_Num) {
                                iteration.HarJson
                               
                            }
                        }
                    }
                }
    
                return res.status(200).json(resultJson);
            }
        }) */
})

router.delete('/deleteTestRunDocument', function (req, res) {
    res.header("Strict-Transport-Security", "max-age=604800"); // 1 week in seconds   
    res.header('Cache-Control', 'private, no-cache, no-store, must-revalidate');
 
    var id = req.query.customerId;
    var runId=req.query.runId;
    if (typeof runId == "undefined" || runId === "" || runId === null) {
      return res.status(500).json("the values sent may be undefined null or empty");
    }
    db.collection("TestRuns").removeOne({ "_id": mongodb.ObjectID(runId) }, function (err, result) {
      if (err) {
        console.log("Error in deleting Test Run document : " + err);
        return res.status(500).json(err);
      }
      else {
        console.log("No Error in deleting Test Run document  : ");
        db.collection("TestResults").removeOne({ "Runid": mongodb.ObjectID(runId) }, function (err, result) {
            if (err) {
              console.log("Error in deleting Test Result Document : " + err);
              return res.status(500).json(err);
            }
            else {
              console.log("No Error in  deleting Test Result Document : ");
              return res.status(200).json("Test Results and Test Runs deleted Successfully ");
            }
          });
      }
    });
  
  
  });


module.exports = router;