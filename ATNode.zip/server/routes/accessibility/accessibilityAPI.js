
var express = require('express');
//require the express router
var router = express.Router();
var multer = require('multer')
var config = require('./../../configuration.json');
var mongodb = require('mongodb');
var fs = require('fs')
let request = require('request');
let validationRoute = require('../validation.js');
//Using mongoclient, not using mongoose
var MongoClient = mongodb.MongoClient;
var dbURL = config.mongoDBURL;
let db;
function currentdate() {
  var d = new Date();
  var date = '' + d.getDate();
  var month = '' + (d.getMonth() + 1);
  var year = d.getFullYear();
  var sec = '' + d.getSeconds()
  var hour = '' + d.getHours() > 12 ? d.getHours() - 12 : d.getHours();
  hour = hour < 10 ? '0' + hour : hour;
  var minutes = d.getMinutes() < 10 ? '0' + d.getMinutes() : d.getMinutes();
  if (date.length < 2)
    date = '0' + date;
  if (month.length < 2)
    month = '0' + month;
  if (hour.length < 2)
    hour = '0' + hour;
  if (sec.length < 2)
    sec = '0' + sec;
  if (minutes.length < 2)
    minutes = '0' + minutes;
  var ampm = d.getHours() < 12 ? 'AM' : 'PM';
  var time = date + '-' + month + '-' + year + ' ' + hour + ':' + minutes + ':' + sec + ' ' + ampm + ' GMT';
  return time
}
const { json } = require('body-parser');
MongoClient.connect(dbURL, function (err, mydb) {
  if (err) {
    ////console.log('accessibility.js : ERROR: DB connection failed');
    return err;
  } else {
    db = mydb.db();
    ////console.log('accessibility.js : DB connection established!');
  }
});
var storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, config.tempftpPath)
  },
  filename: function (req, file, cb) {
    var fname = file.originalname;

    cb(null, fname);
  }
});
//Get Test Details By ID




router.post('/savescenario', function (req, res, next) {
  var upload = multer({
    storage: storage
  }).single('file');

  upload(req, res, function (err) {
    if (err) {
      // An error occurred when uploading
      //console.log(err);
      return res.status(422).send("" + err);
    } else {
      ////console.log(req.body)
      var type = (req.body.type);
      var custid = req.decoded.customerID;
      var scriptid = new mongodb.ObjectID();
      ////console.log(scriptid)
      var appid = req.query.appid;
      var scenarioname = req.body.scenarioname;
      var appurl = req.body.appurl;
      ////console.log(req.file.filename);
      //////console.log(" customerName : "+customerName+" applicationName : "+applicationName);
      //Check if customer folder exists - if not create it
      var folderName = config.ftpPath + appid + '_' + custid;
      if (!fs.existsSync(folderName)) {
        fs.mkdirSync(folderName);
        //////console.log('Folder ' + folderName + ' was created!');
      }

      folderName = folderName + "/" + scenarioname + '_' + scriptid;
      if (!fs.existsSync(folderName)) {
        fs.mkdirSync(folderName);
      }
      fs.copyFileSync(config.tempftpPath + req.file.filename, folderName + '/' + req.file.filename, function (err) {
        if (err) {
          console.error(err);
        } else {
          fs.unlinkSync(config.tempftpPath + req.file.filename)
        }
      });

      let bsoncustid = mongodb.ObjectID(custid);
      let bsonappid = mongodb.ObjectID(appid)
      db.collection("ScenariosList").insertOne({ "timestamp": currentdate(), "customerId": bsoncustid, "appid": bsonappid, "scriptid": scriptid, "scenarioname": scenarioname, "type": type, "appurl": appurl, "filepath": folderName, "filename": req.file.filename }, function (err, result) {
        if (err) {
          ////console.log(err);
          return null;
        }
        else {
          ////console.log("inserted");
          return res.status(200).json("success");
        }
      })

    }
  });
  //res.send("success")
});
router.post('/updatescenario', function (req, res, next) {

  var upload = multer({
    storage: storage
  }).single('file');

  upload(req, res, function (err) {
    if (err) {
      // An error occurred when uploading
      //console.log(err);
      return res.status(422).send("" + err);
    } else {
      console.log(req.body.scriptid)
      var type = (req.body.type);
      var custid = req.decoded.customerID;
      var scriptid = new mongodb.ObjectID(req.body.scriptid);
      var appid = req.query.appid;
      var scenarioname = req.body.scenarioname;
      var appurl = req.body.appurl;
      ////console.log(req.file.filename);
      //////console.log(" customerName : "+customerName+" applicationName : "+applicationName);
      //Check if customer folder exists - if not create it
      var folderName = config.ftpPath + appid + '_' + custid;
      if (!fs.existsSync(folderName)) {
        fs.mkdirSync(folderName);
        //////console.log('Folder ' + folderName + ' was created!');
      }

      folderName = folderName + "/" + scenarioname + '_' + scriptid;
      if (!fs.existsSync(folderName)) {
        fs.mkdirSync(folderName);
      }
      fs.copyFileSync(config.tempftpPath + req.file.filename, folderName + '/' + req.file.filename, function (err) {
        if (err) {
          console.error(err);
        } else {
          fs.unlinkSync(config.tempftpPath + req.file.filename)
        }
      });

      let bsoncustid = mongodb.ObjectID(custid);
      let bsonappid = mongodb.ObjectID(appid)
      db.collection("ScenariosList").updateOne({ "scriptid": scriptid }, { $set: { "customerId": bsoncustid, "appid": bsonappid, "scriptid": scriptid, "scenarioname": scenarioname, "type": type, "appurl": appurl, "filepath": folderName, "filename": req.file.filename } }, function (err, result) {
        if (err) {
          ////console.log(err);
          return null;
        }
        else {
          ////console.log("inserted");
          return res.status(200).json("success");
        }
      })

    }
  });
  //res.send("success")
});

router.post('/getmergedruns', function (req, res, next) {
var appid = req.query.appid;
let runid=[];
runid=req.body.runid;
var custid = req.decoded.customerID;
let bsoncustid = mongodb.ObjectID(custid);
let bsonappid = mongodb.ObjectID(appid)
console.log(runid);
db.collection("TestRuns").find({ "customerid": bsoncustid, "appid": bsonappid, runid: { $in:runid}}).toArray((err, result) => {
  if (err) {
    ////console.log("in")
    return res.status(500).json(err);
  } else {
    console.log(result)
    let finaljson=[]
    finaljson.push(result)
    return res.status(200).json(finaljson);
  }
})
}) 
router.post('/executescenario', function (req, res, next) {
  var custid = req.decoded.customerID;
  var appid = req.query.appid;
  var scriptid = req.body.scriptid;
  let bsoncustid = mongodb.ObjectID(custid);
  let bsonappid = mongodb.ObjectID(appid)
  let bsonscriptid = mongodb.ObjectID(scriptid)
  var scenarioname = req.body.scenarioname;
  var appname = req.body.applicationname
  var appurl = req.body.appurl
  if (req.body.type == "PageSource") {
    db.collection("ScenariosList").findOne({ "customerId": bsoncustid, "appid": bsonappid, "scenarioname": scenarioname, "scriptid": bsonscriptid }, function (err, result) {

      if (err) {
        ////console.log("in")
        return res.status(500).json(err);
      } else {
        //////console.log("hello");
        ////console.log(result);
        if (result != null) {
          //////console.log(result["filename"]);
          db.collection("RunIDCount").findOne({ "RunIDCountName": appid + '_' + custid }, (err, result2) => {
            if (err) {
              //////console.log("err" + result)
              res.send({ Status: 'error' })
            }
            else if (result2 == null) {
              db.collection("RunIDCount").insert({ "RunIDCountName": appid + '_' + custid, "RunIDCountValue": 1 }, function (err, result2) {
                if (err) {
                  ////console.log(err);
                }
                else {
                  const options = {
                    url: 'http://localhost:8080/ATAP_Manual/rest/servicedetails/upload',
                    json: true,
                    body: {
                      appid: appid, scriptid: scriptid, runid: 1,
                      customerid: custid, applicationName: appname, applicationurl: appurl, scenarioname: scenarioname, filename: result["filename"],
                      filepath: result["filepath"]
                    }
                  };
                  request.post(options, (err, resp, body) => {
                    if (err) {
                      return ////console.log(err);
                    }
                    else {
                      if (body == "success") {

                        return res.status(200).json("Scenario Executed");
                      }

                    }
                  });
                }
              })

            }
            else if (result2 !== null) {
              let runidvalue = (result2["RunIDCountValue"])
              db.collection("RunIDCount").updateOne({ "RunIDCountName": appid + '_' + custid }, {
                "$set": {
                  "RunIDCountValue": runidvalue + 1,
                }
              }, function (err) {
                if (err) {
                  ////console.log(err);
                }
                else {
                  const options = {
                    url: 'http://localhost:8080/ATAP_Manual/rest/servicedetails/upload',
                    json: true,
                    body: {
                      appid: appid, scriptid: scriptid, runid: runidvalue + 1,
                      customerid: custid, applicationName: appname, applicationurl: appurl, scenarioname: scenarioname, filename: result["filename"],
                      filepath: result["filepath"]
                    }
                  };
                  request.post(options, (err, resp, body) => {
                    if (err) {
                      return ////console.log(err);
                    }
                    else {
                      ////console.log(body)
                      if (body == "success") {
                        return res.status(200).json("Scenario Executed");
                      }

                    }
                  });
                }
              });
            }

          })
        }
      }
    })
  }
  else if (req.body.type == "url") {
    db.collection("ScenariosList").findOne({ "customerId": bsoncustid, "appid": bsonappid, "scriptid": bsonscriptid }, function (err, result) {

      if (err) {
        ////console.log("in")
        return res.status(500).json(err);
      } else {
        //////console.log("hello");
        // //console.log(result);
        if (result != null) {
          var orginalScript = {};
          //orginalScript = JSON.parse(JSON.stringify(result));
          // //console.log(orginalScript);
          orginalScript.applicationName = req.body.applicationname;
          orginalScript.status = "Stopped"
          orginalScript.customerid = result["customerId"];
          orginalScript.scenarioname = result["scenarioname"];

          orginalScript.appid = result["appid"];
          orginalScript.type = result["type"];
          orginalScript.scriptid = result["scriptid"];
          orginalScript.appid = result["appid"];
          orginalScript.transactions = result["transactions"];
          orginalScript.regions = "localhost";
          //////console.log(result["filename"]);
          db.collection("RunIDCount").findOne({ "RunIDCountName": appid + '_' + custid }, (err, result2) => {
            if (err) {
              //////console.log("err" + result)
              res.send({ Status: 'error' })
            }
            else if (result2 == null) {
              db.collection("RunIDCount").insert({ "RunIDCountName": appid + '_' + custid, "RunIDCountValue": 1 }, function (err, result2) {
                if (err) {
                  ////console.log(err);
                } else {
                  //console.log("here")
                  orginalScript.Runid = 1;
                  db.collection("scheduling_table").insert(orginalScript, function (err, result) {
                    if (err) {
                      //console.log("Error in inserting scheduling_table : " + err);
                      return res.status(500).json(err);
                    } else {
                      request.get("http://" + config.actionControllerHost + ":8080/ATActionController/rest/startscript/" + result.ops[0]._id, (error, response, body) => {
                        if (error) {
                          console.error(error);
                          return res.status(500).json(error);
                        }
                        //console.log(body);
                        if (body === "Script schedule started") {
                          return res.status(200).json(body);

                        } else {
                          return res.status(500).json(body);
                        }

                      })
                    }
                  })
                }
              })

            }
            else if (result2 !== null) {
              let runidvalue = (result2["RunIDCountValue"])
              db.collection("RunIDCount").updateOne({ "RunIDCountName": appid + '_' + custid }, {
                "$set": {
                  "RunIDCountValue": runidvalue + 1,
                }
              }, function (err) {
                if (err) {
                  ////console.log(err);
                }
                else {
                  ////console.log("baby" + result["_id"]);
                  // orginalScript = JSON.parse(JSON.stringify(result));
                  // orginalScript.applicationName = "Demo";
                  ////console.log(orginalScript)
                  // orginalScript.status = "Stopped";
                  // delete orginalScript["_id"];
                  // orginalScript.customerId = mongodb.ObjectID(result["customerId"]);
                  // orginalScript.appid = mongodb.ObjectID(result["appid"]);
                  // orginalScript.scriptid = mongodb.ObjectID(result["scriptid"]);
                  // orginalScript.scenarioname = result["scenarioname"];
                  orginalScript.Runid = runidvalue + 1;
                  // orginalScript.appid = result["appid"];
                  // orginalScript.type = result["type"];
                  // orginalScript.scriptid = result["scriptid"];
                  // orginalScript.appid=result["appid"];
                  // orginalScript.transactions = result["transactions"];
                  db.collection("scheduling_table").insert(orginalScript, function (err, result) {
                    if (err) {
                      //console.log("Error in inserting scheduling_table : " + err);
                      return res.status(500).json(err);
                    } else {
                      //console.log(" inside scheduling table");
                      //console.log(result.ops[0]._id)

                      request.get("http://" + config.actionControllerHost + ":8080/ATActionController/rest/startscript/" + result.ops[0]._id, (error, response, body) => {
                        if (error) {
                          console.error(error);
                          return res.status(500).json(error);
                        }
                        //console.log(body);
                        if (body === "Script schedule started") {
                          return res.status(200).json(body);

                        } else {
                          return res.status(500).json(body);
                        }
                      })
                    }
                  })
                }
              });
            }

          })
        }
      }
    })
  }
  else if (req.body.type == "Selenium") {
    //console.log("In Selenium")
    db.collection("ScenariosList").findOne({ "customerId": bsoncustid, "appid": bsonappid, "scriptid": bsonscriptid }, function (err, result) {

      if (err) {
        ////console.log("in")
        return res.status(500).json(err);
      } else {
        //////console.log("hello");
        // //console.log(result);
        if (result != null) {
          var orginalScript = {};
          //orginalScript = JSON.parse(JSON.stringify(result));
          // //console.log(orginalScript);
          orginalScript.applicationName = req.body.applicationname;
          orginalScript.status = "Stopped"
          orginalScript.customerid = result["customerId"];
          orginalScript.scenarioname = result["scenarioname"];

          orginalScript.appid = result["appid"];
          orginalScript.type = result["type"];
          orginalScript.scriptid = result["scriptid"];
          orginalScript.appid = result["appid"];
          orginalScript.filepath = result["filepath"];
          orginalScript.filename = result["filename"];
          orginalScript.regions = "localhost";
          //////console.log(result["filename"]);
          db.collection("RunIDCount").findOne({ "RunIDCountName": appid + '_' + custid }, (err, result2) => {
            if (err) {
              //////console.log("err" + result)
              res.send({ Status: 'error' })
            }
            else if (result2 == null) {
              db.collection("RunIDCount").insert({ "RunIDCountName": appid + '_' + custid, "RunIDCountValue": 1 }, function (err, result2) {
                if (err) {
                  ////console.log(err);
                } else {
                  //console.log("here")
                  orginalScript.Runid = 1;
                  db.collection("scheduling_table").insert(orginalScript, function (err, result) {
                    if (err) {
                      //console.log("Error in inserting scheduling_table : " + err);
                      return res.status(500).json(err);
                    } else {
                      //console.log(result["_id"])
                      request.get("http://" + config.actionControllerHost + ":8080/ATActionController/rest/startscript/" + result.ops[0]._id, (error, response, body) => {
                        if (error) {
                          console.error(error);
                          return res.status(500).json(error);
                        }
                        //console.log(body);
                        if (body === "Script schedule started") {
                          return res.status(200).json(body);

                        } else {
                          return res.status(500).json(body);
                        }

                      })
                    }
                  })
                }
              })

            }
            else if (result2 !== null) {
              let runidvalue = (result2["RunIDCountValue"])
              db.collection("RunIDCount").updateOne({ "RunIDCountName": appid + '_' + custid }, {
                "$set": {
                  "RunIDCountValue": runidvalue + 1,
                }
              }, function (err) {
                if (err) {
                  ////console.log(err);
                }
                else {
                  orginalScript.Runid = runidvalue + 1;
                  db.collection("scheduling_table").insert(orginalScript, function (err, result) {
                    if (err) {
                      //console.log("Error in inserting scheduling_table : " + err);
                      return res.status(500).json(err);
                    } else {
                      //console.log(" inside scheduling table");
                      //console.log(result.ops[0]._id)

                      request.get("http://" + config.actionControllerHost + ":8080/ATActionController/rest/startscript/" + result.ops[0]._id, (error, response, body) => {
                        if (error) {
                          console.error(error);
                          return res.status(500).json(error);
                        }
                        //console.log(body);
                        if (body === "Script schedule started") {
                          return res.status(200).json(body);

                        } else {
                          return res.status(500).json(body);
                        }
                      })
                    }
                  })
                }
              });
            }

          })
        }
      }
    })
  }
})



router.get('/getscenariolist', function (req, res, next) {
  let bsoncustid = mongodb.ObjectID(req.decoded.customerID);
  let bsonappid = mongodb.ObjectID(req.query.appid);
  db.collection("ScenariosList").find({ "customerId": bsoncustid, "appid": bsonappid }).toArray((err, result) => {
    if (err) {
      // ////console.log("Error in Customers detail module : " + err);
      return res.status(500).json(err);
    }
    else {
      // ////console.log("Result  " + result);
      ////console.log(result)
      return res.status(200).json(result);

    }
  });
})

router.get('/getMessageFromRegionQueue', function (req, res) {
  res.header("Strict-Transport-Security", "max-age=604800"); // 1 week in seconds   
  res.header('Cache-Control', 'private, no-cache, no-store, must-revalidate');
  var regionQueueName = req.query.regionQueueName;
  if (typeof regionQueueName == "undefined" || regionQueueName == null) {
    return res.status(500).json({
      status: "ERROR",
      message: "Region Queue name not passed as parameter"
    });
  }

  /*res.setTimeout(5000, function(){
      ////console.log('Request has timed out, guess no messages in the queue');
      return  res.status(200).json({
          status: "No messages found, after waiting & timedout",
        });
  });*/

  try {
    request.get("http://" + config.actionControllerHost + ":8080/ATActionController/rest/getMessageFromQueue/" + regionQueueName, (error, response, body) => {
      if (error) {
        console.error(error);
        return res.status(500).json({
          status: error
        });
      }
      ////console.log(body);
      return res.status(200).json(body);
    });
  } catch (e) {
    //console.log("Error in getMessageFromRegionQueue " + e);
    return res.status(500).json({
      status: "ERROR",
      message: e
    });
  }


});

router.post('/savescenariodesign', function (req, res, next) {
  console.log(JSON.stringify(req.body));
  var custid = req.decoded.customerID;
  var scriptid = new mongodb.ObjectID();
  ////console.log(scriptid)
  var appid = req.query.appid;
  //console.log(custid, scriptid, appid, req.body.postvalue, req.body.tabledata)

  let bsoncustid = mongodb.ObjectID(custid);
  let bsonappid = mongodb.ObjectID(appid)
  db.collection("ScenariosList").insertOne({ "timestamp": currentdate(), "customerId": bsoncustid, "appid": bsonappid, "scriptid": scriptid, "scenarioname": req.body.postvalue.formscriptname, "type": req.body.postvalue.type, "platform": req.body.postvalue.formplatform, transactions: req.body.tabledata }, function (err, result) {
    if (err) {
      ////console.log(err);
      return null;
    }
    else {
      ////console.log("inserted");
      return res.status(200).json("success");
    }
  })

})

router.post('/updatescenariodesign', function (req, res, next) {
  var custid = req.decoded.customerID;
  console.log(req.body)
  console.log(req.body.postvalue.scriptid);
  var scriptid = mongodb.ObjectID(req.body.postvalue.scriptid);
  console.log(scriptid)
  var appid = req.query.appid;
  //console.log(custid, scriptid, appid, req.body.postvalue, req.body.tabledata)

  let bsoncustid = mongodb.ObjectID(custid);
  let bsonappid = mongodb.ObjectID(appid)
  db.collection("ScenariosList").updateOne({ "scriptid": scriptid }, { $set: { "customerId": bsoncustid, "scriptid": scriptid, "appid": bsonappid, "scenarioname": req.body.postvalue.formscriptname, "type": req.body.postvalue.type, "platform": req.body.postvalue.formplatform, transactions: req.body.tabledata } }, function (err, result) {
    if (err) {
      console.log(err);
      return null;
    }
    else {
      //console.log(result);
      return res.status(200).json("success");
    }
  })

})

router.get('/getTestDetails', function (req, res) {
  console.log("amappid"+req.query.appid +" " +req.decoded.customerID)
  res.header("Strict-Transport-Security", "max-age=604800"); // 1 week in seconds   
  res.header('Cache-Control', 'private, no-cache, no-store, must-revalidate');
  //console.log("-----getTestDetails------");
  var appID = req.query.appid;
  if (appID === null || appID === undefined || appID === "") {
    return res.status(404).json("Application ID is not specified or not valid");
  }
  var bsonAppID = mongodb.ObjectID(appID)
  //"appid": bsonAppID

  var customerID = req.decoded.customerID;
  if (customerID === null || customerID === undefined || customerID === "") {
    return res.status(404).json("Token is not valid");
  }
  ////console.log(customerID)
  var bsonCustomerID = mongodb.ObjectID(customerID)
  db.collection("TestRuns").find({ "customerid": bsonCustomerID, "appid": bsonAppID }).project({}).toArray((err, result) => {
    ////console.log(result)
    if (err) {
      //console.log("Error in getTestRuns : " + err);
      return res.status(500).json(err);
    } else {
  console.log("Result  " + result);
 console.log(result)
      return res.status(200).json(result);
    }
  });
});//end of //Getting Test Details 
router.get('/getTestDetailsByID', function (req, res, next) {
  res.header("Strict-Transport-Security", "max-age=604800"); // 1 week in seconds   
  res.header('Cache-Control', 'private, no-cache, no-store, must-revalidate');
  //console.log("-----getTestDetailsByID------");
  var testrunnid = req.query.objectid;
  //console.log(testrunnid)
  if (testrunnid === null || testrunnid === undefined || testrunnid === "") {
    return res.status(404).json("Test Details ID is not specified or not valid");
  }
  var bsonID = mongodb.ObjectID(testrunnid);
  db.collection('TestRuns').findOne({ "_id": bsonID }, function (err, records) {
    if (err) {
      return res.status(500).json(err);
    } else {
      return res.status(200).json(records);
    }
  });
});
router.get('/getmlrecords', function (req, res, next) {
  console.log(req.query.objectid)
  var testrunnid = req.query.objectid;

  //console.log(testrunnid)
  if (testrunnid === null || testrunnid === undefined || testrunnid === "") {
    return res.status(404).json("Test Details ID is not specified or not valid");
  }
  var bsonID = mongodb.ObjectID(testrunnid);
  res.header("Strict-Transport-Security", "max-age=604800"); // 1 week in seconds   
  res.header('Cache-Control', 'private, no-cache, no-store, must-revalidate');
  db.collection('TestRuns').findOne({ "_id": bsonID }, function (err, records) {
    if (err) {
      return res.status(500).json(err);
    } else {
      console.log(records)
      db.collection('MLRuns').findOne({
        "customerid": mongodb.ObjectID(records["customerid"])
        , "appid": mongodb.ObjectID(records["appid"]), "scriptid": mongodb.ObjectID(records["scriptid"]),
        "runid": records["runid"], "scenarioname": records["scenarioname"]
      }, function (err, records) {
        if (err) {
          return res.status(500).json(err);
        } else {
          console.log(records)
          return res.status(200).json(records);
        }
      });
    }
  });
});

router.post('/startmlanalysis', function (req, res, next) {
  res.header("Strict-Transport-Security", "max-age=604800"); // 1 week in seconds   
  res.header('Cache-Control', 'private, no-cache, no-store, must-revalidate');
  //console.log("-----getTestDetailsByID------");
  var testrunnid = req.query.objectid;
  console.log(req.body.row)
  console.log(req.query.appid)
  let appid = req.query.appid;
  let customerid = req.decoded.customerID
  let scriptid = req.body.row.scriptid;
  let runid = req.body.row.runid;
  let scenarioname = req.body.row.scenarioname;
  //console.log(testrunnid)
  var obj = { row: req.body.row };
  let exec = require('child_process').exec;
  let childprocess = exec('java -jar C:\\Accessibility\\PythonNP\\MLAnalysis.jar ' + appid + " " + customerid + " " + scriptid + " " + scenarioname + " " + runid, function (err, stdout, stderr) {
    console.log("inner")
    if (err) {
      console.log(stderr)
      console.log(err)
    }
    obj = stdout
    console.log(obj)
  })
  var bsonID = mongodb.ObjectID(testrunnid);

  return res.status(200).json("success");

});



///STANDALONE
router.post('/executescenariostandalone', function (req, res, next) {
  var custid = req.body.customerid;
  var appid = req.body.appid;
  console.log(req.body.scenarioname, appid, custid)
  //var scriptid = req.body.scriptid;
  // let bsoncustid = mongodb.ObjectID(custid);
  // let bsonappid = mongodb.ObjectID(appid)
  // let bsonscriptid = mongodb.ObjectID()
  // var scenarioname = req.body.scenarioname;
  // var appname = req.body.applicationname
  // var appurl = req.body.appurl
  db.collection("RunIDCount").findOne({ "RunIDCountName": appid + '_' + custid }, (err, result2) => {
    if (err) {
      //////console.log("err" + result)
      res.send({ Status: 'error' })
    }
    else if (result2 == null) {
      db.collection("RunIDCount").insert({ "RunIDCountName": appid + '_' + custid, "RunIDCountValue": 1 }, function (err, result2) {
        if (err) {
          return res.status(500).json(body);
        } else {
          let runid = 1
          return res.status(200).json(runid);
        }

      })

    }
    else if (result2 !== null) {
      let runidvalue = (result2["RunIDCountValue"])
      db.collection("RunIDCount").updateOne({ "RunIDCountName": appid + '_' + custid }, {
        "$set": {
          "RunIDCountValue": runidvalue + 1,
        }
      }, function (err) {
        if (err) {
          return res.status(500).json(err);
        }
        else {
          return res.status(200).json(runidvalue + 1);
        }

      })
    }
  })
})

router.get('/detailedAnalysisForXlsx', function (req, res, next) {
  res.header("Strict-Transport-Security", "max-age=604800"); // 1 week in seconds   
  res.header('Cache-Control', 'private, no-cache, no-store, must-revalidate');
  var testrunnid = req.query.runId;
  console.log(" detailedAnalysisForXlsx ");
  if (testrunnid === null || testrunnid === undefined || testrunnid === "" || validationRoute(testrunnid)) {
    return res.status(404).json("Test Details ID is not specified or not valid");
  }
  var bsonID = mongodb.ObjectID(testrunnid);
  db.collection('TestRuns').findOne({ "_id": bsonID }, function (err, records) {
    if (err) {
      return res.status(500).json(err);
    } else {
      //console.log(records);
      var analysisdata = records.detail1;
      var resultDA = {};
      var issueCount = [];
      for (let analysis of analysisdata) {
        var transName;
        var impactsData = [];
        //console.log("  analysis.length " + analysis.length);
        var highCount = 0;
        var mediumCount = 0;
        var lowCount = 0;
        for (var i = 0; i < analysis.length; i++) {
          if (analysis[i].hasOwnProperty("pagename")) {
            transName = analysis[i].pagename.pagenames;
            //console.log(" transName : " + transName);
          } else {
            var dynamicDetail = Object.keys(analysis[i]);
            var jsonObject = analysis[i][dynamicDetail[0]];
            //impactsData.push(jsonObject);
            let dataTemp = [];
            var DAKeys = Object.keys(jsonObject);
            for (let key of DAKeys) {

              switch (key) {
                case 'Impact': {
                  dataTemp[0] = jsonObject[key];
                  switch (jsonObject[key]) {
                    case 'High': {
                      highCount++;
                      break;
                    }
                    case 'Medium': {
                      mediumCount++;
                      break;
                    }
                    case 'Low': {
                      lowCount++;
                      break;
                    }
                  }
                  break;
                }
                case 'Violation': {
                  dataTemp[1] = jsonObject[key];
                  break;
                }
                case 'GuidelineNo': {
                  dataTemp[2] = jsonObject[key];
                  break;
                }
                case 'Standard': {
                  dataTemp[3] = jsonObject[key];
                  break;
                }
                case 'IssueDescription': {
                  dataTemp[4] = jsonObject[key];
                  break;
                }
                case 'AffectedUsers': {
                  dataTemp[5] = jsonObject[key];
                  break;
                }
                case 'Sources': {
                  var tempData = "";
                  for (tempSource of jsonObject[key]) {
                    tempData = tempData + tempSource;
                  }
                  dataTemp[6] = tempData;
                  break;
                }
                case 'Suggestion': {
                  dataTemp[7] = jsonObject[key];
                  break;
                }
              }
            }

            impactsData.push(dataTemp);
          }
          if (i == analysis.length - 1) {
            var total = highCount + mediumCount + lowCount;
            //var issues = [];
            //issues.push(transName, highCount, mediumCount, lowCount, total)
            issueCount.push([transName, highCount, mediumCount, lowCount, total]);
          }
        }
        resultDA[transName] = impactsData
      }
      var resultData = {
        "detailedAnalysisData": resultDA,
        "issuesCount": issueCount
      }
      return res.status(200).json(resultData);
    }
  });
})


module.exports = router;
