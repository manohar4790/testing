var express = require('express');
var router = express.Router();
var config = require('../../configuration.json');
var multer = require('multer');
var fs = require('fs');
var path = require('path');

var mongodb = require('mongodb');
//Using mongoclient, not using mongoose
let ObjectID = mongodb.ObjectID;
var MongoClient = mongodb.MongoClient;
var dbURL = config.mongoDBURL;
let db;
MongoClient.connect(dbURL, function (err, mydb) {
    if (err) {
        console.log('userAPI.js : ERROR : DB connection failed using mongodb');
        return err;
    } else {
        db = mydb.db();
        console.log('userAPI.js : DB connection established using mongodb!');
    }
});

var storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, config.tempftpPath)
    },
    filename: function (req, file, cb) {
        var fname = file.originalname;
        var regexAll = /^([^\\]*)\.(\w+)$/;
        var temp1, temp2;
        temp1 = fname.split(".");
        var total = fname.split(fname.lastIndexOf("."));
        var filename = total[0];
        var extension = total[1];
        cb(null, temp1[0] + "_" + Date.now() + "." + temp1[1]);
    }
});

router.get('/getScriptPageDetailsForAT', function (req, res) {
    res.header("Strict-Transport-Security", "max-age=604800"); // 1 week in seconds   
    res.header('Cache-Control', 'private, no-cache, no-store, must-revalidate');
    console.log("-----getScriptPageDetails------");

    var customerID = req.decoded.customerID;
    var applicationId = req.query.applicationID;
    if (customerID === null || customerID === undefined || customerID === "") {
        return res.status(404).json("Token is not valid");
    }
    console.log(" customerID : " + customerID);
    var bsonCustomerID = mongodb.ObjectID(customerID);
    var bsonAppId = mongodb.ObjectID(applicationId);
    console.log(bsonAppId);
    let customerName="";
    db.collection("Customers").find({ "_id": bsonCustomerID }).toArray((err, result) => {
        if (err) {
            return res.status(500).json("Internal Server error");
        } else {
            let apps;
            let scripts=[];
             customerName=result[0].customerName;
            for (let tempRes of result[0].application) {
                if (tempRes.appid == applicationId) {
                    //console.log(tempRes);
                    scripts=tempRes.scripts;
                    scripts.reverse();
                    tempRes.scripts=scripts;
                    tempRes.customerName=customerName;
                    return res.status(200).json(tempRes);
                }
            }

        }
    })
})
router.delete('/deleteScriptForAT', function (req, res) {
    var id = req.decoded.customerID;
    var applicationId = req.query.applicationId;
    var scriptId = req.query.scriptId;
    if (typeof id == "undefined" || id === "" || id === null || typeof applicationId == "undefined" || applicationId === "" || applicationId === null || typeof scriptId == "undefined" || scriptId === "" || scriptId === null) {
        return res.status(500).json("the values sent may be undefined null or empty");
    }
    db.collection("Customers").update({ "_id": mongodb.ObjectID(id), "application.appid": mongodb.ObjectID(applicationId) }, { "$pull": { "application.$.scripts": { "scriptid": mongodb.ObjectID(scriptId) } } }, function (err, result) {
        if (err) {
            console.log("Error in deleteScript : " + err);
            return res.status(500).json("Internal Server Error: Error in deleting the script");
        } else {
            console.log(result);
            console.log("No Error in  deleteScript : ");
            return res.status(200).json("deleted script Successfully ");
        }
    });
});

router.post('/addScriptDesignDataForAT', function (req, res) {
    console.log(" INSIDE      /addNewScriptingData");
    console.log(JSON.stringify(req.body));
    console.log(JSON.stringify(req.body.scriptname));
    var applicationId = req.query.applicationId;
    var id = req.decoded.customerID;
    if (typeof id == "undefined" || id === "" || id === null || typeof applicationId == "undefined" || applicationId === "" || applicationId === null) {
        console.log("applicationId customer Id is null")
        return res.status(500).json("the values sent may be undefined null or empty");
    }
    var transaction = req.body.transaction;
    if (typeof transaction == undefined) {
        console.log("transaction is undefined")
        return res.status(500).json("the values sent may be undefined null or empty");
    }
    for (let i = 0; i < transaction.length; i++) {
        console.log(JSON.stringify(transaction[i]));
    }
    var saveObj = {
        "scriptid": new ObjectID(),
        "scriptname": req.body.scriptname,
        "regions": req.body.regions,
        "no_of_iteration": parseInt(req.body.iteration),
        "CacheSetting": req.body.CacheSetting,
        "Platform": req.body.platform,
        "status": "Stopped",
        "scripttype": req.body.scripttype,
        "transaction": transaction
    }
    var isvalidObj = saveObjValidation(saveObj);
    console.log("IsvalidObject : " + isvalidObj);
    if (isvalidObj === true) {
        console.log(JSON.stringify(saveObj));
        db.collection("Customers").updateOne({ "_id": mongodb.ObjectID(id), "application.appid": mongodb.ObjectID(applicationId) }, { "$push": { "application.$.scripts": saveObj } }, function (err, result) {
            if (err) {
                return res.status(500).json("Internal Server Error: Error in adding script design data");
            } else {
                return res.status(200).json("Scripting data added Successfully ");
            }
        });

    } else {
        return res.status(500).json("the values sent may be undefined null or empty");
    }

});


router.post('/updateScriptDesignDataForAT', function (req, res) {
    console.log("/updateScriptDesignData");
    var transaction = req.body.transaction;
    console.log(JSON.stringify(transaction));
    var saveObj = {
        "scriptid": new ObjectID(req.query.scriptId),
        "scriptname": req.body.scriptname,
        "regions": req.body.regions,
        "no_of_iteration": parseInt(req.body.iteration),
        "CacheSetting": req.body.CacheSetting,
        "Platform": req.body.platform,
        "status": "Stopped",
        "scripttype": req.body.scripttype,
        "transaction": transaction
    }
    let isvalidObj = saveObjValidation(saveObj);
    console.log("IsvalidObject : " + isvalidObj);
    if (isvalidObj) {
        console.log(JSON.stringify(saveObj));
        db.collection("Customers").updateOne({ "_id": mongodb.ObjectID(req.decoded.customerID), "application.appid": mongodb.ObjectID(req.query.applicationId) }, { $set: { "application.$[a].scripts.$[s]": saveObj } }, { arrayFilters: [{ "a.appid": mongodb.ObjectId(req.query.applicationId) }, { "s.scriptid": mongodb.ObjectId(req.query.scriptId) }] },
            function (err, result) {
                if (err) {
                    return res.status(500).json("Internal Server Error: Error in updating script design");
                } else {
                    return res.status(200).json("Design script data updated successfully ");
                }
            });
    } else {
        return res.status(500).json("the values sent may be undefined null or empty");
    }
});
router.post('/addScriptsForAT', function (req, res) {
    var upload = multer({
        storage: storage,
        fileFilter: function (req, file, callback) {
            // path.endsWith(".jar")
            console.log("path : " + path + "\n" + " file.originalname : " + file.originalname);
            // var ext = path.extname(file.originalname);
            // if (ext !== '.jar') {
            if (!(file.originalname.endsWith(".jar")) && !(file.originalname.endsWith(".zip"))) {
                return callback(new Error("Only JAR/ZIP files allowed"))
            }
            callback(null, true)
        }
    }).single('photo');
    var path = '';
    upload(req, res, function (err) {
        if (err) {
            // An error occurred when uploading
            console.log(err);
            return res.status(422).send("" + err);
        } else {
            var id = req.decoded.customerID;
            var applicationId = req.query.applicationId;
            var customerName = req.body.customerName;
            var applicationName = req.body.applicationName;
            console.log(" customerName : "+customerName+" applicationName : "+applicationName);
            //Check if customer folder exists - if not create it
            var folderName = config.ftpPath + customerName;
            if (!fs.existsSync(folderName)) {
                fs.mkdirSync(folderName);
                //console.log('Folder ' + folderName + ' was created!');
            } else {
                //console.log('fs check  1 : ' + folderName + 'folder already exists');
            }

            folderName = folderName + "/" + applicationName;
            if (!fs.existsSync(folderName)) {
                fs.mkdirSync(folderName);
                //console.log('Folder ' + folderName + ' was created!');
            } else {
                //console.log('fs check  2 : ' + folderName + 'folder already exists');
            }
            //Check if application folder exists - if not create it
            //Move the file from C:\synmon\ftp\Temp to the appropriate customer \application name folder
            fs.copyFileSync(config.tempftpPath + req.file.filename, folderName + '/' + req.file.filename, function (err) {
                if (err) {
                    console.error(err);
                } else {
                    //console.log('File moved');
                }
            });
            console.log("uploaded file");
            if (typeof id == "undefined" || id === "" || id === null || typeof applicationId == "undefined" || applicationId === "" || applicationId === null || typeof req.file == "undefined") {
                return res.status(500).json("the values sent may be undefined null or empty");
            }
            var ftpPath = "/" + customerName + "/" + applicationName + "/" + req.file.filename;
            let transaction = {};

            if (req.body.transaction != undefined) {
                transaction = JSON.parse(req.body.transaction);
            }

            var saveObj = {
                "scriptid": new ObjectID(),
                "scriptname": req.file.originalname,
                "scriptversion": req.file.filename,
                "file_location": ftpPath,
                "regions": req.body.regions,
                "scripttype": req.body.scripttype,
                //"fulllocationname": req.body.fulllocationname,
                "no_of_iteration": 1,
                "Platform":"Desktop",
                "CacheSetting":"WithCache",
                "status": "Stopped",
                "transaction": transaction //req.body.transaction
            }
            db.collection("Customers").update({ "_id": mongodb.ObjectID(id), "application.appid": mongodb.ObjectID(applicationId) }, { "$push": { "application.$.scripts": saveObj } }, function (err, result) {
                if (err) {
                    console.log("Error in newScripts : " + err);
                    return res.status(500).json("Internal Server Error: Error in adding scripts");
                } else {
                    console.log("No Error in  applicationNames : ");
                    return res.status(200).json("script added Successfully ");
                }
            })
        }
    });
});

router.post('/updateExistingScriptForAT', function (req, res) {
    console.log("Inside updateExistingScript");
    var upload = multer({
        storage: storage,
    }).single('photo');
    upload(req, res, function (err) {
        if (err) {
            // An error occurred when uploading
            console.log(err);
            /* return res.status(422).send("Error : "+err); */
            return res.status(422).send("" + err);
        } else {
            var regions = req.body.regions;
            var iteration = 1;
            var id = req.decoded.customerID;
            var applicationId = req.query.applicationId;
            var scriptId = req.query.scriptId;
            let transaction = {};
            if (req.body.transaction != undefined) {
                transaction = JSON.parse(req.body.transaction);
            }
            let scripttype = req.body.scripttype;
            if (typeof id == "undefined" || id === "" || id === null || typeof applicationId == "undefined" || applicationId === "" || applicationId === null || typeof req.file == "undefined") {
                return res.status(500).json("the values sent may be undefined null or empty")

            }
            // if (req.file !== undefined) {
            console.log("Inside if block");
            var scriptname = req.file.originalname;
            var file_location = req.file.path;
            var customerName = req.body.customerName;
            var applicationName = req.body.applicationName;
            //Check if customer folder exists - if not create it
            var folderName = config.ftpPath + customerName + "/" + applicationName;

            fs.copyFileSync(config.tempftpPath + req.file.filename, folderName + '/' + req.file.filename, function (err) {
                if (err) {
                    console.error(err);
                } else {
                    console.log("updated file in location : " + folderName + '/' + req.file.filename)
                    //console.log('File moved');
                }
                //res.json({});
            });

            //console.log("DEBUGGIN : " + customerName + ", " + applicationName + ", filename : " + req.file.filename);
            file_location = "/" + customerName + "/" + applicationName + "/" + req.file.filename;
            db.collection("Customers").update({ "_id": mongodb.ObjectID(id), "application.appid": mongodb.ObjectID(applicationId) }, {
                $set: {
                    "application.$[a].scripts.$[s].scriptname": scriptname,
                    "application.$[a].scripts.$[s].file_location": file_location,
                    "application.$[a].scripts.$[s].regions": regions,
                    "application.$[a].scripts.$[s].scripttype": scripttype,
                    "application.$[a].scripts.$[s].no_of_iteration": iteration,
                    "application.$[a].scripts.$[s].transaction": transaction
                }
            }, { arrayFilters: [{ "a.appid": mongodb.ObjectId(applicationId) }, { "s.scriptid": mongodb.ObjectId(scriptId) }] }, function (err, result) {
                if (err) {
                    console.log("Error in updateExistingScript : " + err);
                    return res.status(500).json("Internal Server Error: Error in updating the script");
                } else {
                    console.log("No Error in  updateExistingScript : ");
                    return res.status(200).json("updated script Successfully");
                }
            })
        }

    });
});

router.post('/updateExistingScriptWithoutFileForAT', function (req, res) {
    var regions = req.body.regions;
    var iteration = 1;
    var id = req.decoded.customerID;
    var applicationId = req.query.applicationId;
    var scriptId = req.query.scriptId;
    let transaction = {};
    if (req.body.transaction != undefined) {
        transaction = req.body.transaction;
    }
    let scripttype = req.body.scripttype;
    if (typeof regions == "undefined" || regions === "" || regions === null || typeof id == "undefined" || id === "" || id === null || typeof applicationId == "undefined" || applicationId === "" || applicationId === null || typeof scriptId == "undefined" || scriptId === "" || scriptId === null) {
        return res.status(500).json("the values sent may be undefined null or empty");
    }
    db.collection("Customers").update({ "_id": mongodb.ObjectID(id), "application.appid": mongodb.ObjectID(applicationId) }, {
        $set: {
            "application.$[a].scripts.$[s].regions": regions,
            "application.$[a].scripts.$[s].scripttype": scripttype,
            "application.$[a].scripts.$[s].no_of_iteration": iteration,
            "application.$[a].scripts.$[s].transaction": transaction
        }
    }, { arrayFilters: [{ "a.appid": mongodb.ObjectId(applicationId) }, { "s.scriptid": mongodb.ObjectId(scriptId) }] }, function (err, result) {
        if (err) {
            console.log("Error in updateExistingScriptWithoutFile : " + err);
            return res.status(500).json("Internal Server Error: Error in updating the script");
        } else {
            console.log("No Error in  updateExistingScriptWithoutFile : ");
            return res.status(200).json("updated script Successfully without file ");
        }
    });
});
router.post('/addDuplicateScripts', function (req, res) {
    console.log(" INSIDE      /addDuplicateScripts");
    console.log(JSON.stringify(req.body));
    var applicationId = req.query.applicationId;
    var id = req.decoded.customerID;
    if (typeof id == "undefined" || id === "" || id === null || typeof applicationId == "undefined" || applicationId === "" || applicationId === null) {
        console.log("applicationId customer Id is null")
        return res.status(500).json("the values sent may be undefined null or empty");
    }
    var script = req.body.script;
    script.scriptid=new ObjectID();
    //script.no_of_iteration= parseInt(req.body.iteration);

        db.collection("Customers").updateOne({ "_id": mongodb.ObjectID(id), "application.appid": mongodb.ObjectID(applicationId) }, { "$push": { "application.$.scripts": script } }, function (err, result) {
            if (err) {
                return res.status(500).json("Internal Server Error: Error in adding script design data");
            } else {
                return res.status(200).json("Scripting data added Successfully ");
            }
        });
});
router.get('/getRegions', function (req, res) {

    res.header("Strict-Transport-Security", "max-age=604800"); // 1 week in seconds   
    res.header('Cache-Control', 'private, no-cache, no-store, must-revalidate');
    console.log("-----getRegions------");

    var customerID = req.decoded.customerID;
    if (customerID === null || customerID === undefined || customerID === "") {
        return res.status(404).json("Token is not valid");
    }
    console.log(" customerID : " + customerID);
    var bsonCustomerID = mongodb.ObjectID(customerID);
    db.collection("regions").find({}).toArray((err, result) => {
        if (err) {
            return res.status(500).json("Internal Server error");
        }
        else {
            return res.status(200).json(result);
        }
    }

    )

})
function saveObjValidation(saveObj) {
    if (saveObj.scriptname == null || typeof saveObj.scriptname == "undefined" || saveObj.scriptname === "") {
        return false;
    }
    if (saveObj.regions == null || typeof saveObj.regions == "undefined" || saveObj.regions === "") {
        return false;
    }
    if (saveObj.no_of_iteration == null || typeof saveObj.no_of_iteration == "undefined" || saveObj.no_of_iteration === "") {
        return false;
    }
    if (saveObj.CacheSetting == null || typeof saveObj.CacheSetting == "undefined" || saveObj.CacheSetting === "") {
        return false;
    }
    if (saveObj.Platform == null || typeof saveObj.Platform == "undefined" || saveObj.Platform === "") {
        return false;
    }
    if (saveObj.status == null || typeof saveObj.status == "undefined" || saveObj.status === "") {
        return false;
    }
    if (saveObj.scripttype == null || typeof saveObj.scripttype == "undefined" || saveObj.scripttype === "") {
        return false;
    }
    saveObj.transaction.forEach(function (value) {
        if (typeof value.transactionName == "undefined" || value.transactionName == null || value.transactionName === "" || typeof value.sla == undefined || value.sla == null || value.sla === "" || value.methods == "undefined" || value.methods == null || value.methods === "" || typeof value.navigate == undefined || value.navigate == null || value.navigate === "") {
            return false;
        }
    });

    return true;
}
module.exports = router;