var Influx = require('influx');
var config = require('../../configuration.json');
var express = require('express');
var router = express.Router();
var multer = require('multer');
var fs = require('fs');
var mongodb = require('mongodb');
//Using mongoclient, not using mongoose
let ObjectID = mongodb.ObjectID;
var MongoClient = mongodb.MongoClient;
var dbURL = config.mongoDBURL;
let db;
var Request = require("request");
var AdmZip = require('adm-zip');
var zipperFile = "zippedFile" + '-' + Date.now();
var resultJson = {};
MongoClient.connect(dbURL, function (err, mydb) {
    if (err) {
        console.log('userAPI.js : ERROR : DB connection failed using mongodb');
        return err;
    } else {
        db = mydb.db();
        console.log('userAPI.js : DB connection established using mongodb!');
    }
});

var storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, config.tempftpPath)
    },
    filename: function (req, file, cb) {
        cb(null, zipperFile);

    }
});
router.get('/getNewSample', function (req, res, next) {
    var customerID = "5c5d651c19fb951b98b71512"; var runId = "5ecd15e249a05728d0842593";
    console.log("--------/getNewSample--------");
    var zipperFile = "zippedFile-1590499577981"; // comment for post

    // customerID = resultJson.customerID;
    // console.log("customerID" + customerID);
    // runId = resultJson.runId;
    // console.log("runId" + runId); 

    var folderName = config.assetsPath + customerID;
    if (!fs.existsSync(folderName)) {
        fs.mkdirSync(folderName);
        console.log('Folder ' + folderName + ' was created!');
    } else {
        console.log('fs check  1 : ' + folderName + 'folder already exists');
    }
    var folderName = folderName + '/' + runId;
    if (!fs.existsSync(folderName)) {
        fs.mkdirSync(folderName);
        console.log('Folder ' + folderName + ' was created!');
    } else {
        console.log('fs check  1 : ' + folderName + 'folder already exists');
    }
    fs.copyFileSync(config.tempftpPath + zipperFile, folderName + '/' + zipperFile, function (err) {
        if (err) {
            console.error(err);
        } else {
            console.log("file moved");
        }
    });
    var zipFilePath = folderName + '/' + zipperFile;
    console.log("before unzipping ");
    if (fs.existsSync(folderName + '/' + zipperFile)) {
        console.log(" file found");
    } else {
        console.log("file not found");
    }
    var zip = new AdmZip(zipFilePath);
    zip.extractAllTo(folderName + "/", true);
    fs.unlinkSync(zipFilePath);
    let sample = fs.readFileSync(folderName + '/' + 'rundetails.json');
    resultJson = JSON.parse(sample);
    console.log(resultJson.regions);
    return res.status(200).json("Data posted successfully ");
});

//Insert json into the Mongodb
router.post('/insertNewSampleForAT', function (req, res, next) {

    var upload = multer({
        storage: storage,
        fileFilter: function (req, file, callback) {
            // path.endsWith(".jar")
            console.log(" file.originalname : " + file.originalname);
            // var ext = path.extname(file.originalname);
            // if (ext !== '.jar') {
            if (!(file.originalname.endsWith(".zip"))) {
                return callback(new Error("Only ZIP files allowed"))
            }
            callback(null, true)
        }
    }).single('zippedFile');
    upload(req, res, function (err) {
        if (err) {
            // An error occurred when uploading
            console.log(err);
            return res.status(422).send("" + err);
        } else {
            customerID = req.body.customerID;
            console.log("customerID" + customerID);
            runId = req.body.runId;
            console.log("runId" + runId);

            var folderName = config.assetsPath + customerID;
            if (!fs.existsSync(folderName)) {
                fs.mkdirSync(folderName);
                console.log('Folder ' + folderName + ' was created!');
            } else {
                console.log('fs check  1 : ' + folderName + 'folder already exists');
            }
            var folderName = folderName + '/' + runId;
            if (!fs.existsSync(folderName)) {
                fs.mkdirSync(folderName);
                console.log('Folder ' + folderName + ' was created!');
            } else {
                console.log('fs check  1 : ' + folderName + 'folder already exists');
            }
            fs.copyFileSync(config.tempftpPath + zipperFile, folderName + '/' + zipperFile, function (err) {
                if (err) {
                    console.error(err);
                } else {
                    console.log("file moved");
                }
            });
            var zipFilePath = folderName + '/' + zipperFile;
            console.log("before unzipping ");
            if (fs.existsSync(folderName + '/' + zipperFile)) {
                console.log(" file found");
            } else {
                console.log("file not found");
            }
            var zip = new AdmZip(zipFilePath);
            zip.extractAllTo(folderName + "/", true);
            fs.unlinkSync(zipFilePath);
            let sample = fs.readFileSync(folderName + '/' + 'rundetails.json');
            resultJson = JSON.parse(sample);
            console.log(resultJson.regions);
            var applicationId = resultJson.applicationId;
            var scriptId = resultJson.scriptId;
            var status = resultJson.status;
            var start_time = resultJson.start_time;
            var end_time = resultJson.end_time;
            var slaMet = resultJson.slastatus;
            var transaction = [];
            console.log(resultJson.Transactions.length);
            for (let trans of resultJson.Transactions) {
                var transID = new ObjectID();
                trans.transactionID = transID;
                let tempJson = {
                    "transactionId": transID,
                    "transactionName": trans.transactionName,
                    "firstUser": trans.firstUser,
                    "Avg_RT": trans.Avg_RT,
                    "_95_percentile": trans._95_percentile,
                    "sla": trans.sla,
                    "URL": trans.URL,
                    "Iterations": []
                }
                transaction.push(tempJson)
            }
            mongodb.ObjectID();
            resultJson.customerId = mongodb.ObjectID(customerID);
            resultJson.applicationId = mongodb.ObjectID(applicationId);
            resultJson.scriptId = mongodb.ObjectID(scriptId);
            resultJson.Runid = mongodb.ObjectID(runId);
            db.collection("scheduling_table").removeOne({ "scriptid": mongodb.ObjectID(scriptId), "Runid": mongodb.ObjectID(runId) }, function (err, result) {
                if (err) {
                    return res.status(500).json("error deleting script");
                } else {
                    console.log("Deleted scheduling script");
                    // db.collection("Customers").update({ "_id": mongodb.ObjectID(customerID), "application.appid": mongodb.ObjectID(applicationId) }, {
                    //     $set: {
                    //         "application.$[a].scripts.$[s].status": 'Stopped'
                    //     }
                    // }, { arrayFilters: [{ "a.appid": mongodb.ObjectId(applicationId) }, { "s.scriptid": mongodb.ObjectId(scriptId) }] }, function (err, result) {
                    //     if (err) {
                    //         console.log("Error in updating script status : " + err);
                    //         return res.status(500).json("Internal Server Error: Error in updating the script");
                    //     } else {
                    //         console.log("No Error in  updating script status : ");

                    db.collection("TestRuns").update({ "_id": mongodb.ObjectID(runId) },
                        {
                            $set: {
                                "status": status, "start_time": start_time, "end_time": end_time,
                                "slaMet": slaMet, "transaction": transaction
                            }
                        }, function (err, result) {
                            if (err) {
                                console.log("Error in updating status : " + err);
                                return res.status(500).json("Internal Server Error : Error in updating status");
                            } else {
                                console.log("Updated  status in Test Runs");
                                db.collection("TestResults").insert(resultJson, function (err, result) {
                                    if (err) {
                                        console.log("Error in adding test results documents  : " + err);
                                        return res.status(500).json(err);
                                    }
                                    else {
                                        console.log("No Error in  inserting data in Test Results : ");
                                        return res.status(200).json("added Test Results  Successfully");
                                    }
                                });
                            }
                        });
                    //     }
                    // });
                }
            });

        }

    });
});

router.post('/postDataFromPlugin', async function (req, res, next) {

    console.log("postDataFromPlugin");
    let response = (req.body.Response);
    var result = [];
    console.log(response);
    console.log(response.appid);
    result = response.url.split(".");
    let scenarioname = (result[1]);
    let details1 = []; details2 = [];
    response["issues"].unshift(
        {
            "pagename": {
                "pagenames": scenarioname
            }
        })
        response["issuesCount"]["0"]["rundetails"]["0"]["PageName"]=scenarioname
    details1[0] = response["issues"];
   
    details2[0] = response["issuesCount"];
    // console.log(response["issuesCount"]);
    let mongofinaljson = {};
    mongofinaljson.appid = new ObjectID(response["appid"]);
    mongofinaljson.customerid = new ObjectID(response["customerId"]);
    mongofinaljson.appurl = response["url"];
    mongofinaljson.scenarioname = scenarioname;
    mongofinaljson.scriptid = new ObjectID();
    mongofinaljson.detail1 = details1;
    mongofinaljson.detail2 = details2;
    mongofinaljson.timestamp = new Date();
    mongofinaljson.mlenabled = "false";
    await db.collection("RunIDCount").findOne({ "RunIDCountName": response["appid"] + '_' + response["customerId"] }, (err, result2) => {
        if (err) {
            //////console.log("err" + result)
            res.send({ Status: 'error' })
        }
        else if (result2 == null) {
            db.collection("RunIDCount").insert({ "RunIDCountName": response["appid"] + '_' + response["customerId"], "RunIDCountValue": 1 }, function (err, result2) {
                if (err) {
                    ////console.log(err);
                } else {
                    mongofinaljson.runid = 1;
                    db.collection("TestRuns").insert(mongofinaljson, function (err, result) {
                        if (err) {
                            //console.log("Error in inserting scheduling_table : " + err);
                            return res.status(500).json(err);
                        } else {
                            return res.status(200).json("added Test Results  Successfully");
                        }
                    })
                }
            })
        }
        else if (result2 !== null) {
            let runidvalue = (result2["RunIDCountValue"])
            db.collection("RunIDCount").updateOne({ "RunIDCountName": response["appid"] + '_' + response["customerId"] }, {
                "$set": {
                    "RunIDCountValue": runidvalue + 1,
                }
            }, function (err) {
                if (err) {
                    ////console.log(err);
                }
                else {
                    mongofinaljson.runid = runidvalue + 1;
                    db.collection("TestRuns").insert(mongofinaljson, function (err, result) {
                        if (err) {
                            //console.log("Error in inserting scheduling_table : " + err);
                            return res.status(500).json(err);
                        } else {
                            return res.status(200).json("added Test Results  Successfully");
                        }
                    })
                }
            })

        }

    })

})

function fileReading(fileRead) {
    return new Promise(function (resolve, reject) {

        fs.readFile(fileRead, (err, data) => {
            if (err) {
                console.log(err);
                console.log(" Error in reading readjson file ");
                reject(false);
            } else {
                console.log(" reading file");
                resultJson = JSON.parse(data);
                resolve(true);
            }
        });

    });
}

// router.get('/getLoginValidation', function (req, res, next) {
//     var PerfAssureUrl = "http://ec2-13-232-249-39.ap-south-1.compute.amazonaws.com";
//     var component = "uxMobile";
//     var op = "validate";
//     var users = 0;
//     var email = "user2@cts.com";
//     var password = "pass@123";
//     var parJson = {
//         "email": email,
//         "password": password
//     }
//     console.log(JSON.stringify(parJson))
//     Request.post({
//         url: PerfAssureUrl + "/login/login",
//         json: true,
//         body: parJson
//     }, (errors, response, body) => {
//         if (errors) {
//             console.error(errors);
//             return res.status(500).json(errors);
//         } else {
//             //console.log(body.data.token);
//             Request.get({
//                 url: PerfAssureUrl + ":80/license/LicenseValidatorApi?component=" + component + "&users=" + users + "&op=" + op,
//                 headers: {
//                     'Authorization': 'Bearer ' + body.data.token
//                 }
//             }, (error, response, body) => {
//                 if (error) {
//                     console.error(error);
//                     return res.status(500).json(error);
//                 } else {
//                     console.log("response");
//                    // console.log(response);
//                     console.log(body);
//                     return res.status(200).json(" validate mobilePerf");
//                 }

//             });

//         }
//     });
// });


module.exports = router;