
var express = require('express');
//require the express router
var router = express.Router();
const bcrypt = require('bcrypt');

var elasticsearch = require('elasticsearch');


var config = require('../configuration.json');

let validationRoute = require('./validation.js');

var mongodb = require('mongodb');
//Using mongoclient, not using mongoose
var MongoClient = mongodb.MongoClient;
var dbURL = config.mongoDBURL;
let db;
MongoClient.connect(dbURL, function (err, mydb) {
  if (err) {
    console.log('admin.js : ERROR: DB connection failed');
    return err;
  } else {
    db = mydb.db();
    console.log('admin.js : DB connection established!');
  }
});

var elasticClient = new elasticsearch.Client({
  host: 'http://' + config.elasticsearchDBHost + ':9200',
  log: 'trace'
});

const saltRounds = config.saltRounds;
//app.set('secretKey', 'nodeRestApi')
//app.use(redirectToHTTPS([/localhost:(\d{4})/], [/\/addNewCustomerAdmin/], 301));


//this is onload of admin page
router.get('/getAllCustomerDetailsAdmin', function (req, res) {
  res.header("Strict-Transport-Security", "max-age=604800"); // 1 week in seconds   
  res.header('Cache-Control', 'private, no-cache, no-store, must-revalidate');
  //console.log('Decode string : ' + JSON.stringify(req.decoded));
  if(!req.decoded.hasOwnProperty('role')){
    return res.status(401).json("Unauthorized");
  }
  if(req.decoded.role!="admin"){
    return res.status(401).json("Unauthorized");
  }
  db.collection("Customers").find({}).toArray((err, result) => {
    if (err) {
      console.log("Error in Customers detail module : " + err);
      return res.status(500).json(err);
    } else {
      // console.log("Result  " + result);
      return res.status(200).json(result);
    }
  });


});



//this is to get customer details after selecting a customer in admin page
router.get('/getCustomerDetailsAdmin', function (req, res) {   
  res.header("Strict-Transport-Security", "max-age=604800"); // 1 week in seconds   
  res.header('Cache-Control', 'private, no-cache, no-store, must-revalidate');
  console.log("inside getCustomerDetailsAdmin");
  if(!req.decoded.hasOwnProperty('role')){
    return res.status(401).json("Unauthorized");
  }
  if(req.decoded.role!="admin"){
    return res.status(401).json("Unauthorized");
  }
  var id = req.query.customerId;
  if (typeof id == "undefined" || id === "" || id === null || validationRoute(id)) {
    return res.status(500).json("the values sent may be undefined null or empty");
  }
  db.collection("Customers").find({ "_id": mongodb.ObjectID(id) }).toArray((err, result) => {
    if (err) {
      console.log("Error in Customers detail module : " + err);
      return res.status(500).json(err);
    } else {
      // console.log("Result  " + result);
      return res.status(200).json(result);
    }
  });
});



router.post('/addNewCustomerAdmin', function (req, res) {
  res.header("Strict-Transport-Security", "max-age=604800"); // 1 week in seconds   
  res.header('Cache-Control', 'private, no-cache, no-store, must-revalidate');
  console.log("inside addNewCustomerAdmin");
  if(!req.decoded.hasOwnProperty('role')){
    return res.status(401).json("Unauthorized");
  }
  if(req.decoded.role!="admin"){
    return res.status(401).json("Unauthorized");
  }
  //console.log(req.query.customerName);
  //console.log(req.body);
  var customerName = req.body.customerName;
  var contactDetails = req.body.contactDetails;
  if (typeof customerName == "undefined" || customerName === "" || typeof contactDetails == "undefined" || contactDetails === "" || customerName === null || contactDetails === null || validationRoute(customerName) || validationRoute(contactDetails)) {
    return res.status(500).json("the values sent may be undefined null or empty");
  }
  db.collection("Customers").insert({ "customerName": customerName, "contactDetails": contactDetails, applications: [] }, function (err, result) {
    if (err) {
      console.log("Error in newCustomer : " + err);
      return res.status(500).json(err);
    }
    else {
      // console.log("No Error in  applicationNames : ");
      return res.status(200).json("added application Successfully");
    }
  });
});


router.post('/updateCustomerAdmin', function (req, res) {
  res.header("Strict-Transport-Security", "max-age=604800"); // 1 week in seconds   
  res.header('Cache-Control', 'private, no-cache, no-store, must-revalidate');
  if(!req.decoded.hasOwnProperty('role')){
    return res.status(401).json("Unauthorized");
  }
  if(req.decoded.role!="admin"){
    return res.status(401).json("Unauthorized");
  }
  var id = req.query.customerId;
  var customerName = req.body.customerName;
  var contactDetails = req.body.contactDetails;
  if (typeof id == "undefined" || id === "" || typeof customerName == "undefined" || customerName === "" || typeof contactDetails == "undefined" || contactDetails === "" || id === null || customerName === null || contactDetails === null || validationRoute(customerName) || validationRoute(contactDetails)) {
    return res.status(500).json("the values sent may be undefined null or empty");
  }
  db.collection("Customers").update({ "_id": mongodb.ObjectID(id) }, { "$set": { "customerName": customerName, "contactDetails": contactDetails } }, function (err, result) {
    if (err) {
      console.log("Error in updateCustomerAdmin : " + err);
      return res.status(500).json(err);
    }
    else {
      // console.log("No Error in  updateCustomerAdmin : ");
      return res.status(200).json("updated customer Successfully");
    }
  });
});

router.delete('/deleteCustomer', function (req, res) {
  res.header("Strict-Transport-Security", "max-age=604800"); // 1 week in seconds   
  res.header('Cache-Control', 'private, no-cache, no-store, must-revalidate');
  if(!req.decoded.hasOwnProperty('role')){
    return res.status(401).json("Unauthorized");
  }
  if(req.decoded.role!="admin"){
    return res.status(401).json("Unauthorized");
  }
  var id = req.query.customerId;
  if (typeof id == "undefined" || id === "" || id === null || validationRoute(id)) {
    return res.status(500).json("the values sent may be undefined null or empty");
  }
  db.collection("Customers").removeOne({ "_id": mongodb.ObjectID(id) }, function (err, result) {
    if (err) {
      console.log("Error in deleteCustomer : " + err);
      return res.status(500).json(err);
    }
    else {
      // console.log("No Error in  deleteCustomer : ");
      return res.status(200).json("customer deleted Successfully ");
    }
  });


});

router.post('/addNewApplicationAdmin', function (req, res) {
  res.header("Strict-Transport-Security", "max-age=604800"); // 1 week in seconds   
  res.header('Cache-Control', 'private, no-cache, no-store, must-revalidate');
  if(!req.decoded.hasOwnProperty('role')){
    return res.status(401).json("Unauthorized");
  }
  if(req.decoded.role!="admin"){
    return res.status(401).json("Unauthorized");
  }
  var applicationName = req.body.applicationName;
  var lob = req.body.lob;
  var id = req.query.customerId;
  if (typeof applicationName == "undefined" || applicationName === null || applicationName === "" || typeof lob == "undefined" || lob === null || lob === "" || typeof id == "undefined" || id === "" || id === null || validationRoute(id) || validationRoute(applicationName) || validationRoute(lob)) {
    return res.status(500).json("the values sent may be undefined null or empty");
  }
  if (applicationName !== applicationName.toLowerCase()) {
    return res.status(500).json("application Name should be in lower case");
  }
  else if (applicationName !== applicationName.replace(/\s/g, "")) {
    return res.status(500).json("application Name should not have spaces");
  }
  // console.log("customerID--" + id);
  db.collection("Customers").update({ "_id": mongodb.ObjectID(id) }, { $push: { application: { $each: [{ "appid": new mongodb.ObjectID(), "applicationName": applicationName, "lob": lob, "scripts": [] }] } } }, function (err, result) {
    if (err) {
      console.log("Error in applicationNames : " + err);
      return res.status(500).json("Error : while inserting new application");
    }
    else {
      // console.log("No Error in  applicationNames : ");

      //Now create an index in ElasticSearch
      elasticClient.index({
        index: applicationName,
        type: "_doc",
        body: {
        }
      }).then(function (x) {
        console.log(x);
        return res.status(200).json("added application Successfully");
      },
        function (err) {
          console.log(err);
          return res.status(500).json("Error : while inserting new application");
        });
    }
  });
});


router.post('/updateApplicationAdmin', function (req, res) {
  res.header("Strict-Transport-Security", "max-age=604800"); // 1 week in seconds   
  res.header('Cache-Control', 'private, no-cache, no-store, must-revalidate');
  if(!req.decoded.hasOwnProperty('role')){
    return res.status(401).json("Unauthorized");
  }
  if(req.decoded.role!="admin"){
    return res.status(401).json("Unauthorized");
  }
  var id = req.query.customerId;
  var applicationId = req.query.applicationId;
  var applicationName = req.body.applicationName;
  var lob = req.body.lob;
  if (typeof id == "undefined" || id === "" || id === null || typeof applicationName == "undefined" || applicationName === null || typeof applicationId == "undefined" || applicationId === null || applicationId === "" || typeof lob == "undefined" || lob === null || lob === "" || validationRoute(applicationId) || validationRoute(id) || validationRoute(applicationName) || validationRoute(lob)) {
    return res.status(500).json("the values sent may be undefined null or empty");
  }
  db.collection("Customers").update({ "_id": mongodb.ObjectID(id), "application.appid": mongodb.ObjectID(applicationId) }, { "$set": { "application.$[a].applicationName": applicationName, "application.$[a].lob": lob } }, { arrayFilters: [{ "a.appid": mongodb.ObjectId(applicationId) }] }, function (err, result) {
    if (err) {
      console.log("Error in updateApplicationAdmin : " + err);
      return res.status(500).json(err);
    }
    else {
      console.log("No Error in  updateApplicationAdmin : ");
      return res.status(200).json("updated application Successfully");
    }
  });
});



router.delete('/deleteApplicationAdmin', function (req, res) {
  res.header("Strict-Transport-Security", "max-age=604800"); // 1 week in seconds   
  res.header('Cache-Control', 'private, no-cache, no-store, must-revalidate'); 
  if(!req.decoded.hasOwnProperty('role')){
    return res.status(401).json("Unauthorized");
  }
  if(req.decoded.role!="admin"){
    return res.status(401).json("Unauthorized");
  }
  var id = req.query.customerId;
  var applicationId = req.query.applicationId;
  if (typeof id == "undefined" || id === "" || id === null || typeof applicationId == "undefined" || applicationId === null || applicationId === "" || validationRoute(applicationId) || validationRoute(id)) {
    return res.status(500).json("the values sent may be undefined null or empty");
  }
  db.collection("Customers").update({ "_id": mongodb.ObjectID(id), "application.appid": mongodb.ObjectID(applicationId) }, { "$pull": { "application": { "appid": mongodb.ObjectID(applicationId) } } }, function (err, result) {
    if (err) {
      console.log("Error in deleteApplication : " + err);
      return res.status(500).json(err);
    }
    else {
      console.log("No Error in  deleteApplication : ");
      return res.status(200).json("application deleted Successfully ");
    }
  });
});


router.post('/addNewUser', function (req, res) {
  res.header("Strict-Transport-Security", "max-age=604800"); // 1 week in seconds   
  res.header('Cache-Control', 'private, no-cache, no-store, must-revalidate');
  if(!req.decoded.hasOwnProperty('role')){
    return res.status(401).json("Unauthorized");
  }
  if(req.decoded.role!="admin"){
    return res.status(401).json("Unauthorized");
  }
  var userName = req.body.userName;
  var emailId = req.body.emailId;
  var customerName = req.body.customerName;
  var id = req.query.customerId;
  if (typeof userName == "undefined" || userName === "" || userName === null || typeof emailId == "undefined" || emailId === "" || emailId === null || typeof customerName == "undefined" || customerName === "" || customerName === null || typeof id == "undefined" || id === "" || id === null || validationRoute(id) || validationRoute(userName) || validationRoute(emailId) || validationRoute(customerName)) {
    return res.status(500).json("the values sent may be undefined null or empty");
  }
  const password = bcrypt.hashSync(config.defaultUserPassword, saltRounds);
  db.collection("users").insertOne({
    "userName": userName, "emailId": emailId, "password": password, "customerName": customerName,
    "customerId": mongodb.ObjectID(id)
  }, function (err, result) {
    if (err) {
      console.log("Error in addNewUsers : " + err);
      return res.status(500).json(err);
    }
    else {
      console.log("No Error in  addNewUsers : ");
      return res.status(200).json("added users Successfully");
    }
  });
});



router.post('/updateUser', function (req, res) {
  res.header("Strict-Transport-Security", "max-age=604800"); // 1 week in seconds   
  res.header('Cache-Control', 'private, no-cache, no-store, must-revalidate'); 
  console.log("inside new updateUser");
  if(!req.decoded.hasOwnProperty('role')){
    return res.status(401).json("Unauthorized");
  }
  if(req.decoded.role!="admin"){
    return res.status(401).json("Unauthorized");
  }
  var userId = req.query.userId;
  var userName = req.body.userName;
  var emailId = req.body.emailId;
  if (typeof userName == "undefined" || userName === "" || userName === null || typeof emailId == "undefined" || emailId === "" || emailId === null || typeof userId == "undefined" || userId === "" || userId === null || validationRoute(userName) || validationRoute(emailId) || validationRoute(userId)) {
    return res.status(500).json("the values sent may be undefined null or empty");
  }
  db.collection("users").updateOne({ "_id": mongodb.ObjectID(userId) }, {
    "$set": {
      "userName": userName, "emailId": emailId
    }
  }, function (err, result) {
    if (err) {
      console.log("Error in updateUser : " + err);
      return res.status(500).json(err);
    }
    else {
      console.log("No Error in  updateUser : ");
      return res.status(200).json("updated users Successfully");
    }
  })
});

router.post('/updateUserPassword', function (req, res) {
  res.header("Strict-Transport-Security", "max-age=604800"); // 1 week in seconds   
  res.header('Cache-Control', 'private, no-cache, no-store, must-revalidate');
  if(!req.decoded.hasOwnProperty('role')){
    return res.status(401).json("Unauthorized");
  }
  if(req.decoded.role!="admin"){
    return res.status(401).json("Unauthorized");
  }
  var pass = req.body.password;
  const password = bcrypt.hashSync(pass, saltRounds);
  var userId = req.query.userId;
  console.log("inside new updateUserPassword");
  if (typeof pass == "undefined" || pass === "" || pass === null || typeof userId == "undefined" || userId === "" || userId === null || validationRoute(userId)) {
    return res.status(500).json("the values sent may be undefined null or empty");
  }
  /*this.saltsalt = crypto.randomBytes(16).toString('hex');*/
  /*this.hashhash = crypto.pbkdf2Sync(req.body.password, this.salt, 1000, 64, 'sha512').toString('hex');*/

  db.collection("users").updateOne({ "_id": mongodb.ObjectID(userId) }, {
    "$set": {
      "password": password
    }
  }, function (err, result) {
    if (err) {
      console.log("Error in updateUserPassword : " + err);
      return res.status(500).json(err);
    }
    else {
      console.log("No Error in  updateUser : ");
      return res.status(200).json("updated password Successfully");
    }
  })
});

router.delete('/deleteUser', function (req, res) {
  res.header("Strict-Transport-Security", "max-age=604800"); // 1 week in seconds   
  res.header('Cache-Control', 'private, no-cache, no-store, must-revalidate');
  console.log("inside deleteUser");
  if(!req.decoded.hasOwnProperty('role')){
    return res.status(401).json("Unauthorized");
  }
  if(req.decoded.role!="admin"){
    return res.status(401).json("Unauthorized");
  }
  var userId = req.query.userId;
  if (typeof userId == "undefined" || userId === "" || userId === null || validationRoute(userId)) {
    return res.status(500).json("the values sent may be undefined null or empty");
  }
  db.collection("users").removeOne({ "_id": mongodb.ObjectID(userId) }, function (err, result) {
    if (err) {
      console.log("Error in deleteApplication : " + err);
      return res.status(500).json(err);
    }
    else {
      console.log("No Error in  deleteUser : ");
      return res.status(200).json("User deleted Successfully ");
    }
  })
});

router.get('/unBlockUser', function (req, res) {
  res.header("Strict-Transport-Security", "max-age=604800"); // 1 week in seconds   
  res.header('Cache-Control', 'private, no-cache, no-store, must-revalidate');
  console.log("inside unBlockUser");
  if(!req.decoded.hasOwnProperty('role')){
    return res.status(401).json("Unauthorized");
  }
  if(req.decoded.role!="admin"){
    return res.status(401).json("Unauthorized");
  }
  var userID = req.query.userId;
  if (typeof userID == "undefined" || userID === "" || userID === null || validationRoute(userID)) {
    return res.status(500).json("the values sent may be undefined null or empty");
  }
  db.collection("users").updateOne({ "_id": mongodb.ObjectID(userID) }, {
    "$set": {
      "state": "active",
      "incorrect_attempts": 0
    }
  }, function (err, result) {
    if (err) {
      console.log("Error in unBlockUser : " + err);
      return res.status(500).json(err);
    }
    else {
      console.log("User Unblocked Successfully ");
      return res.status(200).json("User Unblocked Successfully ");
    }
  });
  
});


router.get('/blockUser', function (req, res) {
  res.header("Strict-Transport-Security", "max-age=604800"); // 1 week in seconds   
  res.header('Cache-Control', 'private, no-cache, no-store, must-revalidate');
  console.log("inside blockUser");
  if(!req.decoded.hasOwnProperty('role')){
    return res.status(401).json("Unauthorized");
  }
  if(req.decoded.role!="admin"){
    return res.status(401).json("Unauthorized");
  }
  var userID = req.query.userId;
  if (typeof userID == "undefined" || userID === "" || userID === null || validationRoute(userID)) {
    return res.status(500).json("the values sent may be undefined null or empty");
  }
  db.collection("users").updateOne({ "_id": mongodb.ObjectID(userID) }, {
    "$set": {
      "state": "blocked",
      "incorrect_attempts": 0
    }
  }, function (err, result) {
    if (err) {
      console.log("Error in blockUser : " + err);
      return res.status(500).json(err);
    }
    else {
      console.log("User Blocked Successfully ");
      return res.status(200).json("User Blocked Successfully ");
    }
  });
  
});

router.get('/getUserDetails', function (req, res) {
  res.header("Strict-Transport-Security", "max-age=604800"); // 1 week in seconds   
  res.header('Cache-Control', 'private, no-cache, no-store, must-revalidate');
  console.log("inside getUserDetails");
  if(!req.decoded.hasOwnProperty('role')){
    return res.status(401).json("Unauthorized");
  }
  if(req.decoded.role!="admin"){
    return res.status(401).json("Unauthorized");
  }
  var customerId = req.query.customerId;
  if (typeof customerId == "undefined" || customerId === "" || customerId === null || validationRoute(customerId)) {
    return res.status(500).json("the values sent may be undefined null or empty");
  }
  db.collection("users").find({ "customerId": mongodb.ObjectID(customerId) }).toArray((err, result) => {
    if (err) {
      console.log("Error in User detail module : " + err);
      return res.status(500).json(err);
    } else {
      // console.log("Result  " + result);
      return res.status(200).json(result);
    }
  });
});


module.exports = router;
