var express = require('express');
var router = express.Router();
var config = require('../configuration.json');

let validationRoute = require('./validation.js');

var mongodb = require('mongodb');
//Using mongoclient, not using mongoose
var MongoClient = mongodb.MongoClient;
var dbURL = config.mongoDBURL;
let db;
MongoClient.connect(dbURL, function (err, mydb) {
    if (err) {
        console.log('userAPI.js : ERROR : DB connection failed using mongodb');
        return err;
    } else {
        db = mydb.db();
        console.log('userAPI.js : DB connection established using mongodb!');
    }
});

//Getting Applications 
router.get('/getApplicationListByCID', function (req, res) {
    res.header("Strict-Transport-Security", "max-age=604800"); // 1 week in seconds   
    res.header('Cache-Control', 'private, no-cache, no-store, must-revalidate');
    console.log("-----getApplicationListByCID------");

    var customerID = req.decoded.customerID;
    if (customerID === null || customerID === undefined || customerID === "") {
        return res.status(404).json("Token is not valid");
    }
    var bsonCustomerID = mongodb.ObjectID(customerID);
    //"customerId": bsonCustomerID 
    db.collection("Customers").find({ "_id": bsonCustomerID }).project({ "application.appid": 1, "application.applicationName": 1, }).toArray((err, result) => {
        if (err) {
            console.log("Error in getApplicationListByCID : " + err);
            return res.status(500).json(err);
        } else {
            //console.log("Result  " + result[0].application);
            return res.status(200).json(result[0].application);
        }
    });
});//end of //Getting Applications 

//Get Access Level
router.get('/getAccessLevelByID', function (req, res, next) {
    res.header("Strict-Transport-Security", "max-age=604800"); // 1 week in seconds   
    res.header('Cache-Control', 'private, no-cache, no-store, must-revalidate');
    console.log("-----getAccessLevelByID------");
    var authorization = req.headers['authorization'];

    var token = '';
    if (typeof authorization !== 'undefined') {
        const bearer = authorization.split(' ');
        token = bearer[1];

        if (token === null || token === undefined || token === "")//|| validationRoute(token))
        {
            return res.status(404).json({ message: "Token is not specified or not valid" });
        }
    } else {
        //If header is undefined return Forbidden (403)
        return res.status(403).send({
            error: true,
            message: "Forbidden - No token found"
        });
    }
    var jwt = require('jsonwebtoken');

    var secretKey = config.bcryptSecretKey;
    jwt.verify(token, secretKey, function (err, decoded) {
        // console.log("decoded: "+JSON.stringify(decoded));
        if (err) { //failed verification.
            console.log(err.message);
            return res.status(403).send({
                error: true,
                message: "Forbidden - No token found"
            });
        }
        let user = decoded;
        var bsonID = mongodb.ObjectID(user.id);
        db.collection('users').findOne({ "_id": bsonID }, function (err, result) {
            if (err) {
                return res.status(500).json(err);
            } else {
                let accesslevel = result.accesslevel;
                if (accesslevel === null || accesslevel === undefined || accesslevel === "") {
                    accesslevel = 0;
                }
                let response = {
                    accesslevel: accesslevel,
                };
                return res.status(200).json(response);
            }
        });
    });
});//end of //getAccessLevelByID


module.exports = router;
